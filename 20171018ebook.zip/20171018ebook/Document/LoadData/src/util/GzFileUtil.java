package util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

public class GzFileUtil extends GZIPInputStream {
	private GzFileUtil parent;
	private GzFileUtil child;
	private int size;
	private boolean eos;

	public GzFileUtil(InputStream in, int size) throws IOException {
		// Wrap the stream in a PushbackInputStream...
		super(new PushbackInputStream(in, size), size);
		this.size = size;
	}

	public GzFileUtil(InputStream in) throws IOException {
		// Wrap the stream in a PushbackInputStream...
		super(new PushbackInputStream(in, 1024));
		this.size = -1;
	}

	private GzFileUtil(GzFileUtil parent) throws IOException {
		super(parent.in);
		this.size = -1;
		this.parent = parent.parent == null ? parent : parent.parent;
		this.parent.child = this;
	}

	private GzFileUtil(GzFileUtil parent, int size) throws IOException {
		super(parent.in, size);
		this.size = size;
		this.parent = parent.parent == null ? parent : parent.parent;
		this.parent.child = this;
	}

	@SuppressWarnings("resource")
	public int read(byte[] inputBuffer, int inputBufferOffset,
			int inputBufferLen) throws IOException {
		if (eos) {
			return -1;
		}
		if (this.child != null)
			return this.child.read(inputBuffer, inputBufferOffset,
					inputBufferLen);
		int charsRead = super.read(inputBuffer, inputBufferOffset,
				inputBufferLen);
		if (charsRead == -1) {
			// Push any remaining buffered data back onto the stream
			// If the stream is then not empty, use it to construct
			// a new instance of this class and delegate this and any
			// future calls to it...
			int n = inf.getRemaining() - 8;
			if (n > 0) {
				// More than 8 bytes remaining in deflater
				// First 8 are gzip trailer. Add the rest to
				// any un-read data...
				((PushbackInputStream) this.in).unread(buf, len - n, n);
			} else {
				// Nothing in the buffer. We need to know whether or not
				// there is unread data available in the underlying stream
				// since the base class will not handle an empty file.
				// Read a byte to see if there is data and if so,
				// push it back onto the stream...
				byte[] b = new byte[1];
				int ret = in.read(b, 0, 1);
				if (ret == -1) {
					eos = true;
					return -1;
				} else
					((PushbackInputStream) this.in).unread(b, 0, 1);
			}
			GzFileUtil child;
			if (this.size == -1) {
				child = new GzFileUtil(this);
			} else {
				child = new GzFileUtil(this, this.size);
			}
			return child.read(inputBuffer, inputBufferOffset, inputBufferLen);
		} else
			return charsRead;
	}
	
	public static void main(String[] args) throws Exception {
		String url="http://www.talkingdata.com/measure/talkingdata/download?username=tddata@metrodata.cn&password=CjyddxqDeTAUIFfB&taskid=11113&date=20160904";
		downloadFile(url, "d:/test/kiss0905.txt");
		
	}
	
	/**
	 * 
	 * @param remoteFilePath
	 * @param localFilePath
	 * @throws Exception 
	 */
	public static void downloadFile(String remoteFilePath, String localFilePath) throws Exception {
		URL urlfile = null;
		HttpURLConnection httpUrl = null;
		InputStream bis = null;
		int nnumber;
		try {
			urlfile = new URL(remoteFilePath);
			httpUrl = (HttpURLConnection) urlfile.openConnection();
			httpUrl.connect();
			bis = httpUrl.getInputStream();
			GzFileUtil MmGz = new GzFileUtil(bis);
			FileOutputStream fout = new FileOutputStream(localFilePath);
			byte[] buf = new byte[1024];
			nnumber = MmGz.read(buf, 0, buf.length);
			while (nnumber != -1) {
				fout.write(buf, 0, nnumber);
				nnumber = MmGz.read(buf, 0, buf.length);
			}
			MmGz.close();
			fout.close();
			httpUrl.disconnect();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				bis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
    
	public static void unGzFile(String gzPath ,String topath ) {
		//String gzPath = "d:/kiss0905.gz", topath = "d:/kiss0905.txt";
		try {
			int nnumber;
			FileInputStream fin = new FileInputStream(gzPath);
			GzFileUtil MmGz = new GzFileUtil(fin);
			FileOutputStream fout = new FileOutputStream(topath);
			byte[] buf = new byte[1024];
			nnumber = MmGz.read(buf, 0, buf.length);
			while (nnumber != -1) {
				fout.write(buf, 0, nnumber);
				nnumber = MmGz.read(buf, 0, buf.length);
			}
			MmGz.close();
			fout.close();
			fin.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}