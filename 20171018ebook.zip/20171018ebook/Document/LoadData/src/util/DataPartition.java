package util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import td.GeosPatial;
import td.LabelData;
import td.ProbeData;

public class DataPartition {
	public static String lebUrl = "http://www.talkingdata.com/measure/talkingdata/download?username=tddata@metrodata.cn&password=CjyddxqDeTAUIFfB&taskid=11111&date=";
	public static String geoUrl = "http://www.talkingdata.com/measure/talkingdata/download?username=tddata@metrodata.cn&password=CjyddxqDeTAUIFfB&taskid=11112&date=";
	public static String probeUrl = "http://www.talkingdata.com/measure/talkingdata/download?username=tddata@metrodata.cn&password=CjyddxqDeTAUIFfB&taskid=11113&date=";
	private static String day = "";
	private static String week = "";

	public static void dataInit(String path,String t) throws Exception {
		
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("YYYYMMdd");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		date = calendar.getTime();
		if(StringUtils.isEmpty(t))
		{
			day = formatter.format(date);
		}else{
			day=t;
		}
		week = getDayOfWeek(day);
		
		String root=path;//DataPartition.class.getResource("/").getPath();
		System.out.println("数据路径："+root);
		GzFileUtil.downloadFile(lebUrl+day, root+day+"leb");
		LabelData.readProFile(root+day+"leb", "td_label"+day, "td_label_property"+day); 
		
		GzFileUtil.downloadFile(geoUrl+day, root+day+"geo.txt");
		GeosPatial.readGosFile(root+day+"geo.txt", "td_geospatial"+day,day,week);
		
		GzFileUtil.downloadFile(probeUrl+day, root+day+"probe");
		ProbeData.readProFile( root+day+"probe", "td_probe"+day); 
	}
	public static void main(String[] args) {
		try {
			if(args.length==2)
			{
				dataInit(args[0],args[1]);
			}else{
				dataInit(args[0],null);
				System.exit(0);
			}
		} catch (Exception e) {
			if(e.getMessage().contains("Not in GZIP format"))
			{
				System.out.println("无数据...");
			}else{
				System.out.println("处理异常："+e.getMessage());
			}
			System.exit(-1);
		}
	}


	public static String getDayOfWeek(String day) {
		final String dayNames[] = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五",
		"星期六" };
		SimpleDateFormat sdfInput = new SimpleDateFormat("yyyyMMdd");
		Calendar calendar = Calendar.getInstance();
		Date date = new Date();
		try {
			date = sdfInput.parse(day);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		calendar.setTime(date);
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1;
		if (dayOfWeek < 0)
			dayOfWeek = 0;
		return dayNames[dayOfWeek];

	}
	/**
	 * 
	 * @param remoteFilePath
	 * @param localFilePath
	 */
    public static void downloadFile(String remoteFilePath, String localFilePath)
    {
        URL urlfile = null;
        HttpURLConnection httpUrl = null;
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        File f = new File(localFilePath);
        try
        {
            urlfile = new URL(remoteFilePath);
            httpUrl = (HttpURLConnection)urlfile.openConnection();
            httpUrl.connect();
            bis = new BufferedInputStream(httpUrl.getInputStream());
            bos = new BufferedOutputStream(new FileOutputStream(f));
            int len = 2048;
            byte[] b = new byte[len];
            while ((len = bis.read(b)) != -1)
            {
                bos.write(b, 0, len);
            }
            bos.flush();
            bis.close();
            httpUrl.disconnect();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                bis.close();
                bos.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
}
