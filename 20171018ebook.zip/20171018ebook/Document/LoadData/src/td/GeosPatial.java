package td;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class GeosPatial {

	 public static void readGosFile(String filePath,String destFile,String day,String week) throws Exception{
		InputStreamReader read = null;
		OutputStream write = null;
		/**
		 * {����λ��}��γ��_����_���ִ��� {������/��ĩ��ĳ��ʱ���ڵĵ���λ�÷ֲ�}��ʱ��:{����λ��},{����λ��},{����λ��},...
		 * {��������ĳ��ʱ���ڵĵ���λ�÷ֲ�};{��������ĳ��ʱ���ڵĵ���λ�÷ֲ�}
		 * |{��ĩ��ĳ��ʱ���ڵĵ���λ�÷ֲ�};{��ĩ��ĳ��ʱ���ڵĵ���λ�÷ֲ�} 54:e4:3a:4e:b5:12
		 * 17:31.39687_121.05354_2,31.39412_120.96703_5, 31.40236_120.96977_1;
		 * 8:31.36803_121.05492_1, 31.39412_120.96703_1, 31.40373_120.95879_2,
		 * 31.29112_120.92308_6; 11:31.35017_120.96703_1,31.36803_121.05492_2;
		 * 16:31.39412_120.96703_1,31.40511_120.97252_2; 10:
		 * 31.39412_120.96703_7,31.44905_120.94643_1;
		 * 19:31.39412_120.96977_1,31.39687_120
		 * .92445_1,31.39412_120.96703_5,31.38176_120
		 * .90385_4,31.35979_120.64293_1
		 * ;9:31.39412_120.96703_1;21:31.44218_120.92308_1
		 * ,31.39412_120.96703_7,31.38863_120
		 * .99724_4,31.41609_120.93407_2,31.37901_121
		 * .08788_3,31.39687_120.92445_6
		 * ;15:31.37215_121.02882_3,31.37489_121.03157_2,31.39275_120.96703_1
		 * INSERT INTO `td_geospatial` (`mac`, `t_time`, `longitude`,
		 * `latitude`, `counts`, `t_day`, `t_week`, `t_holiday`, `record_id`,
		 * `create_time`) VALUES ('2', '2', '2', '2', '2', '2', '2', '2', '2',
		 * '2016-09-02 19:51:53')
		 * |8:31.33919_120.66765_3;20:31.39275_120.96703_8
		 * ,31.38176_120.90385_1,31.42296_120
		 * .91072_2;19:31.35017_120.96703_2,31.40511_120
		 * .97252_1;9:31.40923_120.91621_2
		 * ,31.39687_120.96703_6,31.40099_120.96977_1;21:31.39275_120.96703_1
		 * f779bd142eca4a83b42e598cf59c669d
		 */
		try {

			String encoding = "utf-8";
			File file = new File(filePath);
			File destF = new File(destFile);
			if (file.isFile() && file.exists()) { // �ж��ļ��Ƿ����
				read = new InputStreamReader(new FileInputStream(file),
						encoding);// ���ǵ������ʽ
				write = new FileOutputStream(destF);
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				Date now = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat(
						"YYYY-MM-dd HH:mm:ss");
				String condate = formatter.format(now);
				while ((lineTxt = bufferedReader.readLine()) != null) {
					String values[] = lineTxt.split("\t", -1);
					String user_mac = values[0];
					String id = values[2];
					String latitude = "";
					String longitude = "";
					String time = "";
					String count = "";
					String lalong = values[1];
					if (lalong.contains("|")) {
						String lebs[] = lalong.split("\\|", -1);// ����λ��
						String days = lebs[0];// ������
						String weeks = lebs[1];// ��ĩ
						for (String tempday : StringUtils.split(days, ";")) {
							String timep[] = StringUtils.split(tempday, ":");
							time = timep[0];// ʱ��
							for (String gc : StringUtils.split(timep[1], ",")) {
								String gc_[] = gc.split("_", -1);
								StringBuffer data = new StringBuffer();
								try {
									latitude = gc_[0];
									longitude = gc_[1];
									count = gc_[2];
								} catch (Exception e) {
									System.out.println("异常数据："+timep[1]);
								}
								data.append(user_mac);
								data.append(";");
								data.append(time);
								data.append(";");
								data.append(longitude);
								data.append(";");
								data.append(latitude);
								data.append(";");
								data.append(count);
								data.append(";");
								data.append(day);
								data.append(";");
								data.append(week);
								data.append(";");
								data.append(1);//1��?����
								data.append(";");
								data.append(id);
								data.append(";");
								data.append(condate);
								data.append("\r\n");
								write.write(data.toString().getBytes("utf-8"));

							}
						}
						for (String temps : StringUtils.split(weeks, ";")) {
							String timep[] = StringUtils.split(temps, ":");
							time = timep[0];// ʱ��
							for (String gc : StringUtils.split(timep[1], ",")) {
									String gc_[] = gc.split("_", -1);
									try {
										latitude = gc_[0];
										longitude = gc_[1];
										count = gc_[2];
									} catch (Exception e) {
										System.out.println("异常数据："+timep[1]);
									}
									StringBuffer data = new StringBuffer();
									data.append(user_mac);
									data.append(";");
									data.append(time);
									data.append(";");
									data.append(longitude);
									data.append(";");
									data.append(latitude);
									data.append(";");
									data.append(count);
									data.append(";");
									data.append(day);
									data.append(";");
									data.append(week);
									data.append(";");
									data.append(2);//2������
									data.append(";");
									data.append(id);
									data.append(";");
									data.append(condate);
									data.append("\r\n");
									write.write(data.toString().getBytes("utf-8"));
								
								
							}
						}

					}else{
						StringBuffer data = new StringBuffer();
						data.append(user_mac);
						data.append(";");
						data.append(time);
						data.append(";");
						data.append(longitude);
						data.append(";");
						data.append(latitude);
						data.append(";");
						data.append(count);
						data.append(";");
						data.append(day);
						data.append(";");
						data.append(week);
						data.append(";");
						data.append(";");
						data.append(id);
						data.append(";");
						data.append(condate);
						data.append("\r\n");
						write.write(data.toString().getBytes("utf-8"));
					}
				}
				read.close();
			} else {
				System.out.println("文件未找到");
			}
		} catch (Exception e) {
			System.out.println("文件未找到:" + e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (write != null) {
					write.close();
				}
				if (read != null) {
					read.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
		}
	public static void main(String[] args) throws Exception {
		readGosFile("d:/geospatial.a","d:/geospatial.txt","20160905","����һ");
	}
	
}
