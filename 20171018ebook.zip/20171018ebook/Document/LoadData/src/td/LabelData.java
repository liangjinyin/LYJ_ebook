package td;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;


public class LabelData {
	 public static void readProFile(String filePath,String destFile,String tdFroperty) throws Exception{
			InputStreamReader read = null;
			OutputStream write = null;
			OutputStream write2 = null;
			try {
			String encoding = "utf-8";
			File file = new File(filePath);
			File destF = new File(destFile);
			File froperty = new File(tdFroperty);
			if (file.isFile() && file.exists()) { // �ж��ļ��Ƿ����
				read = new InputStreamReader(new FileInputStream(file),
						encoding);// ���ǵ������ʽ
				write = new FileOutputStream(destF);
				write2 = new FileOutputStream(froperty);
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				Date now = new Date();
				SimpleDateFormat formatter = new SimpleDateFormat(
						"YYYY-MM-dd HH:mm:ss");
				String condate = formatter.format(now);
				/**
				70:11:24:ae:ea:5f		
				02010101;0.52|02011303;0.65|020113;0.65|020114;0.77|02010102;0.65|02011411;0.77|02011203;0.88|020101;1.4|020112;0.88	
				030101;50.0		
				060103;10.0|06010301;10.0	
				�Ϻ���
				������
				����|�ֻ�|���Լ۱�|5.5-5.1Ӣ��|˫��˫��|500-999|S920
				����
				android+4.2.1			
				720*1280*320	
				61ba8688691d44ab9b0304f07999d39b
				
				*/
				while ((lineTxt = bufferedReader.readLine()) != null) {
					//System.out.println(lineTxt);
					String values[] = lineTxt.split("\t", -1);	
					String mac=values[0];
					String city=values[6];
					String village=values[7];
					String device=values[10];
					String lan=values[11];
					String version=values[12];
					String video=values[13];
					String id=values[14];
					StringBuffer data2 = new StringBuffer();
					data2.append(mac);
					data2.append(";");
					data2.append(city);
					data2.append(";");
					data2.append(village);
					data2.append(";");
					data2.append(device);
					data2.append(";");
					data2.append(lan);
					data2.append(";");
					data2.append(version);
					data2.append(";");
					data2.append(video);
					data2.append(";");
					data2.append(id);
					data2.append(";");
					data2.append(condate);
					data2.append("\r\n");
					write2.write(data2.toString().getBytes("utf-8"));
					for (String lie : values) {
						//System.out.println(lie);
						if(lie.contains("|")&&lie.contains(";")){
							for (String string : StringUtils.split(lie, "|")) {
								if(string.contains(";"))
								{
									String names[] = StringUtils.split(string, ";");
									StringBuffer data = new StringBuffer();
									data.append(mac);
									data.append(";");
									for (String s : names) {
										if(!s.equals(mac)){
											data.append(s);
											data.append(";");
										}
									}
									data.append(condate);
									data.append("\r\n");
									write.write(data.toString().getBytes("utf-8"));
								}
							}
						}
						if(lie.contains(";")&&!lie.contains("|")){
							String names[] = StringUtils.split(lie, ";");
							StringBuffer data = new StringBuffer();
							data.append(mac);
							data.append(";");
							for (String s : names) {
								if(!s.equals(mac)){
									data.append(s);
									data.append(";");
								}
							}
							data.append(condate);
							data.append("\r\n");
							write.write(data.toString().getBytes("utf-8"));
						}
						
					}
					
				}
				read.close();
			} else {
				System.out.println("文件未找到");
			}
			} catch (Exception e) {
				System.out.println("文件未找到" + e.getMessage());
				e.printStackTrace();
				throw e;
			} finally {
				try {
					if (write != null) {
						write.close();
					}
					if (read != null) {
						read.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	public static void main(String[] args) throws Exception {
		readProFile("d:/leb.a","d:/leb.txt","d:/lebPro.txt");
	}

}
