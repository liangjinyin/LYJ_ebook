package td;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
public class ProbeData {
	 public static void readProFile(String filePath,String destFile) throws Exception{
			InputStreamReader read = null;
			OutputStream write = null;
			/**
			 * 00:16:6d:3f:3e:9d e4:95:6e:4e:e7o:a8 1471958527 1471958600 -84
			 * 00:16:6d:d9:a5:a6 e4:95:6e:4e:e8:d2 1471948571 1471948612 -87
			 * 00:18:e4:cb:8e:0f e4:95:6e:4e:e7:a8 1471937299 1471937299 -83
			 * 00:18:e4:d5:66:d1 e4:95:6e:4e:e7:a8 1471945160 1471945160 -85 INSERT
			 * INTO `td_probe` (`user_mac`, `probe_mac`, `first_time`, `last_time`,
			 * `sign`, `update_time`) VALUES ('1', '1', '1', '1', '1', '2016-08-31
			 * 17:48:20')
			 */
			try {
				String encoding = "utf-8";
				File file = new File(filePath);
				File destF = new File(destFile);
				if (file.isFile() && file.exists()) { // �ж��ļ��Ƿ����
					read = new InputStreamReader(new FileInputStream(file),
							encoding);// ���ǵ������ʽ
					write = new FileOutputStream(destF);
					BufferedReader bufferedReader = new BufferedReader(read);
					String lineTxt = null;
					Date now = new Date();
					SimpleDateFormat formatter = new SimpleDateFormat(
							"YYYY-MM-dd HH:mm:ss");
					String condate = formatter.format(now);
					while ((lineTxt = bufferedReader.readLine()) != null) {
						StringBuffer sql = new StringBuffer();
						String values[] = lineTxt.split("\t",-1);
						String user_mac = "";
						String probe_mac = "";
						String first_time = "";
						String last_time = "";
						String sign = "";
						user_mac = values[0];
						probe_mac = values[1];
						first_time = values[2];
						last_time = values[3];
						sign = values[4];
						sql.append( user_mac );
						sql.append(";");
						sql.append( probe_mac );
						sql.append(";");
						Date t = new Date(Long.parseLong(first_time) * 1000);
						sql.append( formatter.format(t) );
						sql.append(";");
						t = new Date(Long.parseLong(last_time) * 1000);
						sql.append( formatter.format(t) );
						sql.append(";");
						sql.append( sign );
						sql.append(";");
						sql.append( condate );
						sql.append("\r\n");
						write.write(sql.toString().getBytes("utf-8"));
					}
					read.close();
				} else {
					System.out.println("文件未找到");
				}
			} catch (Exception e) {
				System.out.println("文件未找到：" + e.getMessage());
				e.printStackTrace();
				throw e;
			} finally {
				try {
					if (write != null) {
						write.close();
					}
					if (read != null) {
						read.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	public static void main(String[] args) throws Exception {
		readProFile("d:/",args[1]);
		//readProFile(args[0],args[1]);
	}

}
