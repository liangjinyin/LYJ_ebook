使用说明

使用hive用户操作
su - hive

导入指定时间段的数据 时间格式YYYYmmdd
loaddata.sh 日期
导入9月七号的数据列子:  ./loaddata.sh 20160907
无参数  默认导入昨天的数据


批量导入时间段数据  时间格式YYYYmmdd
allload.sh 开始日期 结束日期
导入八月分的数据
./allload.sh  20160801 20150830

无参数默认导入前五天的数据 不包括今天



数据导入本地

java -jar loaddata.jar  原始数据路径  日期

处理数据在当前目录
