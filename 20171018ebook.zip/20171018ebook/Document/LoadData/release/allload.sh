
#!/bin/bash
##开始时间    前五天
startDate=`date -d "5 day ago" +"%Y%m%d"`
##结束时间    前一天
endDate=`date -d "1 day ago" +"%Y%m%d"`
dir=`dirname $0`
source /etc/profile
cd $dir
dir=`pwd`

if [ $# -eq 2 ];then  	
  startDate=$1
  endDate=$2
fi

startSec=`date -d "$startDate" "+%s"`
endSec=`date -d "$endDate" "+%s"`
for((i=$startSec;i<=$endSec;i+=86400))
do
    yd=`date -d "@$i" "+%Y%m%d"`
    echo "导入"${yd}"的数据............."
    $dir/loaddata.sh ${yd}
done
