#!/usr/bin/env bash
dir=`dirname $0`
source /etc/profile
cd $dir
dir=`pwd`

day=`date -d "1 day ago" +"%Y%m%d"`

if [ $# -eq 1 ];then
  day=$1
fi
echo $day
week=`date -d $day  +"%A"`
echo $week

probedata=/apps/hive/warehouse/data_center.db/td_probe/
lebdata=/apps/hive/warehouse/data_center.db/td_label/
lebprodata=/apps/hive/warehouse/data_center.db/td_label_property/
geodata=/apps/hive/warehouse/data_center.db/td_geospatial/
mkdir -p $dir/original
mkdir -p $dir/data

#加载数据到本地
java -jar $dir/loaddata.jar  $dir/original/ $day
if [ $? -ne 0 ];then
  echo  $day" 数据下载失败，无数据"
  exit -1	
fi
# exit -1
# return 
# 删除已存在的分区
hive -e "use data_center; alter table td_label drop partition(day='$day'); alter table td_label_property drop partition(day='$day'); alter table td_geospatial drop partition(day='$day'); alter table  td_probe  drop partition(day='$day');"

##创建分区目录
lebdata=$lebdata"day=$day"
lebprodata=$lebprodata"day=$day"
geodata=$geodata"day=$day"
probedata=$probedata"day=$day"
hadoop fs -mkdir -p $lebdata
hadoop fs -mkdir -p $lebprodata
hadoop fs -mkdir -p $geodata
hadoop fs -mkdir -p $probedata

echo "导入hdfs数据$day"
##导入标签数据
hadoop fs -put $dir/td_label$day $lebdata

##导入标签属性数据
hadoop fs -put $dir/td_label_property$day $lebprodata

##导入地理位置数据
hadoop fs -put $dir/td_geospatial$day   $geodata

##导入设备数据
hadoop fs -put $dir/td_probe$day  $probedata

#切分数据保存在data下
mv -f $dir/td_* $dir/data/

echo "数据处理"
hive -e "use data_center; alter table td_label add partition(day='$day'); alter table td_label_property add partition(day='$day'); alter table td_geospatial add partition(day='$day'); alter table td_probe add partition(day='$day'); insert overwrite table td_geospatial partition (day='$day') select g.mac, g.t_time, g.longitude, g.latitude, max(g.counts) as counts, '$day' as t_day, '$week' as t_week, g.t_holiday, g.record_id, '' as create_time from td_geospatial as g group by g.mac, g.t_time, g.longitude, g.latitude, g.t_holiday,g.record_id; insert overwrite table td_label partition (day='$day') select l.user_mac, l.label, l.weight, max(l.create_time) as create_time from td_label as l group by l.label, l.user_mac, l.create_time, l.weight;"

