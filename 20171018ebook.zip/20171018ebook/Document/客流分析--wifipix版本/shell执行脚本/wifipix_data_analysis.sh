#!bin/sh

# 历史采集数据处理
# 表结构初始化
 su - hdfs -c "hive -f /home/hdfs/wifipix_hql/1.table_create.hql"

# 1、将文件从59上同步至14服务器上,并删除当天的采集数据
 rm -rf /home/masa/wifipix/* 
 scp -r 172.30.103.59:/home/masa/wifipix/* /home/masa/wifipix
 today=`date "+%Y%m%d"`
 rm -f /home/masa/wifipix/${today}
# 2、历史数据上传至hive表的hdfs目录下：
 hadoop fs -mkdir /apps/hive/warehouse/wifipix.db/base_probe_user_visit_info_original/history
 hadoop fs -put /home/masa/wifipix/* /apps/hive/warehouse/wifipix.db/base_probe_user_visit_info_original/history/
# 3、历史数据加载到hive表（原始明细表）
 su - hdfs -c "hive -f /home/hdfs/wifipix_hql/2.history_data_load.hql"
# 4、历史数据分析
 su - hdfs -c "hive -f /home/hdfs/wifipix_hql/3.history_data_analysis.hql"
# 5、导出结果数据
# 1、sqoop导出结果数据至marketing
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/marketing?characterEncoding=utf8 --username marketing --password exmind --table st_case_user_visit_info_daily1 --export-dir /apps/hive/warehouse/wifipix.db/case_user_visit_info_daily --input-fields-terminated-by '\t' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/marketing?characterEncoding=utf8 --username marketing --password exmind --table st_case_user_visit_info_daily_by_dur1 --export-dir /apps/hive/warehouse/wifipix.db/case_user_visit_info_daily_by_dur --input-fields-terminated-by '\t' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/marketing?characterEncoding=utf8 --username marketing --password exmind --table st_case_user_visit_info_daily_by_period1 --export-dir /apps/hive/warehouse/wifipix.db/case_user_visit_info_daily_by_period --input-fields-terminated-by '\t' --input-null-string '\\\N' --input-null-non-string '\\\N'"

# 2、sqoop导出结果数据至marketing
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/masa?characterEncoding=utf8 --username masa --password masa --table st_case_user_visit_info_daily1 --export-dir /apps/hive/warehouse/wifipix.db/masa_case_user_visit_info_daily --input-fields-terminated-by '\t' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/masa?characterEncoding=utf8 --username masa --password masa --table st_case_user_visit_info_daily_by_dur1 --export-dir /apps/hive/warehouse/wifipix.db/masa_case_user_visit_info_daily_by_dur --input-fields-terminated-by '\t' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/masa?characterEncoding=utf8 --username masa --password masa --table st_case_probe_user_visit_info_daily1 --export-dir /apps/hive/warehouse/wifipix.db/masa_case_probe_user_visit_info_daily --input-fields-terminated-by '\t' --input-null-string '\\\N' --input-null-non-string '\\\N'"

# 增量采集数据处理
# 1、每日将昨日生成的采集文件从59上同步至14服务器上
 yesterday=`date -d yesterday "+%Y%m%d"`
 scp -r 172.30.103.59:/home/masa/wifipix/${yesterday} /home/masa/wifipix
# 2、昨日采集数据文件上传至hive表的hdfs目录下：
 hadoop fs -mkdir /apps/hive/warehouse/wifipix.db/base_probe_user_visit_info_original/${yesterday}
 hadoop fs -put /home/masa/wifipix/${yesterday} /apps/hive/warehouse/wifipix.db/base_probe_user_visit_info_original/${yesterday}/
# 3、加载hive分区数据（原始明细表）
 su - hdfs -c "hive -hiveconf yesterday='${yesterday}' -f /home/hdfs/wifipix_hql/4.daily_data_load.hql"
# 4、增量数据分析
 su - hdfs -c "hive -f /home/hdfs/wifipix_hql/5.daily_data_analysis.hql"
# 5 导出日增数据

# 1、sqoop导出结果数据至marketing
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/marketing?characterEncoding=utf8 --username marketing --password exmind --table st_case_user_visit_info_daily1 --export-dir /apps/hive/warehouse/wifipix.db/case_user_visit_info_daily_add --input-fields-terminated-by '\001' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/marketing?characterEncoding=utf8 --username marketing --password exmind --table st_case_user_visit_info_daily_by_dur1 --export-dir /apps/hive/warehouse/wifipix.db/case_user_visit_info_daily_by_dur_add --input-fields-terminated-by '\001' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/marketing?characterEncoding=utf8 --username marketing --password exmind --table st_case_user_visit_info_daily_by_period1 --export-dir /apps/hive/warehouse/wifipix.db/case_user_visit_info_daily_by_period_add --input-fields-terminated-by '\001' --input-null-string '\\\N' --input-null-non-string '\\\N'"

# 2、sqoop导出结果数据至marketing
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/masa?characterEncoding=utf8 --username masa --password masa --table st_case_user_visit_info_daily1 --export-dir /apps/hive/warehouse/wifipix.db/masa_case_user_visit_info_daily_add --input-fields-terminated-by '\001' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/masa?characterEncoding=utf8 --username masa --password masa --table st_case_user_visit_info_daily_by_dur1 --export-dir /apps/hive/warehouse/wifipix.db/masa_case_user_visit_info_daily_by_dur_add --input-fields-terminated-by '\001' --input-null-string '\\\N' --input-null-non-string '\\\N'"
 su - hdfs -c "sqoop export --connect jdbc:mysql://172.30.103.14:3306/masa?characterEncoding=utf8 --username masa --password masa --table st_case_probe_user_visit_info_daily1 --export-dir /apps/hive/warehouse/wifipix.db/masa_case_probe_user_visit_info_daily_add --input-fields-terminated-by '\001' --input-null-string '\\\N' --input-null-non-string '\\\N'"

