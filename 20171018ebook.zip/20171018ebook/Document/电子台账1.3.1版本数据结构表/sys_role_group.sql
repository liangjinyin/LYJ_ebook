/*
Navicat MySQL Data Transfer

Source Server         : 172.30.103.14
Source Server Version : 50534
Source Host           : 172.30.103.14:3306
Source Database       : ebook

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2017-11-13 15:39:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `sys_role_group`
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_group`;
CREATE TABLE `sys_role_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(16) NOT NULL COMMENT '权限名',
  `create_time` datetime DEFAULT NULL,
  `create_by` varchar(64) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_by` varchar(64) DEFAULT NULL,
  `del_flag` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='权限配置信息';

-- ----------------------------
-- Records of sys_role_group
-- ----------------------------
INSERT INTO `sys_role_group` VALUES ('1', '案场普通用户', '2017-09-30 17:43:04', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('2', '案场管理员', '2017-09-30 17:43:30', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('3', '管理员', '2017-09-30 17:44:00', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('4', '系统普通人员', '2017-09-30 17:57:58', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('5', '测试', '2017-10-10 15:12:21', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('6', '测试2', '2017-10-10 15:12:45', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('7', '测试3', '2017-10-10 15:13:10', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('8', '测试4', '2017-10-10 15:13:43', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('9', '测试5', '2017-10-10 15:15:12', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('10', '测试6', '2017-10-11 09:51:52', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('11', '测试8', '2017-10-12 10:47:30', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('12', '测试7', '2017-10-12 10:48:07', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('13', '测试9', '2017-10-12 11:16:38', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('14', '测试10', '2017-10-13 10:41:49', null, null, null, '0');
INSERT INTO `sys_role_group` VALUES ('15', '测试11', '2017-10-16 15:56:04', null, null, null, '0');
