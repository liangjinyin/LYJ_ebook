/*
Navicat MySQL Data Transfer

Source Server         : 172.30.103.14
Source Server Version : 50534
Source Host           : 172.30.103.14:3306
Source Database       : ebook

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2017-11-13 15:39:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `sys_role_group_detail`
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_group_detail`;
CREATE TABLE `sys_role_group_detail` (
  `group_id` int(11) NOT NULL COMMENT '权限id',
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限详细信息';

-- ----------------------------
-- Records of sys_role_group_detail
-- ----------------------------
INSERT INTO `sys_role_group_detail` VALUES ('2', '2');
INSERT INTO `sys_role_group_detail` VALUES ('2', '5');
INSERT INTO `sys_role_group_detail` VALUES ('2', '8');
INSERT INTO `sys_role_group_detail` VALUES ('2', '9');
INSERT INTO `sys_role_group_detail` VALUES ('2', '10');
INSERT INTO `sys_role_group_detail` VALUES ('2', '11');
INSERT INTO `sys_role_group_detail` VALUES ('2', '12');
INSERT INTO `sys_role_group_detail` VALUES ('1', '1');
INSERT INTO `sys_role_group_detail` VALUES ('1', '8');
INSERT INTO `sys_role_group_detail` VALUES ('1', '9');
INSERT INTO `sys_role_group_detail` VALUES ('1', '10');
INSERT INTO `sys_role_group_detail` VALUES ('1', '11');
INSERT INTO `sys_role_group_detail` VALUES ('1', '12');
INSERT INTO `sys_role_group_detail` VALUES ('1', '4');
INSERT INTO `sys_role_group_detail` VALUES ('1', '5');
INSERT INTO `sys_role_group_detail` VALUES ('10', '4');
INSERT INTO `sys_role_group_detail` VALUES ('10', '5');
INSERT INTO `sys_role_group_detail` VALUES ('10', '8');
INSERT INTO `sys_role_group_detail` VALUES ('10', '9');
INSERT INTO `sys_role_group_detail` VALUES ('10', '10');
INSERT INTO `sys_role_group_detail` VALUES ('10', '11');
INSERT INTO `sys_role_group_detail` VALUES ('10', '12');
INSERT INTO `sys_role_group_detail` VALUES ('9', '2');
INSERT INTO `sys_role_group_detail` VALUES ('9', '8');
INSERT INTO `sys_role_group_detail` VALUES ('9', '9');
INSERT INTO `sys_role_group_detail` VALUES ('9', '10');
INSERT INTO `sys_role_group_detail` VALUES ('9', '11');
INSERT INTO `sys_role_group_detail` VALUES ('9', '12');
INSERT INTO `sys_role_group_detail` VALUES ('3', '1');
INSERT INTO `sys_role_group_detail` VALUES ('3', '4');
INSERT INTO `sys_role_group_detail` VALUES ('3', '5');
INSERT INTO `sys_role_group_detail` VALUES ('3', '6');
INSERT INTO `sys_role_group_detail` VALUES ('3', '8');
INSERT INTO `sys_role_group_detail` VALUES ('3', '9');
INSERT INTO `sys_role_group_detail` VALUES ('3', '10');
INSERT INTO `sys_role_group_detail` VALUES ('3', '11');
INSERT INTO `sys_role_group_detail` VALUES ('3', '12');
INSERT INTO `sys_role_group_detail` VALUES ('3', '2');
INSERT INTO `sys_role_group_detail` VALUES ('5', '2');
INSERT INTO `sys_role_group_detail` VALUES ('5', '6');
INSERT INTO `sys_role_group_detail` VALUES ('8', '2');
INSERT INTO `sys_role_group_detail` VALUES ('8', '6');
INSERT INTO `sys_role_group_detail` VALUES ('8', '5');
INSERT INTO `sys_role_group_detail` VALUES ('11', '2');
INSERT INTO `sys_role_group_detail` VALUES ('11', '6');
INSERT INTO `sys_role_group_detail` VALUES ('4', '2');
INSERT INTO `sys_role_group_detail` VALUES ('4', '4');
INSERT INTO `sys_role_group_detail` VALUES ('4', '5');
INSERT INTO `sys_role_group_detail` VALUES ('4', '8');
INSERT INTO `sys_role_group_detail` VALUES ('4', '9');
INSERT INTO `sys_role_group_detail` VALUES ('14', '4');
INSERT INTO `sys_role_group_detail` VALUES ('14', '8');
INSERT INTO `sys_role_group_detail` VALUES ('14', '5');
INSERT INTO `sys_role_group_detail` VALUES ('13', '1');
INSERT INTO `sys_role_group_detail` VALUES ('13', '2');
INSERT INTO `sys_role_group_detail` VALUES ('13', '4');
INSERT INTO `sys_role_group_detail` VALUES ('13', '6');
INSERT INTO `sys_role_group_detail` VALUES ('13', '8');
INSERT INTO `sys_role_group_detail` VALUES ('13', '9');
INSERT INTO `sys_role_group_detail` VALUES ('13', '10');
INSERT INTO `sys_role_group_detail` VALUES ('13', '11');
INSERT INTO `sys_role_group_detail` VALUES ('13', '12');
INSERT INTO `sys_role_group_detail` VALUES ('13', '5');
INSERT INTO `sys_role_group_detail` VALUES ('12', '1');
INSERT INTO `sys_role_group_detail` VALUES ('12', '4');
INSERT INTO `sys_role_group_detail` VALUES ('12', '5');
INSERT INTO `sys_role_group_detail` VALUES ('12', '2');
INSERT INTO `sys_role_group_detail` VALUES ('12', '6');
INSERT INTO `sys_role_group_detail` VALUES ('12', '8');
INSERT INTO `sys_role_group_detail` VALUES ('12', '9');
INSERT INTO `sys_role_group_detail` VALUES ('12', '10');
INSERT INTO `sys_role_group_detail` VALUES ('12', '11');
INSERT INTO `sys_role_group_detail` VALUES ('12', '12');
INSERT INTO `sys_role_group_detail` VALUES ('15', '4');
INSERT INTO `sys_role_group_detail` VALUES ('15', '5');
INSERT INTO `sys_role_group_detail` VALUES ('15', '8');
INSERT INTO `sys_role_group_detail` VALUES ('15', '9');
INSERT INTO `sys_role_group_detail` VALUES ('15', '10');
INSERT INTO `sys_role_group_detail` VALUES ('15', '11');
INSERT INTO `sys_role_group_detail` VALUES ('15', '12');
INSERT INTO `sys_role_group_detail` VALUES ('6', '8');
INSERT INTO `sys_role_group_detail` VALUES ('6', '9');
INSERT INTO `sys_role_group_detail` VALUES ('6', '10');
INSERT INTO `sys_role_group_detail` VALUES ('6', '11');
INSERT INTO `sys_role_group_detail` VALUES ('6', '12');
INSERT INTO `sys_role_group_detail` VALUES ('7', '8');
INSERT INTO `sys_role_group_detail` VALUES ('7', '9');
INSERT INTO `sys_role_group_detail` VALUES ('7', '10');
INSERT INTO `sys_role_group_detail` VALUES ('7', '11');
INSERT INTO `sys_role_group_detail` VALUES ('7', '12');
