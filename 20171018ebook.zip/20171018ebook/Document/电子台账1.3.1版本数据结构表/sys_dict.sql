/*
Navicat MySQL Data Transfer

Source Server         : 172.30.103.14
Source Server Version : 50534
Source Host           : 172.30.103.14:3306
Source Database       : ebook

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2017-11-13 15:38:55
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `sys_dict`
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict`;
CREATE TABLE `sys_dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `value` varchar(64) DEFAULT NULL COMMENT '数据值',
  `label` varchar(64) DEFAULT NULL COMMENT '数据标签',
  `type` varchar(64) NOT NULL COMMENT '类型',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `select_type` varchar(16) DEFAULT NULL COMMENT '选择类型',
  `value_type` varchar(24) DEFAULT NULL COMMENT '数据类型',
  `required` tinyint(1) DEFAULT NULL COMMENT '是否必选',
  `remark` varchar(256) DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '创建者',
  `create_by` varchar(16) DEFAULT NULL COMMENT '修改时间',
  `update_by` varchar(16) DEFAULT NULL COMMENT '修改者',
  `del_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8 COMMENT='字典表';

-- ----------------------------
-- Records of sys_dict
-- ----------------------------
INSERT INTO `sys_dict` VALUES ('1', '00', '未知', 'age', '5', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('2', '01', '20岁以下', 'age', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('3', '02', '20-30岁', 'age', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('4', '03', '30-40岁', 'age', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('5', '04', '40-50岁', 'age', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('6', '05', '50岁以上', 'age', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('7', '01', '一房', 'apart_type', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('8', '02', '二房', 'apart_type', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('9', '03', '三房', 'apart_type', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('10', '04', '四房及以上', 'apart_type', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('11', '05', 'LOFT', 'apart_type', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('12', '06', 'SOHO', 'apart_type', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('13', '07', '临街商铺', 'apart_type', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('14', '08', '场内商铺', 'apart_type', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('15', '09', '办公间', 'apart_type', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('16', '10', '车位', 'apart_type', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('17', '11', '其他', 'apart_type', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('18', 'tezhengxinxi', '特征信息', 'default_attr_group', '1', null, null, null, '', null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('19', 'yixiangxinxi', '意向信息', 'default_attr_group', '2', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('20', 'huangpu', '黄浦区', 'district', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('21', 'xuhui', '徐汇区', 'district', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('22', 'changning', '长宁区', 'district', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('23', 'jingan', '静安区', 'district', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('24', 'putuo', '普陀区', 'district', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('25', 'hongkou', '虹口区', 'district', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('26', 'yangpu', '杨浦区', 'district', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('27', 'minxing', '闵行区', 'district', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('28', 'baoshan', '宝山区', 'district', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('29', 'jiading', '嘉定区', 'district', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('30', 'pudong', '浦东新区', 'district', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('31', 'jinshan', '金山区', 'district', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('32', 'songjiang', '松江区', 'district', '130', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('33', 'qingpu', '青浦区', 'district', '140', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('34', 'fengxian', '奉贤区', 'district', '150', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('35', 'zhabei', '闸北区', 'district', '160', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('36', 'luwan', '卢湾区', 'district', '170', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('37', 'chongming', '崇明县', 'district', '180', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('38', '0', '未知', 'gender', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('39', '1', '男', 'gender', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('40', '2', '女', 'gender', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('41', '08', '动迁换房', 'goufangyongtu', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('42', '07', '为子女(自己)结婚用', 'goufangyongtu', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('43', '06', '投资/保值', 'goufangyongtu', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('44', '01', '自用办公', 'goufangyongtu', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('45', '02', '首套自住', 'goufangyongtu', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('46', '03', '改善自住', 'goufangyongtu', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('47', '04', '为父母(自己)养老用', 'goufangyongtu', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('48', '05', '其他', 'goufangyongtu', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('49', '01', '300万元以下', 'goufangyusuan', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('50', '02', '300-500万元', 'goufangyusuan', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('51', '03', '500-800万元', 'goufangyusuan', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('52', '04', '800-1000万元', 'goufangyusuan', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('53', '05', '1000-1500万元', 'goufangyusuan', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('54', '06', '1500万元以上', 'goufangyusuan', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('55', '01', '间距', 'guanzhuyinsu', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('56', '02', '行业政策', 'guanzhuyinsu', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('57', '03', '装修风格', 'guanzhuyinsu', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('58', '04', '市场形势', 'guanzhuyinsu', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('59', '05', '装修标准', 'guanzhuyinsu', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('60', '06', '开发商品牌', 'guanzhuyinsu', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('61', '07', '装修品牌', 'guanzhuyinsu', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('62', '08', '物业管理', 'guanzhuyinsu', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('63', '09', '升值空间', 'guanzhuyinsu', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('64', '10', '小区成熟度', 'guanzhuyinsu', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('65', '11', '区位', 'guanzhuyinsu', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('66', '12', '小区规划', 'guanzhuyinsu', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('67', '13', '其他', 'guanzhuyinsu', '130', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('68', '14', '生活配套', 'guanzhuyinsu', '140', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('69', '15', '小区景观', 'guanzhuyinsu', '150', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('70', '16', '交通', 'guanzhuyinsu', '160', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('71', '17', '小区规模', 'guanzhuyinsu', '170', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('72', '18', '周边环境', 'guanzhuyinsu', '180', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('73', '19', '容积率', 'guanzhuyinsu', '190', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('74', '20', '学区环境', 'guanzhuyinsu', '200', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('75', '21', '得房率', 'guanzhuyinsu', '210', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('76', '22', '医院', 'guanzhuyinsu', '220', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('77', '23', '车位配置', 'guanzhuyinsu', '230', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('78', '24', '价格', 'guanzhuyinsu', '240', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('79', '25', '会所', 'guanzhuyinsu', '250', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('80', '26', '房型', 'guanzhuyinsu', '260', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('81', '27', '交房时间', 'guanzhuyinsu', '270', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('82', '28', '面积', 'guanzhuyinsu', '280', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('83', '29', '折扣', 'guanzhuyinsu', '290', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('84', '30', '采光', 'guanzhuyinsu', '300', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('85', '31', '付款方式', 'guanzhuyinsu', '310', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('86', '32', '朝向', 'guanzhuyinsu', '320', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('87', '33', '双限/贷款/融资', 'guanzhuyinsu', '330', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('88', '01', '矿产/地质/水利/能源', 'hangye', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('89', '02', '商业/贸易', 'hangye', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('90', '03', '政府/非盈利机构', 'hangye', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('91', '04', '交通/物流/仓储', 'hangye', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('92', '05', '市场/公关/广告/咨询/媒体', 'hangye', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('93', '06', '制造业', 'hangye', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('94', '07', '餐饮/旅游/服务', 'hangye', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('95', '08', '农/林/牧/渔', 'hangye', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('96', '09', '房地产/建筑/装修装饰', 'hangye', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('97', '10', '法律/司法/行政管理', 'hangye', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('98', '11', '科研/教育/文化/体育/艺术', 'hangye', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('99', '12', '计算机/互联网/通讯/电信', 'hangye', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('100', '13', '银行/保险/证券/投资/金融', 'hangye', '130', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('101', '14', '公用事业(水电气)', 'hangye', '140', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('102', '15', '医疗/护理/卫生', 'hangye', '150', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('103', '16', '其他', 'hangye', '160', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('104', 'name', '姓名', 'hexinxinxi', '10', 'text', null, '1', '{\"textType\":\"00\"}', null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('105', 'gender', '性别', 'hexinxinxi', '20', 'select', 'gender', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('106', 'age', '年龄段', 'hexinxinxi', '50', 'select', 'age', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('107', 'mobile', '联系方式', 'hexinxinxi', '30', 'text', null, '1', '{\"textType\":\"01\"}', null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('108', 'intentProject', '意向楼盘', 'hexinxinxi', '90', 'select', 'intent_project', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('109', 'intentLevel', '意向级别', 'hexinxinxi', '40', 'select', 'intent_level', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('110', 'intentApartType', '目标户型', 'hexinxinxi', '100', 'selectbox', 'intent_apart_type', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('111', 'remark', '客户描述', 'hexinxinxi', '110', 'textarea', null, '1', '{\"textType\":\"00\"}', null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('112', '01', '本地', 'hujizhuangkuang', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('113', '02', '外地', 'hujizhuangkuang', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('114', '03', '外籍', 'hujizhuangkuang', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('115', 'A', 'A', 'intent_level', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('116', 'B', 'B', 'intent_level', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('117', 'C', 'C', 'intent_level', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('118', 'D', 'D', 'intent_level', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('119', '01', '单身', 'jiatingjiegou', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('120', '02', '夫妻', 'jiatingjiegou', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('121', '03', '三口之家', 'jiatingjiegou', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('122', '04', '四口之家', 'jiatingjiegou', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('123', '05', '三代同堂', 'jiatingjiegou', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('124', '06', '多代同堂', 'jiatingjiegou', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('125', '01', '采光', 'kangxingyinsu', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('126', '02', '付款方式', 'kangxingyinsu', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('127', '03', '朝向', 'kangxingyinsu', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('128', '04', '双限/贷款/融资', 'kangxingyinsu', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('129', '05', '装修标准', 'kangxingyinsu', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('130', '06', '行业政策', 'kangxingyinsu', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('131', '07', '装修风格', 'kangxingyinsu', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('132', '08', '市场形势', 'kangxingyinsu', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('133', '09', '装修标准', 'kangxingyinsu', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('134', '10', '开发商品牌', 'kangxingyinsu', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('135', '11', '装修品牌', 'kangxingyinsu', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('136', '12', '物业管理', 'kangxingyinsu', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('137', '13', '区位', 'kangxingyinsu', '130', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('138', '14', '升值空间', 'kangxingyinsu', '140', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('139', '15', '小区成熟度', 'kangxingyinsu', '150', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('140', '16', '生活配套', 'kangxingyinsu', '160', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('141', '17', '小区规划', 'kangxingyinsu', '170', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('142', '18', '其他', 'kangxingyinsu', '180', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('143', '19', '交通', 'kangxingyinsu', '190', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('144', '20', '小区景观', 'kangxingyinsu', '200', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('145', '21', '周边环境', 'kangxingyinsu', '210', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('146', '22', '小区规模', 'kangxingyinsu', '220', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('147', '23', '学校', 'kangxingyinsu', '230', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('148', '24', '容积率', 'kangxingyinsu', '240', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('149', '25', '医院', 'kangxingyinsu', '250', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('150', '26', '得房率', 'kangxingyinsu', '260', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('151', '27', '价格', 'kangxingyinsu', '270', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('152', '28', '车位配置', 'kangxingyinsu', '280', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('153', '29', '房型', 'kangxingyinsu', '290', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('154', '30', '会所', 'kangxingyinsu', '300', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('155', '31', '面积', 'kangxingyinsu', '310', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('156', '32', '交房时间', 'kangxingyinsu', '320', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('157', '33', '楼层', 'kangxingyinsu', '330', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('158', '34', '折扣', 'kangxingyinsu', '340', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('159', '01', '住宅', 'property_type', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('160', '02', '别墅联排', 'property_type', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('161', '03', '酒店式公寓', 'property_type', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('162', '01', '车身广告', 'renzhitujing', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('163', '02', '同行转介', 'renzhitujing', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('164', '03', '房展会', 'renzhitujing', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('165', '04', '巡展', 'renzhitujing', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('166', '05', '拍单', 'renzhitujing', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('167', '06', '直接单页/信函', 'renzhitujing', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('168', '07', '移动网络', 'renzhitujing', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('169', '08', '账单', 'renzhitujing', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('170', '09', '互联网站', 'renzhitujing', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('171', '10', '短信', 'renzhitujing', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('172', '11', '电视', 'renzhitujing', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('173', '12', '已购朋友推荐', 'renzhitujing', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('174', '13', '广播', 'renzhitujing', '130', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('175', '14', '未购朋友推荐', 'renzhitujing', '140', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('176', '15', '报纸', 'renzhitujing', '150', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('177', '16', '中介', 'renzhitujing', '160', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('178', '17', '户外大牌', 'renzhitujing', '170', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('179', '18', '杂志', 'renzhitujing', '180', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('180', '19', '同策汇', 'renzhitujing', '190', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('181', '20', '道旗', 'renzhitujing', '200', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('182', '21', '户外高炮', 'renzhitujing', '210', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('183', '22', '工地围墙', 'renzhitujing', '220', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('184', '23', '交通指示牌', 'renzhitujing', '230', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('185', '24', '引导旗', 'renzhitujing', '240', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('186', '00', '文字', 'text_type', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('187', '00', '文字', 'text_type', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('188', '01', '数字', 'text_type', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('189', '01', '数字', 'text_type', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('190', 'jiatingjiegou', '家庭结构', 'hexinxinxi', '60', 'select', 'jiatingjiegou', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('191', 'renzhitujing', '认知途径', 'hexinxinxi', '70', 'selectbox', 'renzhitujing', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('192', 'hujizhuangkuang', '户籍状况', 'tezhengxinxi', '30', 'select', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('193', 'zhiye', '职业', 'tezhengxinxi', '40', 'select', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('194', 'gongzuoquyu', '工作区域', 'tezhengxinxi', '50', 'select', 'district', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('195', 'xianjuzhuquyu', '现居住区域', 'tezhengxinxi', '60', 'select', 'district', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('196', 'hangye', '行业', 'tezhengxinxi', '70', 'select', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('197', '01', '60平米以下', 'yixiangmianji', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('198', '02', '60-70平米', 'yixiangmianji', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('199', '03', '70-80平米', 'yixiangmianji', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('200', '04', '80-90平米', 'yixiangmianji', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('201', '05', '90-100平米', 'yixiangmianji', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('202', '06', '100-110平米', 'yixiangmianji', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('203', '07', '110-120平米', 'yixiangmianji', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('204', '08', '120-130平米', 'yixiangmianji', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('205', '09', '130-150平米', 'yixiangmianji', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('206', '10', '150-180平米', 'yixiangmianji', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('207', '11', '180-200平米', 'yixiangmianji', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('208', '12', '200平米以上', 'yixiangmianji', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('209', 'goufangyongtu', '购房用途', 'hexinxinxi', '80', 'selectbox', 'goufangyongtu', '1', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('210', 'goufangyusuan', '购房预算', 'yixiangxinxi', '20', 'select', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('211', 'kangxingyinsu', '抗性因素', 'yixiangxinxi', '30', 'selectbox', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('212', 'yixiangmianji', '意向面积', 'yixiangxinxi', '40', 'select', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('213', 'guanzhuyinsu', '关注因素', 'yixiangxinxi', '50', 'selectbox', 'custom', '0', null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('214', '01', '无职业', 'zhiye', '10', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('215', '02', '高级管理者', 'zhiye', '20', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('216', '03', '中层管理者', 'zhiye', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('217', '04', '一般职员', 'zhiye', '40', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('218', '05', '技术人员(工程师/程序员)', 'zhiye', '50', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('219', '06', '私人企业主', 'zhiye', '60', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('220', '07', '公务员', 'zhiye', '70', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('221', '08', '军人/警察/武警', 'zhiye', '80', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('222', '09', '教师/文艺工作者', 'zhiye', '90', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('223', '10', '医生/医务工作者', 'zhiye', '100', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('224', '11', '自由职业者', 'zhiye', '110', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('225', '12', '离退休人员', 'zhiye', '120', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('226', '13', '在校学生', 'zhiye', '130', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('227', '14', '其他', 'zhiye', '140', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('228', '04', '别墅叠加', 'property_type', '30', null, null, null, null, null, null, null, null, '0');
INSERT INTO `sys_dict` VALUES ('229', '05', '别墅独栋', 'property_type', '40', null, null, null, null, null, null, null, null, '0');
