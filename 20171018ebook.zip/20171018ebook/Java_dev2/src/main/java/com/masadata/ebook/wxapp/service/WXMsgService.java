package com.masadata.ebook.wxapp.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.common.util.DateUtils;
import com.masadata.ebook.customer.dao.CustomerDao;
import com.masadata.ebook.customer.entity.CustReport;
import com.masadata.ebook.customer.entity.Customer;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;
import com.masadata.ebook.wxapp.api.msg.RecvMsg;
import com.masadata.ebook.wxapp.api.msg.TextCustomMsg;
import com.masadata.ebook.wxapp.api.request.SendMessageRequest;
import com.masadata.ebook.wxapp.dao.CaseWXAppDao;
import com.masadata.ebook.wxapp.entity.CaseWXApp;

@Service
public class WXMsgService {
	@Autowired 
	CustomerDao custDao;
	@Autowired
	UserDao userDao;
	@Autowired
	CaseWXAppDao appDao;
	@Autowired
	AccessTokenService tokenService;
	
	public static final String WXAPP_ENCODING_AESKEY = "Q1W2E3!@#";
	//定时向绑定了身份的公众号用户推送日报消息
	@Scheduled(cron="0 0 8 ? * *")
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public void pushCustDailyReport() throws Exception {
		List<CustReport> yesterdayReport = custDao.getYesterdayCustReport();
		String yesterday = DateUtils.getYesterday();
		for(CustReport report : yesterdayReport) {
			if(!StringUtils.isEmpty(report.getOpenid())) {
				TextCustomMsg msg = new TextCustomMsg(report.getOpenid(), 
						String.format(AppConfig.PUSH_TEMPLATE_CUST_DAILY_REPORT, 
								report.getVisitors(), report.getMultiVisitVisitors(), report.getDealCustomers(), 
								getReportCustomerListPageUrl(AppConfig.VISITOR_LIST_URL, "" + report.getCaseId(), yesterday), 
								getReportCustomerListPageUrl(AppConfig.Multi_VISIT_VISITOR_LIST_URL, "" + report.getCaseId(), yesterday), 
								getReportCustomerListPageUrl(AppConfig.DEAL_CUSTOMER_LIST_URL, "" + report.getCaseId(), yesterday)));
				new SendMessageRequest(tokenService.getAccessToken("" + report.getCaseId()), msg.toMsgBody()).send();
			}
		}
	}
	
	public static final String WX_MSGTYPE_TEXT = "text";
	public static final String WX_MSGTYPE_EVENT = "event";
	public static final String WX_EVENT_SUBSCRIBE = "subscribe";
	public static final String WX_EVENT_CLICK = "click";
	public static final String WX_EVENTKEY_YESTERDAY_REPORT = "yesterday-report";
	public static final String WX_EVENTKEY_INCOMPLETE_LIST = "incomplete-list";
	
	private CaseWXApp getCaseWXAppInfoByCaseId(String caseId) {
		CaseWXApp app = appDao.getCaseWXAppInfo(caseId);
		if(app == null) {
			app = new CaseWXApp();
			app.setAppID(AppConfig.EBOOK_APP_ID);
			app.setAppSecret(AppConfig.EBOOK_APP_SECRET);
			app.setWebHost(AppConfig.EBOOK_WEB_HOST);
		}
		return app;
	}
	
	private String getAppPageUrl(String url, String caseId) throws UnsupportedEncodingException {
		url = url.replaceAll("\\{caseId\\}", caseId);
		CaseWXApp app = getCaseWXAppInfoByCaseId(caseId);
		url = url.replaceAll("\\{appid\\}", app.getAppID());
		url = url.replaceAll("\\{webserver\\}", URLEncoder.encode(app.getWebHost(), "utf-8"));
		return url;
	}
	private String getClientInfoPageUrl(String url, String caseId, int custId) throws UnsupportedEncodingException {
		url = getAppPageUrl(url, caseId);
		url = url.replaceAll("\\{id\\}", "" + custId);
		return url;
	}
	private String getReportCustomerListPageUrl(String url, String caseId, String statDate) throws UnsupportedEncodingException {
		url = getAppPageUrl(url, caseId);
		url = url.replaceAll("\\{statDate\\}", statDate);
		return url;
	}
	
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public void pushUserBindOKMsg(User user) throws Exception {
		TextCustomMsg msg = new TextCustomMsg(user.getOpenid(), String.format(AppConfig.PUSH_TEMPLATE_WXUSER_BINDED, getAppPageUrl(AppConfig.USER_INFO_URL, user.getCaseId())));
		new SendMessageRequest(tokenService.getAccessToken(user.getCaseId()), msg.toMsgBody()).send();
	}

	//客户来访登记的消息推送
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public void pushCustVisitMsg(Customer cust) throws Exception {
		String caseId = cust.getCaseId();
		String openid = cust.getConsultant() == null ? "" : userDao.getCaseUserOpenidByUser(cust.getConsultant(), caseId);
		if(StringUtils.isEmpty(openid)) {
			return ;
		} else {
			String custName = cust.getName() + (cust.getGender() == null ? "" : (cust.getGender() == 1 ? "先生" : "女士"));
			TextCustomMsg msg = new TextCustomMsg(openid, String.format(AppConfig.PUSH_TEMPLATE_CUST_VISIT_REGISTRY, custName, cust.getMobile(), cust.getMobile(), 
					getClientInfoPageUrl(AppConfig.CUSTOMER_INFO_URL, caseId, cust.getId())));
			new SendMessageRequest(tokenService.getAccessToken(caseId), msg.toMsgBody()).send();
		}
	}
	
	//公众号事件消息接收处理：1、昨日日报--删除；2、未补全信息；3、客户查询；4、关注提醒
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public void handle(RecvMsg recvMsg, String caseId) {
		User user = new User();
		user.setOpenid(recvMsg.getFromUserName());
		caseId = StringUtils.isEmpty(userDao.getUserBindedCaseByWXOpenID(recvMsg.getFromUserName())) ? "0" : userDao.getUserBindedCaseByWXOpenID(recvMsg.getFromUserName());
		user.setCaseId(caseId);
		String content = null;
		try {
			Integer adminFlag = StringUtils.isEmpty(user.getCaseId()) ? null : userDao.getUserAdminFlag(user);
			String msgType = recvMsg.getMsgType();
			if(WX_MSGTYPE_TEXT.equalsIgnoreCase(msgType)) {
				if(adminFlag == null) { //未验证人员，提醒一下
					content = String.format(AppConfig.PUSH_TEMPLATE_WXUSER_UNBINDED, getAppPageUrl(AppConfig.USER_INFO_URL, caseId));
				} else { //客户查询
					String mobile = recvMsg.getContent().trim();
					if(mobile.length() == 11) {
						Customer cust = null;
						if(adminFlag == 1) {
							cust = custDao.getCustInfoByMobileAndCaseAdmin(user, mobile);
						} else {
							cust = custDao.getCustInfoByMobileAndCaseWorker(user, mobile);
						}						
						if(cust == null) {
							content = AppConfig.PUSH_TEMPLATE_CUST_NOT_EXIST;
						} else { //推送客户信息
							content = String.format(AppConfig.PUSH_TEMPLATE_CUST_INFO,getClientInfoPageUrl(AppConfig.CUSTOMER_INFO_URL, caseId,cust.getId()) ,cust.getName(), cust.getStatus(), cust.getLastRecordDate(), cust.getConsultantName(), cust.getConsultantNo());
						}
					}
				}
			} else if(WX_MSGTYPE_EVENT.equalsIgnoreCase(msgType)) {
				String event = recvMsg.getEvent();
				if(WX_EVENT_SUBSCRIBE.equalsIgnoreCase(event)) { //订阅信息推送
					if(adminFlag == null) {
						content = String.format(AppConfig.PUSH_TEMPLATE_WXUSER_SUBSCRIBE, "电子台账", getAppPageUrl(AppConfig.USER_INFO_URL, caseId));
					} else {
						content = String.format(AppConfig.PUSH_TEMPLATE_WXUSER_BINDED, getAppPageUrl(AppConfig.USER_INFO_URL, caseId));
					}
				} else if(WX_EVENT_CLICK.equalsIgnoreCase(event)) {
					if(adminFlag == null) { //未验证人员，提醒一下
						content = String.format(AppConfig.PUSH_TEMPLATE_WXUSER_UNBINDED, getAppPageUrl(AppConfig.USER_INFO_URL, caseId));
					} else { // click菜单事件处理
						String eventKey = recvMsg.getEventKey();
						if(WX_EVENTKEY_INCOMPLETE_LIST.equalsIgnoreCase(eventKey)) { //未补全信息菜单点击
							int incompleteSize = 0;
							if(adminFlag == 0) {
								incompleteSize = custDao.getIncompleteVisitorCount(user);
							} else {
								incompleteSize = custDao.getIncompleteVisitorCountByAdmin(user);
							}
							content = String.format(AppConfig.PUSH_TEMPLATE_INCOMPLETE_LIST, incompleteSize, getAppPageUrl(AppConfig.INCOMPLETE_LIST_URL, caseId));
						} /*else if(WX_EVENTKEY_YESTERDAY_REPORT.equalsIgnoreCase(eventKey)) { //昨日日报菜单点击--该事件菜单删除
							CustReport report = custDao.getYesterdayCustReportByUser(user);
							if(report == null) {
								report = new CustReport();
							}
							report.setStatDate(DateUtils.getYesterday());
							content = String.format(AppConfig.PUSH_TEMPLATE_CUST_DAILY_REPORT, 
									report.getVisitors(), report.getMultiVisitVisitors(), report.getDealCustomers(), 
									getReportCustomerListPageUrl(AppConfig.VISITOR_LIST_URL, "" + user.getCaseId(), report.getStatDate()), 
									getReportCustomerListPageUrl(AppConfig.Multi_VISIT_VISITOR_LIST_URL, "" + user.getCaseId(), report.getStatDate()), 
									getReportCustomerListPageUrl(AppConfig.DEAL_CUSTOMER_LIST_URL, "" + user.getCaseId(), report.getStatDate()));
						}*/
					}
				}
			}
			if(!StringUtils.isEmpty(content)) { //推送消息
				TextCustomMsg msg = new TextCustomMsg(user.getOpenid(), content);
				new SendMessageRequest(tokenService.getAccessToken(caseId), msg.toMsgBody()).send();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public String authWXAppServerUrl(String signature, String nonce, String timestamp, String echostr) {
		try {
			List<String> list = new ArrayList<String>();
			list.add(nonce);
			list.add(timestamp);
			list.add(AppConfig.WXAPP_SERVER_AUTH_TOKEN);
			Collections.sort(list);
			if(signature.equalsIgnoreCase(DigestUtils.sha1Hex(list.get(0)+list.get(1)+list.get(2)))) {
				return echostr;
			} else {
				return "error";
			}
		} catch(Exception e) {
			e.printStackTrace();
			return "";
		}
	}

}
