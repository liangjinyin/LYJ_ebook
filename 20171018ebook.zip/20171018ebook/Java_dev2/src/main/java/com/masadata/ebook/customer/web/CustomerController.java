package com.masadata.ebook.customer.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.web.BaseController;
import com.masadata.ebook.customer.entity.Customer;
import com.masadata.ebook.customer.service.CustomerService;
import com.masadata.ebook.user.entity.User;

@RestController
@RequestMapping(value="${server.apiPath}/wxapp/customer", method={RequestMethod.POST})
public class CustomerController extends BaseController {

	@Autowired
	private CustomerService custService;
	
	@RequestMapping("/incomplete-visitor-list")
	public String getIncompleteVisitorList(User user, @RequestParam("rowNum") Integer rowNum) {
		if(rowNum == null) {
			rowNum = 0;
		}
		data = custService.getIncompleteVisitorList(user, rowNum);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/visitor-list")
	public String getVisitorList(User user, @RequestParam("rowNum") Integer rowNum, @RequestParam(name="statDate", required=false) String statDate) {
		data = custService.getVisitorList(user, rowNum, statDate);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/multi-visit-list")
	public String getMultiVisitVisitorList(User user, @RequestParam("rowNum") Integer rowNum, @RequestParam(name="statDate", required=false) String statDate) {
		data = custService.getMultiVisitVisitorList(user, rowNum, statDate);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/deal-list")
	public String getDealCustList(User user, @RequestParam("rowNum") Integer rowNum, @RequestParam(name="statDate", required=false) String statDate) {
		data = custService.getDealCustList(user, rowNum, statDate);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/list")
	public String getCustList(User user, @RequestParam("rowNum") Integer rowNum,@RequestParam("status") String status) {
		data = custService.getCustList(user, rowNum,status);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/visit-list")
	public String getCustVisitList(User user, @RequestParam("rowNum") Integer rowNum) {
		data = custService.getCustVisitList(user, rowNum);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/add")
	public String addCust(User user, Customer cust) {
		try {
			retCode = custService.addCust(user, cust);
		} catch(Exception e) {
			e.printStackTrace();
			retCode = ResultCode.OPERATION_FAILED;
		}
		data = null;
		return result();
	}
	
	@RequestMapping("/detail")
	public String getCustDetail(User user, @RequestParam("id") String id) {
		try {
			data = custService.getCustDetail(user, id);
			if(data instanceof ResultCode) {
				retCode = (ResultCode) data;
				data = null;
			} else {
				retCode = ResultCode.OPERATION_SUCCESSED;
			}
		} catch(Exception e) {
			retCode = ResultCode.OPERATION_SUCCESSED;
			data = null;
			e.printStackTrace();
		}
		return result();
	}
	
	@RequestMapping("/save")
	public String saveCustDetail(User user, Customer cust) {
		try {
			retCode = custService.saveCustDetail(user, cust);
		} catch(Exception e) {
			e.printStackTrace();
			retCode = ResultCode.OPERATION_FAILED;
		}
		data = null;
		return result();
	}
	
	@RequestMapping("/del")
	public String delCust(User user, @RequestParam("id") String id) {
		retCode = custService.delCust(user, id);
		data = null;
		return result();
	}
	
	@RequestMapping(path="/report", method=RequestMethod.GET)
	public String getCustReport(User user, @RequestParam("rowNum") Integer rowNum) {
		try {
			if(rowNum == null) {
				rowNum = 0;
			}
			data = custService.getCustReport(user, rowNum);
			retCode = ResultCode.OPERATION_SUCCESSED;
		} catch(Exception e) {
			e.printStackTrace();
			data = null;
			retCode = ResultCode.OPERATION_FAILED;
		}
		return result();
	}
	/**
	 * 
	 * @param user 当前用户的openid，caseid
	 * @param id 意向楼盘id
	 * @return 意向楼盘下面的目标户型
	 * @throws Exception
	 */
	@RequestMapping(path="/getApartTypeLabel")
	public String getApartTypeLabelByProj(User user, @RequestParam Integer pid){
		
		try {
			if(pid==null){
				pid=0;
			}
			data = custService.getApartTypeLabelByProj(user,pid);
			retCode = ResultCode.OPERATION_SUCCESSED;
		} catch (Exception e) {
			e.printStackTrace();
			data = null;
			retCode = ResultCode.OPERATION_FAILED;
		}
		return result();
	}
}
