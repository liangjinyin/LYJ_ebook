package com.masadata.ebook.customer.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.util.DateUtils;
import com.masadata.ebook.common.util.NumberUtils;
import com.masadata.ebook.common.util.PinYinUtils;
import com.masadata.ebook.customer.dao.CaseDao;
import com.masadata.ebook.customer.dao.CustomerDao;
import com.masadata.ebook.customer.entity.CustAttr;
import com.masadata.ebook.customer.entity.CustReport;
import com.masadata.ebook.customer.entity.CustStatusRecord;
import com.masadata.ebook.customer.entity.Customer;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;
import com.masadata.ebook.wxapp.service.WXMsgService;

@Service
@Transactional(readOnly=true)
public class CustomerService {

	@Autowired
	private CustomerDao custDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private CaseDao caseDao;
	@Autowired
	WXMsgService msgService;
	
	public static final String CUST_STATUS_CALL = "来电";
	public static final String CUST_STATUS_VISITOR = "到访";
	public static final String CUST_STATUS_DEAL = "成交";
	public static final String CUST_INTENT_LEVEL_D = "D";
	public static final String CUST_INTENT_LEVEL_C = "C";
	public static final String CUST_INTENT_LEVEL_B = "B";
	public static final String CUST_INTENT_LEVEL_A = "A";
	public static final String ATTR_TYPE_SELECT = "select";
	public static final String ATTR_TYPE_SELECTBOX = "selectbox";
	public static final String DEFAULT_LAST_NAME_FIRST_LETTER = "#";
	public static final String DEFAULT_AGE = "00";
	
	
	/*
	 * 获取未补全到访客户列表
	 */
	public Map<String, Object> getIncompleteVisitorList(User user, int rowNum) {
		Map<String, Object> data = new HashMap<String, Object>();
		List<Map<String, Object>> list = null;
		int total = 0, remain = 0;
		if(isCaseAdmin(user)) {
			list = custDao.getIncompleteVisitorListByAdmin(user, rowNum, AppConfig.PAGE_SIZE);
			total = custDao.getIncompleteVisitorCountByAdmin(user);
		} else {
			list = custDao.getIncompleteVisitorList(user, rowNum, AppConfig.PAGE_SIZE);
			total = custDao.getIncompleteVisitorCount(user);
		}
		remain = total - rowNum - list.size();
		data.put("list", list);
		data.put("total", list.size());
		data.put("remain", remain);
		return data;
	}
	
	/*
	 * 获取到访客户列表
	 */
	public Map<String, Object> getVisitorList(User user, int rowNum, String statDate) {
		Map<String, Object> data = new HashMap<String, Object>();
		List<Map<String, Object>> list = null;
		int total = 0, remain = 0;
		if(isCaseAdmin(user)) {
			list = custDao.getVisitorListByAdmin(user, rowNum, AppConfig.PAGE_SIZE, statDate);
			total = custDao.getVisitorCountByAdmin(user, statDate);
		} else {
			list = custDao.getVisitorList(user, rowNum, AppConfig.PAGE_SIZE, statDate);
			total = custDao.getVisitorCount(user, statDate);
		}
		remain = total - rowNum - list.size();
		data.put("list", list);
		data.put("total", list.size());
		data.put("remain", remain);
		return data;
	}
	
	/*
	 * 获取多次到访客户列表
	 */
	public Map<String, Object> getMultiVisitVisitorList(User user, int rowNum, String statDate) {
		Map<String, Object> data = new HashMap<String, Object>();
		List<Map<String, Object>> list = null;
		int total = 0, remain = 0;
		if(isCaseAdmin(user)) {
			list = custDao.getMultiVisitVisitorListByAdmin(user, rowNum, AppConfig.PAGE_SIZE, statDate);
			total = custDao.getMultiVisitVisitorCountByAdmin(user, statDate);
		} else {
			list = custDao.getMultiVisitVisitorList(user, rowNum, AppConfig.PAGE_SIZE, statDate);
			total = custDao.getMultiVisitVisitorCount(user, statDate);
		}
		remain = total - rowNum - list.size();
		data.put("list", list);
		data.put("total", list.size());
		data.put("remain", remain);
		return data;
	}
	
	/*
	 * 获取成交客户列表
	 */
	public Map<String, Object> getDealCustList(User user, int rowNum, String statDate) {
		Map<String, Object> data = new HashMap<String, Object>();
		List<Map<String, Object>> list = null;
		int total = 0, remain = 0;
		if(isCaseAdmin(user)) {
			list = custDao.getDealCustListByAdmin(user, rowNum, AppConfig.PAGE_SIZE, statDate);
			total = custDao.getDealCustCountByAdmin(user, statDate);
		} else {
			list = custDao.getDealCustList(user, rowNum, AppConfig.PAGE_SIZE, statDate);
			total = custDao.getDealCustCount(user, statDate);
		}
		remain = total - rowNum - list.size();
		data.put("list", list);
		data.put("total", list.size());
		data.put("remain", remain);
		return data;
	}
	
	/*
	 * 获取客户列表，按日期排序
	 */
	public Map<String, Object> getCustList(User user, int rowNum,String status) {
		Map<String, Object> data = new LinkedHashMap<String, Object>();
		boolean isAdmin = isCaseAdmin(user);
		if(!StringUtils.isEmpty(user.getName())) {
			if(NumberUtils.isNumeric(user.getName())) {
				user.setMobile(user.getName());
			}
		}
		List<Map<String, Object>> custList = null;
		Map<String, List<Map<String, Object>>> list = new LinkedHashMap<String, List<Map<String, Object>>>();
		int total = 0, remain = 0, all = 0;
		if(isAdmin) {
			custList = custDao.getCustListByAdminWithNameOrMobile(user, rowNum, AppConfig.PAGE_SIZE,status);
			all = custDao.getCustCountByAdminWithNameOrMobile(user,status);
		} else {
			custList = custDao.getCustListByNameOrMobile(user, rowNum, AppConfig.PAGE_SIZE,status);
			all = custDao.getCustCountByNameOrMobile(user,status);
		}
		total = custList.size();
		remain = all - total - rowNum;
		/*for(Map<String, Object> cust : custList) {
			String firstLetter = (String) cust.get("firstLetter");
			if(list.containsKey(firstLetter)) {
				list.get(firstLetter).add(cust);
			} else {
				List<Map<String, Object>> newList = new ArrayList<Map<String, Object>>();
				newList.add(cust);
				list.put(firstLetter, newList);
			}
		}*/
		for(Map<String, Object> cust : custList) {
			String recordDate = (String) cust.get("recordDate");
			if(list.containsKey(recordDate)) {
				list.get(recordDate).add(cust);
			} else {
				List<Map<String, Object>> newList = new ArrayList<Map<String, Object>>();
				newList.add(cust);
				list.put(recordDate, newList);
			}
		}
		data.put("list", list);
		data.put("total", total);
		data.put("remain", remain);
		return data;
	}
	
	/*
	 * 获取客户访问记录，按天汇总并排序
	 */
	public Map<String, Object> getCustVisitList(User user, int rowNum) {
		Map<String, Object> data = new HashMap<String, Object>();
		Map<String, List<Map<String, Object>>> list = new LinkedHashMap<String, List<Map<String, Object>>>();
		int total = 0, remain = 0, all = 0;
		List<Map<String, Object>> visitList = null;
		if(isCaseAdmin(user)) {
			visitList = custDao.getAllVisitListByAdmin(user, rowNum, AppConfig.PAGE_SIZE);
			all = custDao.getAllVisitCountByAdmin(user);
		} else {
			visitList = custDao.getAllVisitList(user, rowNum, AppConfig.PAGE_SIZE);
			all = custDao.getAllVisitCount(user);
		}
		total = visitList.size(); 
		remain = all - rowNum - total;
		data.put("total", total);
		data.put("remain", remain);
		for(Map<String, Object> record : visitList) {
			String visitDate = (String) record.get("visitDate");
			if(list.containsKey(visitDate)) {
				list.get(visitDate).add(record);
			} else {
				List<Map<String, Object>> newList = new ArrayList<Map<String, Object>>();
				newList.add(record);
				list.put(visitDate, newList);
			}
		}
		data.put("list", list);
		return data;
	}
	
	/*
	 * 新建客户
	 */
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode addCust(User user, Customer cust) throws Exception {
		//手机号、姓名、性别等数据是否为空，以及格式验证 略
		if(StringUtils.isEmpty(cust.getMobile())) {
			return ResultCode.CUST_MOBILE_EMPTY;
		}

		//检查客户信息：手机号是否存在
		if(custDao.checkCustMobileExist(user, cust.getMobile()) > 0) {
			return ResultCode.CUST_MOBILE_EXIST;
		}
		User consultant = null;
		//如果是管理员，需判断填写的置业顾问是否存在，并设置接待人员
		if(isCaseAdmin(user)) {
			if(StringUtils.isEmpty(cust.getConsultantNo())) {
				consultant = userDao.getUserByWXOpenID(user);
			} else {
				consultant = userDao.getUserByCaseIdAndUserNo(user.getCaseId(), cust.getConsultantNo());
			}
		} else { //不是案场管理员，则自己就是接待人员
			consultant = userDao.getUserByWXOpenID(user);
		}
		if(consultant != null) {
			cust.setConsultant(consultant.getId());
			cust.setConsultantName(consultant.getName());
			cust.setConsultantNo(consultant.getNo());
		} else {
			return ResultCode.CUST_CONSULTANT_NOTEXIST;
		}
		cust.setCaseId(user.getCaseId());
		cust.setCreateBy("" + userDao.getUserByWXOpenID(user).getId());
		cust.setCreateTime(new Date());
		cust.setUpdateBy(cust.getCreateBy());
		cust.setUpdateTime(cust.getCreateTime());
		cust.setLastRecordDate(DateUtils.formatDate(cust.getCreateTime()));
		//取得客户姓名拼音首字母
		cust.setFirstLetter(PinYinUtils.getLastNameFirstLetter(cust.getName(), DEFAULT_LAST_NAME_FIRST_LETTER));
		cust.setAge(DEFAULT_AGE);
		//添加的客户状态 来电，意向楼盘 本案场
		cust.setStatus(cust.getStatus());
		Map<String, String> oneProject = caseDao.getCaseOneProjectByCaseId(user.getCaseId());
		cust.setIntentProject(oneProject.get("id"));
		cust.setIntentProjectLabel(oneProject.get("name"));
		//默认配置：意向等级 D，到访次数、成交次数置为0
		cust.setIntentLevel(CUST_INTENT_LEVEL_D);
		cust.setVisits(0);
		cust.setDeals(0);
		
		//保存信息，并增加客户状态记录
		if(custDao.addCust(cust) > 0) {
			CustStatusRecord record = new CustStatusRecord();
			record.setCustId(cust.getId());
			record.setRecordTime(DateUtils.formatDateTimeMinute(cust.getCreateTime()));
			record.setStatus(cust.getStatus());
			record.setCreateBy(cust.getCreateBy());
			record.setUpdateBy(cust.getCreateBy());
			if(cust.getStatus().equals(CustomerService.CUST_STATUS_VISITOR)){
				record.setVisitType(2);
			}else{
				record.setVisitType(1);
			}
			custDao.insertCustStatusRecord(record);//增加客户状态记录
			updateCustCompletion(cust.getId(), user.getCaseId());//计算客户信息完整度
			//更新状态/到访次数/成交次数 ，更新时间
			updateTimeAndStatus(cust);
			//增加推送接待信息
				msgService.pushCustVisitMsg(cust);
			return ResultCode.OPERATION_SUCCESSED;
		} else {
			return ResultCode.OPERATION_FAILED;
		}
	}
	
	/*
	 * 客户详情
	 */

	public Object getCustDetail(User user, String id) {
		if(!checkCustExistOrNot(user, id)) {
			return ResultCode.OPERATION_NOT_PERMITTED;
		}
		Map<String, Object> detail = custDao.getCustDetail(id);
		//增加 楼盘项目列表 intentProjectList
		List<Map<String, Object>> intentProjectList = caseDao.getProjectList(user.getCaseId());
		Map<String, Object> map = new HashMap<String, Object>(); 
		//改变意向房型的选择值为数组 intentApartType
		map.put("intentApartTypeList" , caseDao.getCaseApartTypeListByCaseId(user.getCaseId()));
		intentProjectList.add(map);
		//增加家庭结构列表 familyFormationList
		List<Map<String, Object>> familyFormationList = caseDao.getFamilyFormationList();
		//增加认知途径列表 knowWayList
		List<Map<String, Object>> knowWayList = caseDao.getKnowWayList();
		//增加购房用途列表 purchaseUseList
		List<Map<String, Object>> purchaseUseList = caseDao.getPurchaseUseList();
		
		detail.put("familyFormationList", familyFormationList);
		detail.put("knowWayList", knowWayList);
		detail.put("purchaseUseList", purchaseUseList);
		detail.put("intentProjectList", intentProjectList);
		detail.put("intentApartTypeList" , caseDao.getCaseApartTypeListByCaseId(user.getCaseId()));
		
		//detail.put("intentApartTypeList", caseDao.getCaseApartTypeListByCaseId(user.getCaseId()));
		//添加标签显示
		detail.put("familyFormation", (StringUtils.isEmpty(detail.get("familyFormation")) ? new String() : ((String)detail.get("familyFormation"))));
		detail.put("familyFormationLabel", (StringUtils.isEmpty(detail.get("familyFormationLabel")) ? "未选择" : detail.get("familyFormationLabel")));
		detail.put("knowWay", (StringUtils.isEmpty(detail.get("knowWay")) ? new String[]{} : ((String)detail.get("knowWay")).split(",")));
		detail.put("knowWayLabel", (StringUtils.isEmpty(detail.get("knowWayLabel")) ? "未选择" : detail.get("knowWayLabel")));
		detail.put("purchaseUse", (StringUtils.isEmpty(detail.get("purchaseUse")) ? new String[]{} : ((String)detail.get("purchaseUse")).split(",")));
		detail.put("purchaseUseLabel", (StringUtils.isEmpty(detail.get("purchaseUseLabel")) ? "未选择" : detail.get("purchaseUseLabel")));
		detail.put("intentApartType", (StringUtils.isEmpty(detail.get("intentApartType")) ? new String[]{} : ((String)detail.get("intentApartType")).split(",")));
		detail.put("intentApartTypeLabel", (StringUtils.isEmpty(detail.get("intentApartTypeLabel")) ? "未选择" : detail.get("intentApartTypeLabel")));
		//处理分组维度信息 attrGroups
		List<Map<String, Object>> attrGroups = caseDao.getCaseCustAttrGroupAndDetail(user.getCaseId());
		List<CustAttr> custAttrs = custDao.getCustAttrs(id);
		for(Map<String, Object> attrGroup : attrGroups) { //遍历分组
			//List<Map<String, Object>> attrs = (List<Map<String, Object>>) attrGroup.get("attrs");
			List<Map<String, Object>> attrs = caseDao.getCaseCustAttrByGroup((int)attrGroup.get("id"));
			for(Map<String, Object> attr : attrs) {  //遍历维度
				boolean attrHasValue = false;
				String attrType = (String) attr.get("type");
				for(CustAttr custAttr : custAttrs) { //可选的维度和客户已选择值的维度匹配，并根据维度类型设置值
					if(custAttr.getId() == (int)attr.get("id")) {
						if(!StringUtils.isEmpty((String)custAttr.getValue())) {
							if(ATTR_TYPE_SELECTBOX.equalsIgnoreCase(attrType)) { //多选的维度值用数组格式
								attr.put("value", "");
								String values = caseDao.checkAttrOption(custAttr.getId(), ((String)custAttr.getValue()).split(","));
								if(!StringUtils.isEmpty(values)) {
									attr.put("value", values.split(","));
								}
							} else {
								attr.put("value", custAttr.getValue());
							}
						}
						attr.put("valueLabel", StringUtils.isEmpty(custAttr.getValueLabel()) ? "未选择" : custAttr.getValueLabel());
						custAttrs.remove(custAttr);//匹配成功的，从custAttrs中移除，避免下次循环又扫描一次
						attrHasValue = true;
						break ;
					}
				}
				if(!attrHasValue) { //没匹配成功，设置默认为未选择
					if(ATTR_TYPE_SELECTBOX.equalsIgnoreCase(attrType)) { //多选的维度值用数组格式
						attr.put("value", new String[] {});
					} else {
						attr.put("value","");
					}
					attr.put("valueLabel", "未选择");
				}
				attr.put("options", caseDao.getCaseCustAttrOptions((int)attr.get("id"))); 
			}
			attrGroup.put("attrs", attrs);
		}
		detail.put("attrGroups", attrGroups);
		detail.put("visitList", custDao.getCustVisitList(id));
		detail.put("dealList", custDao.getCustDealList(id));
		return detail;
	}
	
	/*
	 * 计算客户信息完整度
	 */
	public void updateCustCompletion(int custId, String caseId) {
		int allItem = 0, hasItem = 0;
		Map<String, Object> detail = custDao.getCustDetail("" + custId);
		//核心信息
		if(!StringUtils.isEmpty(detail.get("name"))) {
			++hasItem;
		}
		++allItem;
		if(detail.get("gender") != null) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("age"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("mobile"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("intentProject"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("intentLevel"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("intentApartType"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("familyFormation"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("knowWay"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("purchaseUse"))) {
			++hasItem;
		}
		++allItem;
		if(!StringUtils.isEmpty(detail.get("remark"))) {
			++hasItem;
		}
		++allItem;
		//其他可选维度信息
		/*List<CustAttr> caseAttrs = caseDao.getCaseCustAttrList(caseId);
		List<Integer> requiredAttrs = new ArrayList<Integer>();
		for(CustAttr caseAttr : caseAttrs) {
			if( 1 == caseAttr.getRequired() ) {
				++allItem;
				requiredAttrs.add(caseAttr.getId());
			}
		}
		List<CustAttr> attrs = custDao.getCustAttrs("" + custId);
		if(attrs != null) {
			for(CustAttr attr : attrs) {
				if(requiredAttrs.contains(attr.getId()) && !StringUtils.isEmpty(attr.getValue())) {
					++hasItem;
				}
			}
		}*/
		String completion = Math.round(hasItem * 100.0 / allItem) + "%";
		custDao.updateCustCompletion(custId, completion);
	}
	
	/*
	 * 内部使用：验证用户是否访问的客户是否存在或是否有权限操作
	 */
	private boolean checkCustExistOrNot(User user, String id) {
		if(StringUtils.isEmpty(id)) {
			return false;
		}
		boolean exist = true;
		if(isCaseAdmin(user)) {
			if(custDao.checkCustExistByAdmin(user, id) == 0) {
				exist = false;
			}
		} else {
			if(custDao.checkCustExist(user, id) == 0) {
				exist = false;
			}
		}
		return exist;
	}
	/*
	 * 内部使用：用户在案场是否为管理员权限
	 */
	private boolean isCaseAdmin(User user) {
		if(userDao.getUserAdminFlag(user) == 1) {
			return true;
		} else {
			return false;
		}
	}
	
	/*
	 * 保存客户详情
	 */
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode saveCustDetail(User user, Customer cust) {
		
		if(!checkCustExistOrNot(user, "" + cust.getId())) {
			return ResultCode.OPERATION_NOT_PERMITTED;
		}
		Map<String, Object> old = custDao.getCustDetail("" + cust.getId());
		if(!cust.getMobile().equalsIgnoreCase((String)old.get("mobile")) && custDao.checkCustMobileExist(user, cust.getMobile()) > 0) {
			return ResultCode.CUST_MOBILE_EXIST;
		}
		user = userDao.getUserByWXOpenID(user);
		cust.setUpdateBy("" + user.getId());
		if(StringUtils.isEmpty(cust.getName())) {
			cust.setName((String)old.get("name"));
		}
		cust.setFirstLetter(PinYinUtils.getLastNameFirstLetter(cust.getName(), DEFAULT_LAST_NAME_FIRST_LETTER));
		if(StringUtils.isEmpty(cust.getMobile())) {
			cust.setMobile((String)old.get("mobile"));
		}
		if(StringUtils.isEmpty(cust.getRemark())) {
			cust.setRemark((String)old.get("remark"));
		}
		if(StringUtils.isEmpty(cust.getGender())) {
			cust.setGender((int)old.get("gender"));
		}
		//验证年龄字段 略
		if(StringUtils.isEmpty(cust.getAge())) {
			cust.setAge((String)old.get("age"));
		}
		//意向级别 ABCD值验证  略
		if(StringUtils.isEmpty(cust.getIntentLevel())) {
			cust.setIntentLevel((String)old.get("intentLevel"));
		}
		//校验意向楼盘，更新意向楼盘显示值
		if(StringUtils.isEmpty(cust.getIntentProject())) {
			cust.setIntentProjectLabel("未选择");
		} else {
			if(caseDao.checkCaseProjectExist(user.getCaseId(), cust.getIntentProject()) == 0) {
				cust.setIntentProject(caseDao.getCaseOneProjectByCaseId(user.getCaseId()).get("id"));
			}
			cust.setIntentProjectLabel(caseDao.getCaseProjectById(cust.getIntentProject()));
		}
		//校验家庭结构，更新家庭结构显示值
		if(StringUtils.isEmpty(cust.getFamilyFormation())) {
			cust.setFamilyFormationLabel("未选择");
		} else {
			String familyFormation = custDao.getFamilyFormationLabel(cust.getFamilyFormation());
			if(familyFormation!=null){
				cust.setFamilyFormationLabel(familyFormation);
			}else{
				cust.setFamilyFormationLabel("未选择");
			}
		}
		//校验意向房型，更新意向房型显示值
		if(!StringUtils.isEmpty(cust.getIntentApartType())) {
			String[] apartTypeList = cust.getIntentApartType().split(",");
			String apartTypeLists = caseDao.checkApartTypes(user.getCaseId(),cust.getIntentProject(),apartTypeList);
			cust.setIntentApartType(apartTypeLists);
			apartTypeList = apartTypeLists.split(",");
			if(apartTypeList.length > 0 && !StringUtils.isEmpty(apartTypeList[0])) {
				cust.setIntentApartTypeLabel(caseDao.getApartTypeLabel(user.getCaseId(), apartTypeList[0]));
			} else {
				cust.setIntentApartTypeLabel("未选择");
			}
		} else {
			cust.setIntentApartTypeLabel("未选择");
		}
		//校验认知途径，更新认知途径显示值
		if(!StringUtils.isEmpty(cust.getKnowWay())) {
			String[] knowWayList = cust.getKnowWay().split(",");
			cust.setKnowWay(cust.getKnowWay());
			if(knowWayList.length > 0 && !StringUtils.isEmpty(knowWayList[0])) {
				cust.setKnowWayLabel(custDao.getKnowWayLabel(knowWayList[0]));
			} else {
				cust.setKnowWayLabel("未选择");
			}
		} else {
			cust.setKnowWayLabel("未选择");
		}
		//校验购房用途，更新购房用途显示值
		if(!StringUtils.isEmpty(cust.getPurchaseUse())) {
			String[] purchaseUseList = cust.getPurchaseUse().split(",");
			cust.setPurchaseUse(cust.getPurchaseUse());
			if(purchaseUseList.length > 0 && !StringUtils.isEmpty(purchaseUseList[0])) {
				cust.setPurchaseUseLabel(custDao.getPurchaseUseLabel(purchaseUseList[0]));
			} else {
				cust.setPurchaseUseLabel("未选择");
			}
		} else {
			cust.setPurchaseUseLabel("未选择");
		}
		//成交房型数据校验
		if(cust.getDealList() != null && cust.getDealList().size() > 0) {
			for(CustStatusRecord dealRecord : cust.getDealList()) {
				if(StringUtils.isEmpty(dealRecord.getRecordTime())) {
					continue ;
				}
				if(!StringUtils.isEmpty(dealRecord.getDealApartType())) {
					String dealApartType = caseDao.checkApartType(user.getCaseId(), dealRecord.getDealApartType().split(","));
					dealRecord.setDealApartType(dealApartType);
					if(!StringUtils.isEmpty(dealApartType)) {
						dealRecord.setDealApartTypeLabel(caseDao.getApartTypeLabel(user.getCaseId(), dealRecord.getDealApartType()));
					}
				}
			}
		}
		//记录并验证各维度属性数据
		if(cust.getAttrs() != null) {
			for(CustAttr attr : cust.getAttrs()) {
				if(!StringUtils.isEmpty(attr.getValue())) {
					CustAttr caseAttr = caseDao.getCaseCustAttrById(attr.getId());
					if(caseAttr == null) {//客户维度信息有变更，页面需要重新刷新
						return ResultCode.FORM_NOT_LATESTED;
					}
					if(!StringUtils.isEmpty(attr.getValue())) {
						if(ATTR_TYPE_SELECT.equalsIgnoreCase(caseAttr.getType()) && attr.getValue().split(",").length > 1) {
							return ResultCode.CUST_ATTR_VALUE_NOTSUPPORTED;
						}
						/*if(attr.getValue().split(",").length != caseDao.checkAttrOption(attr.getId(), attr.getValue().split(","))) {
							return ResultCode.CUST_ATTR_VALUE_NOTSUPPORTED;
						}*/
						//修正错误的维度值
						attr.setValue(caseDao.checkAttrOption(attr.getId(), attr.getValue().split(",")));
					}
				}
			}
		}
		if(custDao.updateCust(cust) > 0) {
			//记录客户访问记录
			custDao.deleteCustVisitRecord(cust.getId());
			if(cust.getVisitList() != null && cust.getVisitList().size() > 0) {
				for(CustStatusRecord record : cust.getVisitList()) {
					if(record == null || StringUtils.isEmpty(record.getRecordTime())) {
						continue ;
					}
					record.setCreateBy("" + user.getId());
					record.setCustId(cust.getId());
					record.setStatus(CUST_STATUS_VISITOR);
					if(record.getVisitType()==null){
						record.setVisitType(1);
					}else{
						record.setVisitType(record.getVisitType());
					}
					custDao.insertCustStatusRecord(record);
				}
			}
			//记录客户成交记录
			custDao.deleteCustDealRecord(cust.getId());
			if(cust.getDealList() != null && cust.getDealList().size() > 0) {
				for(CustStatusRecord record : cust.getDealList()) {
					if(record == null || StringUtils.isEmpty(record.getRecordTime()) || StringUtils.isEmpty(record.getDealApartType())) {
						continue ;
					}
					record.setCreateBy("" + user.getId());
					record.setCustId(cust.getId());
					record.setStatus(CUST_STATUS_DEAL);
					custDao.insertCustStatusRecord(record);
				}
			}
			//更新状态/到访次数/成交次数,更新状态最新变更时间
			updateTimeAndStatus(cust);
			//记录客户属性信息
			if(cust.getAttrs() != null && cust.getAttrs().size() > 0) {
				for(CustAttr custAttr : cust.getAttrs()) {
					custDao.deleteCustAttr(cust.getId(), custAttr.getId());
					custAttr.setCustId(cust.getId());
					custAttr.setValueLabel(StringUtils.isEmpty(custAttr.getValue()) ? "未选择" : caseDao.getAttrOptionLabel(custAttr.getId(), custAttr.getValue().split(",")[0]));
					custDao.insertCustAttr(custAttr);
				}
			}
			//统一更新信息完整度
			updateCustCompletion(cust.getId(), user.getCaseId());
			return ResultCode.OPERATION_SUCCESSED;
		} else {
			return ResultCode.OPERATION_FAILED;
		}
	}
	
	/*
	 * 删除客户
	 */
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode delCust(User user, String id) {
		if(!checkCustExistOrNot(user, id)) {
			return ResultCode.OPERATION_NOT_PERMITTED;
		}
		if(custDao.delCust(user, id) > 0) {
			return ResultCode.OPERATION_SUCCESSED;
		} else {
			return ResultCode.OPERATION_FAILED;
		}
	}
	
	/*
	 * 客户日报统计结果
	 */
	public Map<String, Object> getCustReport(User user, int rowNum) throws Exception {
		String openDate = caseDao.getCaseOpenDate(user.getCaseId());
		//根据rowNum判断查询的时间范围,最小要等于案场开盘日期
		List<String> dateList = DateUtils.getDateList(openDate, DateUtils.getSeparatedDate(DateUtils.formatDate(new Date()), rowNum), AppConfig.PAGE_SIZE);
		int all = DateUtils.getTwoDateSeparateDays(openDate, DateUtils.formatDate(new Date())), total = dateList.size(), remain = all - rowNum - total;
		String beginDate = dateList.get(dateList.size() - 1), endDate = dateList.get(0);
		List<CustReport> list = custDao.getCustReportByUser(user, beginDate, endDate);
		List<CustReport> reportList = new ArrayList<CustReport>();
		int index = 0;
		for(String date : dateList) {
			if(index < list.size() && date.equalsIgnoreCase(list.get(index).getStatDate())) {
				reportList.add(list.get(index));
				++index;
			} else {
				CustReport report = new CustReport();
				report.setStatDate(date);
				report.setStatMonth(date.substring(0, 7));
				report.setStatWeekday(DateUtils.getWeekday(date));
				reportList.add(report);
			}
		}
		Map<String, List<CustReport>> newReportList = new LinkedHashMap<String, List<CustReport>>();
		for(CustReport report : reportList) {
			if(newReportList.containsKey(report.getStatMonth())) {
				newReportList.get(report.getStatMonth()).add(report);
			} else {
				List<CustReport> newList = new ArrayList<CustReport>();
				newList.add(report);
				newReportList.put(report.getStatMonth(), newList);
			}
		}
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("list", newReportList);
		data.put("total", total);
		data.put("remain", remain);
		return data;
	}
	/**
	 * 根据意向楼盘获取目标户型
	 * @param user 当前用户的openid，caseid
	 * @param pid 意向楼盘id
	 * @return 意向楼盘下面的目标户型
	 * @throws Exception
	 */
	public Map<String, Object> getApartTypeLabelByProj(User user, Integer pid) {
		Map<String, Object> data = new HashMap<String, Object>();
		List<Map<String, Object>> apartTypeLabel = custDao.getApartTypeLabelByProj(user,pid);
		data.put("list",apartTypeLabel );
		return data;
	}
	
	private void updateTimeAndStatus(Customer cust){
		//更新状态/到访次数/成交次数
		custDao.updateCustStatusAndDealsAndVisits(cust.getId());
		//更新状态最新变更时间
		custDao.updateStatusLastRecordDate(cust.getId());
	}
}
