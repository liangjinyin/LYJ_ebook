package com.masadata.ebook.wxapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.wxapp.api.request.AccessTokenRequest;
import com.masadata.ebook.wxapp.api.request.MenuGetRequest;
import com.masadata.ebook.wxapp.dao.CaseWXAppDao;
import com.masadata.ebook.wxapp.entity.CaseWXApp;

@Component
public class AccessTokenService {

	@Autowired
	CaseWXAppDao caseAppDao;
	
	//@Scheduled(fixedDelay=7140000)
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public void updateWXAppAccessToken() {
		List<CaseWXApp> appList = caseAppDao.getCaseWXAppList();
		for(CaseWXApp app : appList) {
			updateWXAppAccessToken(app);
		}
	}
	
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	private void updateWXAppAccessToken(CaseWXApp app) {
		int times = 3;
		String accessToken = null;
		while(times-- > 0) { //每个公众号的access_token最多尝试获取3次
			try {
				JSONObject json = JSON.parseObject(new AccessTokenRequest(app.getAppID(), app.getAppSecret()).getAccessToken());
				if(json.containsKey("errcode") && json.getIntValue("errcode") != 0) {
					//公众号配置信息有错误,
					System.out.println("getTokenError:appid=" + app.getAppID() + "|secret=" + app.getAppSecret() + "|err=" + json.toString());
					break;
				} else if(json.containsKey("access_token")) {
					accessToken = json.getString("access_token");
					break;
				} else {
					//其他服务端错误，继续尝试
					continue;
				}
			} catch(Exception e) { //如果请求过程中出现异常，继续尝试
				e.printStackTrace(); 
				continue;
			}
		}
		if(!StringUtils.isEmpty(accessToken)) { //更新accessToken
			app.setAccessToken(accessToken);
			caseAppDao.updateCaseWXAppAccessToken(app);
		}
	}
	
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public String getAccessToken(String caseId) {
		String accessToken = null;
		if(StringUtils.isEmpty(caseId)) {
			accessToken = caseAppDao.getWXAppAccessTokenByAppID(AppConfig.EBOOK_APP_ID);
		} else {
			accessToken = caseAppDao.getWXAppAccessToken(caseId);
		}
		//通过调用获取菜单接口验证access_token是否有效
		try {
			JSONObject json = JSON.parseObject(new MenuGetRequest(accessToken).getMenu());
			if(json.containsKey("errcode")) { //有错误，默认考虑为微信的40001或42001（40001： invalid credential,access_token is invalid or not latest；42001：access_token expired）
				CaseWXApp app = null;
				if(StringUtils.isEmpty(caseId)) {
					app = new CaseWXApp();
					app.setAppID(AppConfig.EBOOK_APP_ID);
					app.setAppSecret(AppConfig.EBOOK_APP_SECRET);
					app.setWebHost(AppConfig.EBOOK_WEB_HOST);
				} else {
					app = caseAppDao.getCaseWXAppInfo(caseId);
				}
				if(app != null) {
					updateWXAppAccessToken(app);
					accessToken = caseAppDao.getWXAppAccessToken(caseId);
				} else { //已删除的案场直接获取公众号信息 获取 accessToken
					accessToken = JSON.parseObject(new AccessTokenRequest(AppConfig.EBOOK_APP_ID, AppConfig.EBOOK_APP_SECRET).getAccessToken()).getString("access_token");
				}
			}
		} catch(Exception e) { //验证如果出现异常，则直接返回token
			e.printStackTrace();
		}
		return accessToken;
	}
}

