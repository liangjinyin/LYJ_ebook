package com.masadata.ebook.user.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.user.dao.MobileCodeDao;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;
import com.masadata.ebook.wxapp.api.request.WXUserBaseInfoRequest;
import com.masadata.ebook.wxapp.service.AccessTokenService;
import com.masadata.ebook.wxapp.service.WXMsgService;

@Service
@Transactional(readOnly=true)
public class UserService {

	@Autowired
	UserDao userDao;
	@Autowired
	MobileCodeDao codeDao;
	@Autowired
	AccessTokenService tokenService;
	@Autowired
	WXMsgService msgService;
	
	//微信用户绑定身份信息
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode bind(String code, User user) throws Exception {
		if(codeDao.checkMobileCode(user.getMobile(), code, CodeService.CODE_TYPE_BIND_WXAPP) > 0) {//验证码正确
			//该手机号对应的用户是否为案场工作人员
			Boolean userLoginFlag = userDao.getUserLoginFlagByMobile(user.getMobile());
			if(userLoginFlag == null) {//不为工作人员
				return ResultCode.USER_NOT_CASE_WORKER;
			} else if(!userLoginFlag) {
				return ResultCode.USER_DENIED;
			} else {
				String bindedMobile = userDao.getUserBindMobileByOpenid(user);
				if(!StringUtils.isEmpty(bindedMobile) && !bindedMobile.equalsIgnoreCase(user.getMobile())) {
					return ResultCode.USER_HAS_BINDED_MOBILE;
				}
				String bindedOpenid = userDao.getUserBindOpenidByMobile(user);
				if(!StringUtils.isEmpty(bindedOpenid) && !bindedOpenid.equalsIgnoreCase(user.getOpenid())) {
					return ResultCode.USER_MOBILE_HAS_BINED;
				}
				if(userDao.checkCaseWorkerMobileAndName(user) == 0) {//姓名与手机号和预留的信息不匹配
					return ResultCode.USER_INFO_NOT_MATCHED;
				}
				if(userDao.bindUserWXOpenID(user) > 0) {
					//一个公众号多个案场的模式下，绑定时未传入caseId参数，绑定后重置一下caseId
					user.setCaseId(userDao.getUserBindedCaseByWXOpenID(user.getOpenid()));
					//更新用户头像
					try {
						String token = tokenService.getAccessToken(user.getCaseId());
						JSONObject json = JSON.parseObject(new WXUserBaseInfoRequest(token, user.getOpenid()).getWXUserBaseInfo());
						if(json.containsKey("errcode")) {
							//记录异常信息
						} else {
							user.setPhoto(json.getString("headimgurl"));
							userDao.updateCaseWorkerPhoto(user);
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
					//绑定成功， 推送消息给用户
						msgService.pushUserBindOKMsg(user);
					return ResultCode.OPERATION_SUCCESSED;
				} else {
					return ResultCode.OPERATION_FAILED;
				}
			}
		} else {//验证码错误或失效
			if(codeDao.checkMobileIncorrectOrExpired(user.getMobile(), code, CodeService.CODE_TYPE_BIND_WXAPP) == null) {
				return ResultCode.MOBILECODE_INCORRECT;
			} else {
				return ResultCode.MOBILECODE_EXPIRED;
			}
		}
	}
	
	//查看个人中心
	public Map<String, Object> getUserInfo(User user) {
		 
				Map<String, Object>	u = 	userDao.getUserInfo(user);
				return u;
	}
	
	//注销绑定信息
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode cancelBind(User user) {
		if(userDao.cancelBind(user) > 0) {
			return ResultCode.OPERATION_SUCCESSED;
		} else {
			return ResultCode.OPERATION_FAILED;
		}
	}
	
	//公众号里查看当前案场的配置信息，用户在添加客户时需要展示用
	public Map<String, Object> getUserCaseConfig(User user) {
		return userDao.getUserCaseConfig(user.getCaseId());
	}
}
