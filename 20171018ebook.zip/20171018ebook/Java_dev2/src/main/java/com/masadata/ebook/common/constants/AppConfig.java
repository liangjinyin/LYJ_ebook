package com.masadata.ebook.common.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:wxapp/config.properties")
public class AppConfig {

	public static final String PUSH_TEMPLATE_CUST_DAILY_REPORT = "昨日共有%d人到访，%d人多次到访，%d人成交。\n<a href=\"%s\">查看到访客户列表…</a>\n<a href=\"%s\">查看多次来访客户列表…</a>\n<a href=\"%s\">查看成交客户列表…</a>";
	public static final String PUSH_TEMPLATE_CUST_INFO = "客户姓名：<a href=\"%s\">  %s</a>  \n%s时间：  %s\n接待人员：  %s\n工作编号：  %s";
	public static final String PUSH_TEMPLATE_CUST_NOT_EXIST = "无此客户信息";
	public static final String PUSH_TEMPLATE_WXUSER_SUBSCRIBE = "您已关注%s，请尽快完成账号验证。\n<a href=\"%s\">账号验证申请…</a>";
	public static final String PUSH_TEMPLATE_INCOMPLETE_LIST = "当前未补全信息共有%d人。\n<a href=\"%s\">查看未补全信息列表</a>";
	public static final String PUSH_TEMPLATE_WXUSER_UNBINDED = "您未完成账号验证。\n<a href=\"%s\">账号验证申请…</a>";
	public static final String PUSH_TEMPLATE_WXUSER_BINDED = "您已验证通过，可以使用本产品。\n<a href=\"%s\">查看个人中心...</a>";
	public static final String PUSH_TEMPLATE_CUST_VISIT_REGISTRY = "您已接待客户%s。\n电话：<a href=\"tel:%s\">%s</a>\n<a href=\"%s\">补全信息</a>";

	public static String EBOOK_APP_ID;
	@Value("${ebook.appID}")
	public void setEBookAppID(String appID) {
		EBOOK_APP_ID = appID;
	}
	public static String EBOOK_APP_SECRET;
	@Value("${ebook.appSecret}")
	public void setEBookAppSecret(String appSecret) {
		EBOOK_APP_SECRET = appSecret;
	}
	public static String EBOOK_WEB_HOST;
	@Value("${ebook.webHost}")
	public void setEBookWebHost(String webHost) {
		EBOOK_WEB_HOST = webHost;
	}
	
	public static int PAGE_SIZE;
	@Value("${page_size}")
	public void setPageSize(int pageSize) {
		PAGE_SIZE = pageSize;
	}
	public static String SERVER_API_PATH;
	@Value("${server.apiPath}")
	public void setServerApiPath(String apiPath) {
		SERVER_API_PATH = apiPath;
	}
	public static boolean SERVER_ALLOW_CORSDOMAIN;
	@Value("${server.allow_corsdomain}")
	public void setServerAllowCorsDomain(boolean allowed) {
		SERVER_ALLOW_CORSDOMAIN = allowed;
	}
	public static String SERVER_CORSDOMAIN;
	@Value("${server.corsdomain}")
	public void setServerCorsDomain(String domain) {
		SERVER_CORSDOMAIN = domain;
	}
	public static String WXAPP_SERVER_AUTH_TOKEN;
	@Value("${wxapp_server_auth_token}")
	public void setWXAppServerAuthToken(String token) {
		WXAPP_SERVER_AUTH_TOKEN = token;
	}
	public static String INCOMPLETE_LIST_URL;
	@Value("${incomplete_list}")
	public void setIncompleteListUrl(String url) {
		INCOMPLETE_LIST_URL = url;
	}
	
	public static String VISITOR_LIST_URL;
	@Value("${visitor_list}")
	public void setVisitorListUrl(String url) {
		VISITOR_LIST_URL = url;
	}
	
	public static String Multi_VISIT_VISITOR_LIST_URL;
	@Value("${multi_visit_visitor_list}")
	public void setMultiVisitVisitorListUrl(String url) {
		Multi_VISIT_VISITOR_LIST_URL = url;
	}

	public static String DEAL_CUSTOMER_LIST_URL;
	@Value("${deal_customer_list}")
	public void setDealCustomerListUrl(String url) {
		DEAL_CUSTOMER_LIST_URL = url;
	}

	public static String HISTORY_REPORT_URL;
	@Value("${history_report}")
	public void setHistoryReportUrl(String url) {
		HISTORY_REPORT_URL = url;
	}

	public static String NEW_CUSTOMER_URL;
	@Value("${new_customer}")
	public void setNewCustomerUrl(String url) {
		NEW_CUSTOMER_URL = url;
	}

	public static String CUSTOMER_LIST_URL;
	@Value("${customer_list}")
	public void setCustomerListUrl(String url) {
		CUSTOMER_LIST_URL = url;
	}

	public static String VISIT_LIST_URL;
	@Value("${visit_list}")
	public void setVisitListUrl(String url) {
		VISIT_LIST_URL = url;
	}
	
	public static String CUSTOMER_INFO_URL;
	@Value("${customer_info}")
	public void setCustomerInfoUrl(String url) {
		CUSTOMER_INFO_URL = url;
	}
	
/*	public static String USER_BIND_URL;
	@Value("${user_bind}")
	public void setUserBindUrl(String url) {
		USER_BIND_URL = url;
	}
*/	
	public static String USER_INFO_URL;
	@Value("${user_info}")
	public void setUserInfoUrl(String url) {
		USER_INFO_URL = url;
	}
}

