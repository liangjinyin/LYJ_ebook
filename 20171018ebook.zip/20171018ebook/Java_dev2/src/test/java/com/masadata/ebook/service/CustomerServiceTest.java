package com.masadata.ebook.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.StringUtils;

import com.masadata.ebook.EBookApp;
import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.util.DateUtils;
import com.masadata.ebook.customer.dao.CaseDao;
import com.masadata.ebook.customer.dao.CustomerDao;
import com.masadata.ebook.customer.entity.CustAttr;
import com.masadata.ebook.customer.entity.CustReport;
import com.masadata.ebook.customer.service.CustomerService;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;
import com.masadata.ebook.wxapp.dao.CaseWXAppDao;



@RunWith(MockitoJUnitRunner.class)  
@SpringBootTest(classes=EBookApp.class)
public class CustomerServiceTest {

	@Mock
	private CustomerDao custDao;
	@Mock
	private UserDao userDao;
	@Mock
	private CaseDao caseDao;
	@Mock
	private CaseWXAppDao appDao;

	@InjectMocks
	@Autowired
	private CustomerService custService;
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void getCustReport() throws Exception {
		// mock
		new AppConfig().setPageSize(25);
		User user = new User();
		List<CustReport> mockResult = new ArrayList<>();
		int rowNum = 0;
		String beginDate = DateUtils.formatDate(new Date()), endDate = beginDate;
		// invoke
		Mockito.when(caseDao.getCaseOpenDate(user.getCaseId())).thenReturn(DateUtils.formatDate(new Date()));
		Mockito.when(custDao.getCustReportByUser(user, beginDate, endDate)).thenReturn(mockResult);
		Map<String, Object> result = custService.getCustReport(user, rowNum);
		// assert
		Assert.assertNotNull("getCustReport result map can be empty but not null", result);
		Assert.assertTrue((int)result.get("total") == 1);
		Assert.assertTrue((int)result.get("remain") == 0);
		Assert.assertTrue(((Map<String, Object>)result.get("list")).containsKey(beginDate.substring(0, 7)));
	}
	
	@Test
	public void delCust() {
		String custId = "1";
		User user = new User();
		Mockito.when(userDao.getUserAdminFlag(user)).thenReturn(1, 0, 1, 0);
		Mockito.when(custDao.checkCustExistByAdmin(user, custId)).thenReturn(0, 1);
		Mockito.when(custDao.checkCustExist(user, custId)).thenReturn(0, 1);
		Mockito.when(custDao.delCust(user, custId)).thenReturn(1, 1);
		
		ResultCode result = null;
		
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_NOT_PERMITTED.getResultCode()));
		
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_NOT_PERMITTED.getResultCode()));
	
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_SUCCESSED.getResultCode()));
		
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_SUCCESSED.getResultCode()));
	
	}
	
	
	@Test
	public void getCustDetail(){
		User user =  new User();
		user.setCaseId("1");
		user.setId(5);
		user.setMobile("13631699601");
		user.setName("李振龙");
		user.setOpenid("ozN9K0k55VCvo_y8FoylFzy2DYIo");
		String id = "18";
		 String ATTR_TYPE_SELECTBOX = "selectbox";
		
		Map<String, Object> detail = custDao.getCustDetail(id);
		//增加 楼盘项目列表 intentProjectList
		detail.put("intentProjectList", caseDao.getProjectList(user.getCaseId()));
		//改变意向房型的选择值为数组 intentApartType
		detail.put("intentApartTypeList", caseDao.getCaseApartTypeListByCaseId(user.getCaseId()));
		detail.put("intentApartType", (StringUtils.isEmpty(detail.get("intentApartType")) ? new String[]{} : ((String)detail.get("intentApartType")).split(",")));
		detail.put("intentApartTypeLabel", (StringUtils.isEmpty(detail.get("intentApartTypeLabel")) ? "未选择" : detail.get("intentApartTypeLabel")));
		//处理分组维度信息 attrGroups
		List<Map<String, Object>> attrGroups = caseDao.getCaseCustAttrGroupAndDetail(user.getCaseId());
		List<CustAttr> custAttrs = custDao.getCustAttrs(id);
		for(Map<String, Object> attrGroup : attrGroups) { //遍历分组
			//List<Map<String, Object>> attrs = (List<Map<String, Object>>) attrGroup.get("attrs");
			List<Map<String, Object>> attrs = caseDao.getCaseCustAttrByGroup((int)attrGroup.get("id"));
			for(Map<String, Object> attr : attrs) {  //遍历维度
				boolean attrHasValue = false;
				String attrType = (String) attr.get("type");
				for(CustAttr custAttr : custAttrs) { //可选的维度和客户已选择值的维度匹配，并根据维度类型设置值
					if(custAttr.getId() == (int)attr.get("id")) {
						if(!StringUtils.isEmpty((String)custAttr.getValue())) {
							if(ATTR_TYPE_SELECTBOX.equalsIgnoreCase(attrType)) { //多选的维度值用数组格式
								attr.put("value", "");
								String values = caseDao.checkAttrOption(custAttr.getId(), ((String)custAttr.getValue()).split(","));
								if(!StringUtils.isEmpty(values)) {
									attr.put("value", values.split(","));
								}
							} else {
								attr.put("value", custAttr.getValue());
							}
						}
						attr.put("valueLabel", StringUtils.isEmpty(custAttr.getValueLabel()) ? "未选择" : custAttr.getValueLabel());
						custAttrs.remove(custAttr);//匹配成功的，从custAttrs中移除，避免下次循环又扫描一次
						attrHasValue = true;
						break ;
					}
				}
				if(!attrHasValue) { //没匹配成功，设置默认为未选择
					if(ATTR_TYPE_SELECTBOX.equalsIgnoreCase(attrType)) { //多选的维度值用数组格式
						attr.put("value", new String[] {});
					} else {
						attr.put("value","");
					}
					attr.put("valueLabel", "未选择");
				}
				attr.put("options", caseDao.getCaseCustAttrOptions((int)attr.get("id"))); 
			}
			attrGroup.put("attrs", attrs);
		}
		detail.put("attrGroups", attrGroups);
		detail.put("visitList", custDao.getCustVisitList(id));
		detail.put("dealList", custDao.getCustDealList(id));
		System.out.println(detail);
	}
	
	/*
	@Test
	public void addDate(){
		String mac = "60:21:01:F6:C0:2D,A8:66:7F:D7:38:6A,84:38:35:55:03:A8,"
				+ "C4:B3:01:CE:FF:E1,F4:31:C3:8F:4E:9C,5C:AD:CF:77:D5:D8,6C:72:E7:66:55:85,"
				+ "D4:A1:48:DD:56:2E,A4:71:74:CE:57:0E,70:48:0F:4C:FB:1B,FC:3F:7C:0E:99:A6,"
				+ "88:44:77:38:21:7A,C0:CC:F8:42:5A:D0,9C:F3:87:43:DB:C1,48:E9:F1:A9:49:9E,"
				+ "C0:CC:F8:84:62:5A,F4:31:C3:05:0A:CF,DC:0C:5C:87:C5:FD,74:1B:B2:C4:36:71,"
				+ "24:5B:A7:67:92:19,B8:63:4D:25:E9:85,48:E9:F1:CD:32:B0,F0:1B:6C:E4:11:C4,"
				+ "78:D7:5F:31:1A:28,D4:61:9D:4F:C1:60,A4:3D:78:B7:90:53,D0:33:11:83:70:85,"
				+ "9C:F3:87:20:22:65,BC:A9:20:AD:EF:B3,0C:D7:46:9C:2E:B8,64:A5:C3:81:64:36,"
				+ "58:44:98:DF:BC:9E,10:10:10:10:10:10,3C:91:57:39:F5:7D";
		String[] arr = mac.split(",");
		
		String mac = "";
		//调用接口分别得到工作地和居住地的经纬度
		
		//填入数据库
		
		
		
	}*/
	
	
	   /* public static void main(String[] args) throws IOException {
	       // System.out.println(getData());
	        HttpHelper http = new HttpHelper();
	        String turl ="https://api.talkingdata.com/tdmkaccount/authen/app/v2?apikey={baea26cd893a41928e187a1c7bc1346c}&apitoken={30d21b91259845419799785a8bddf6b8}" ;
	        CommonHttpResponse response = null;
			try {
				response =  new HttpHelper().httpGet(turl , null);
				System.out.println(response.getClass().toString());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
	        
	        
	        /*String url = "https://api.talkingdata.com/data/user-loc-residence-latlng/v1";
	        JSONObject params = new JSONObject();
	        params.put("APIKey","baea26cd893a41928e187a1c7bc1346c");
	        params.put("APIToken","30d21b91259845419799785a8bddf6b8");
	        params.put("id", "F4:31:C3:8F:4E:9C");
	        params.put("type","mac");
	        CommonHttpResponse t = null;
	        try {
				t =   http.httpGet(url, params);
				System.out.println(t.getEntityStr().toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
	   // }
}
