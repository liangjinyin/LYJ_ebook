package com.masadata.ebook.dao;

import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.StringUtils;

import com.masadata.ebook.common.util.DateUtils;
import com.masadata.ebook.customer.dao.CustomerDao;
import com.masadata.ebook.customer.entity.CustReport;
import com.masadata.ebook.user.entity.User;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerDaoTest {

	@Autowired
	CustomerDao custDao;
	
	@Test
	public void getCustReportByUser() {
		User user = new User();
		user.setCaseId("1");
		user.setOpenid("openid");
		String date = DateUtils.formatDate(new Date());
		Assert.assertNotNull(custDao.getCustReportByUser(user, date, date));
	}
	
	@Test
	public void getYesterdayCustReportByUser() {
		User user = new User();
		user.setCaseId("1999");
		user.setOpenid("ozN9K0kK2STgLX8XTbSPFyKVEe9Y");
		CustReport report = custDao.getYesterdayCustReportByUser(user);
		if(report != null) {
			if(!StringUtils.isEmpty(report.getStatDate())) {
				Assert.assertTrue(report.getStatDate().equalsIgnoreCase(DateUtils.getYesterday()));
			}
			Assert.assertTrue(report.getUserId() > 0);
		}
	}
	
	@Test
	public void getYesterdayCustReport() {
		Assert.assertNotNull(custDao.getYesterdayCustReport());
	}
	
	@Test
	public void getlastTime() {
		Date date = custDao.getlastTime(91);
		//System.out.println((System.currentTimeMillis()- date.getTime())/(60*60*1000));
		if(date != null) {
			Assert.assertNotNull(date);
		}
	}
}
