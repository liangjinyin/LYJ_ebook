package com.masadata.ebook.common;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

public class TestUtils {

	public static String getControllerResult(ResultCode resultCode, Object data) {
		JSONObject result = new JSONObject();
		result.put("retCode", resultCode.getResultCode());
		result.put("retMsg", resultCode.getResultMsg());
		result.put("data", data);
		return JSON.toJSONString(result, SerializerFeature.DisableCircularReferenceDetect);
	}
}
