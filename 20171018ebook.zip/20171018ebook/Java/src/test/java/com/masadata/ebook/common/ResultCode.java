package com.masadata.ebook.common;

public enum ResultCode {

	OPERATION_SUCCESSED("000", "操作成功"),
	OPERATION_FAILED("001", "操作失败"), 
	OPERATION_ABNORMAL("002", "操作异常"),
	USER_UNAUTHORIZED("003", "身份未验证"), 
	OPERATION_NOT_PERMITTED("004", "权限不足"),
	NONE("999", "无意义数据"), 
	
	MOBILECODE_EXPIRED("1001", "验证码已失效"), 
	MOBILECODE_INCORRECT("1002", "验证码错误"), 
	MOBILECODE_TYPE_INVALID("1003", "无效的验证码请求"), 
	MOBILECODE_EMPTY("1004", "验证码为空"), 
	
	USER_NOT_CASE_WORKER("2001", "非案场工作人员"), 
	USER_INFO_NOT_MATCHED("2002", "手机号与姓名不匹配"), 
	
	CUST_MOBILE_EXIST("3001", "该手机号已存在"), 
	CUST_INTENT_APARTTYPE_INVALID("3002", "存在不支持的房型"),
	CUST_DEAL_APARTTYPE_NULL("3003", "成交房型为空"),
	CUST_DEAL_APARTTYPE_INVALID("3004", "不支持的成交房型"),
	CUST_ATTR_VALUE_NOTSUPPORTED("3005", "不支持的维度值"), 
	CUST_MOBILE_EMPTY("3006", "客户手机号缺失"), 
	CUST_CONSULTANT_EMPTY("3007", "客户置业顾问为空"), 
	CUST_CONSULTANT_NOTEXIST("3008", "置业顾问编号错误"), 
	
	OPENID_REQEUST_FAILED("40000", "获取微信用户openid请求失败"),
	CUSTOM_ERROR("{errcode}", "{errmsg}"), 
	;
	
	

	private String code;
	private String msg;
	ResultCode(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}
	public String getResultCode() {
		return code;
	}
	public String getResultMsg() {
		return msg;
	}
	public static ResultCode createResultCode(String code) {
		for(ResultCode val : ResultCode.values()) {
			if(val.getResultCode().equalsIgnoreCase(code)) {
				return val;
			}
		}
		return ResultCode.NONE;
	}
	public static ResultCode createCustomResultCode(String code, String msg) {
		ResultCode custom =  ResultCode.CUSTOM_ERROR;
		custom.code = code;
		custom.msg = msg;
		return custom;
	}
	public static void main(String args[]) {
		System.out.println(createResultCode("000").toString());
	}
}
