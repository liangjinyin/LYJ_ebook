package com.masadata.ebook.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.masadata.ebook.EBookApp;
import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.util.DateUtils;
import com.masadata.ebook.customer.dao.CaseDao;
import com.masadata.ebook.customer.dao.CustomerDao;
import com.masadata.ebook.customer.entity.CustReport;
import com.masadata.ebook.customer.service.CustomerService;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;



@RunWith(MockitoJUnitRunner.class)  
@SpringBootTest(classes=EBookApp.class)
public class CustomerServiceTest {

	@Mock
	private CustomerDao custDao;
	@Mock
	private UserDao userDao;
	@Mock
	private CaseDao caseDao;

	@InjectMocks
	@Autowired
	private CustomerService custService;
	
	@SuppressWarnings("unchecked")
	@Test
	public void getCustReport() throws Exception {
		// mock
		new AppConfig().setPageSize(25);
		User user = new User();
		List<CustReport> mockResult = new ArrayList<>();
		int rowNum = 0;
		String beginDate = DateUtils.formatDate(new Date()), endDate = beginDate;
		// invoke
		Mockito.when(caseDao.getCaseOpenDate(user.getCaseId())).thenReturn(DateUtils.formatDate(new Date()));
		Mockito.when(custDao.getCustReportByUser(user, beginDate, endDate)).thenReturn(mockResult);
		Map<String, Object> result = custService.getCustReport(user, rowNum);
		// assert
		Assert.assertNotNull("getCustReport result map can be empty but not null", result);
		Assert.assertTrue((int)result.get("total") == 1);
		Assert.assertTrue((int)result.get("remain") == 0);
		Assert.assertTrue(((Map<String, Object>)result.get("list")).containsKey(beginDate.substring(0, 7)));
	}
	
	@Test
	public void delCust() {
		String custId = "1";
		User user = new User();
		Mockito.when(userDao.getUserAdminFlag(user)).thenReturn(1, 0, 1, 0);
		Mockito.when(custDao.checkCustExistByAdmin(user, custId)).thenReturn(0, 1);
		Mockito.when(custDao.checkCustExist(user, custId)).thenReturn(0, 1);
		Mockito.when(custDao.delCust(user, custId)).thenReturn(1, 1);
		
		ResultCode result = null;
		
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_NOT_PERMITTED.getResultCode()));
		
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_NOT_PERMITTED.getResultCode()));
	
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_SUCCESSED.getResultCode()));
		
		result = null;
		result = custService.delCust(user, custId);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.getResultCode().equalsIgnoreCase(ResultCode.OPERATION_SUCCESSED.getResultCode()));
	
	}
	
}
