package com.masadata.ebook.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.masadata.ebook.customer.dao.CaseDao;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class CaseDaoTest {

	@Autowired
	CaseDao caseDao;
	
	@Test
	public void getProjectList() {
		Assert.assertTrue(caseDao.getProjectList("1999").size() >= 0);
	}
	
	@Test
	public void getCaseApartTypeListByProjectId() {
		Assert.assertTrue(caseDao.getCaseApartTypeListByCaseId("1999").size() >= 0);
	}
}
