package com.masadata.ebook.wxapp.api.request;

import org.apache.http.HttpStatus;

import com.alibaba.fastjson.JSONObject;
import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class SendMessageRequest {

	private String accessToken;
	private JSONObject msgBody;
	private static String URL = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=%s";
	
	public SendMessageRequest(String accessToken, JSONObject msgBody) {
		this.accessToken = accessToken;
		this.msgBody = msgBody;
	}
	
	public String send() throws Exception { 
		CommonHttpResponse response = new HttpHelper().httpPostWithStringStream(String.format(URL, accessToken), msgBody);
		if(response.getRetCode() == HttpStatus.SC_OK) {
			return response.getEntityStr();
		} else {
			return response.toString();
		}
	}
	
}
