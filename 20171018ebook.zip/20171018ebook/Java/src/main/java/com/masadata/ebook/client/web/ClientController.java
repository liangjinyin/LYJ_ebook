package com.masadata.ebook.client.web;

import java.net.URLDecoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masadata.ebook.client.service.ClientService;
import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.web.BaseController;
import com.masadata.ebook.customer.entity.Customer;

@RestController
@RequestMapping(path="${server.apiPath}/client", method=RequestMethod.POST)
public class ClientController extends BaseController {

	@Autowired
	ClientService clientService;
	
	private String extractMacFromQuery(String queryStr) {
		String macStr = "userMac=", mobileMac = null;
		if(queryStr.indexOf('&', queryStr.indexOf(macStr)) > -1) {
			mobileMac = queryStr.substring(queryStr.indexOf(macStr) + macStr.length(), queryStr.indexOf('&', queryStr.indexOf(macStr)));
		} else {
			mobileMac = queryStr.substring(queryStr.indexOf(macStr) + macStr.length());
		}
		try {
			return URLDecoder.decode(mobileMac, "utf-8");
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@RequestMapping("/customer/exist")
	public String checkCustExist(@RequestParam("caseId") String caseId, @RequestParam("queryStr") String queryStr) {
		boolean exist = false;
		try {
			exist = clientService.checkCustExist(caseId, extractMacFromQuery(queryStr), queryStr);
		} catch(Exception e) {
			exist = false;
		}
		data = exist;
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/client-config")
	public String getCaseClientConfig(@RequestParam("caseId") String caseId, @RequestParam(name="token", required=false) String token) {
		if(!StringUtils.isEmpty(token) && !"masa.123".equalsIgnoreCase(token)) {
			retCode = ResultCode.OPERATION_NOT_PERMITTED;
		} else {
			retCode = ResultCode.OPERATION_SUCCESSED;
			data = clientService.getCaseClientConfig(caseId);
		}
		return result();
	}
	
	@RequestMapping("/customer/check")
	public String customerCheckIn(Customer cust, @RequestParam("queryStr") String queryStr, @RequestParam(name="code", required=false) String code) {
		cust.setMobileMac(extractMacFromQuery(queryStr));
		cust.setHanming(queryStr);
		try {
			retCode = clientService.customerCheckIn(cust, code);
		} catch(Exception e) {
			e.printStackTrace();
			retCode = ResultCode.OPERATION_FAILED;
		}
		data = null;
		return result();
	}
}
