package com.masadata.ebook.customer.entity;

import java.util.Date;

import org.springframework.util.StringUtils;

public class CustStatusRecord {

	private String id;
	String key;
	private Integer custId;
	private String status;
	private String recordTime;
	String value;
	private String dealApartType;
	private String dealApartTypeLabel;
	private Date createTime;
	private String createBy;
	private Date updateTime;
	private String updateBy;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getKey() {
		return id;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	public String getValue() {
		return (StringUtils.isEmpty(dealApartType) ? recordTime : dealApartTypeLabel);
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDealApartType() {
		return dealApartType;
	}
	public void setDealApartType(String dealApartType) {
		this.dealApartType = dealApartType;
	}
	public String getDealApartTypeLabel() {
		return dealApartTypeLabel;
	}
	public void setDealApartTypeLabel(String dealApartTypeLabel) {
		this.dealApartTypeLabel = dealApartTypeLabel;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	
}
