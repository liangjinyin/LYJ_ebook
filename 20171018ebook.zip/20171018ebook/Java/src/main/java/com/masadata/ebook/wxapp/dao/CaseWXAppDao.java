package com.masadata.ebook.wxapp.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.masadata.ebook.wxapp.entity.CaseWXApp;

@Mapper
public interface CaseWXAppDao {

	@Select("select case_id caseId, app_id appID, app_name appName, app_secret appSecret, web_host webHost, server_url serverUrl "
			+ "from salesoffice_wxapp_config "
			+ "where case_id = ${caseId} and del_flag = 0 ")
	CaseWXApp getCaseWXAppInfo(@Param("caseId") String caseId);
	
	@Select("select distinct app_id appID, app_name appName, app_secret appSecret "
			+ "from salesoffice_wxapp_config "
			+ "where app_id is not null and del_flag = 0 ")
	List<CaseWXApp> getCaseWXAppList();
	
	@Update("update salesoffice_wxapp_config "
			+ "set access_token = #{accessToken} "
			+ "where app_id = #{appID}")
	Integer updateCaseWXAppAccessToken(CaseWXApp app);
	
	@Update("update salesoffice_wxapp_config "
			+ "set jsapi_ticket = #{jsApiTicket} "
			+ "where app_id = #{appID}")
	Integer updateCaseWXAppJSApiTicket(CaseWXApp app);
	
	@Select("select access_token "
			+ "from salesoffice_wxapp_config "
			+ "where case_id = ${caseId} and del_flag = 0 ")
	String getWXAppAccessToken(@Param("caseId") String caseId);
	
	@Select("select distinct access_token "
			+ "from salesoffice_wxapp_config "
			+ "where app_id = #{appID} and del_flag = 0 "
			+ "limit 1 ")
	String getWXAppAccessTokenByAppID(@Param("appID") String appID);

	@Select("select jsapi_ticket jsApiTicket "
			+ "from salesoffice_wxapp_config "
			+ "where case_id = ${caseId} and del_flag = 0 ")
	String getWXAppJSApiTicket(@Param("caseId") String caseId);
	
	@Select("select distinct jsapi_ticket jsApiTicket "
			+ "from salesoffice_wxapp_config "
			+ "where app_id = #{appID} and del_flag = 0 "
			+ "limit 1 ")
	String getWXAppJSApiTicketByAppID(@Param("appID") String appID);
}
