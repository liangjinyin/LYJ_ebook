package com.masadata.ebook.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class DateUtils {

	public static String[] WEEKDAYS = {"", "周日", "周一", "周二", "周三", "周四", "周五", "周六"};
	
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static String formatDate(Date date) {
		return formatDate(date, DATE_FORMAT);
	}
	
	public static String formatDate(Date date, String format) {
		DateFormat df = new SimpleDateFormat(format);
		return df.format(date);
	}
	
	public static String formatDateTimeMinute(Date date) {
		return formatDate(date, "yyyy-MM-dd HH:mm");
	}
	
	public static Date parseDate(String date) throws ParseException {
		return parseDate(date, DATE_FORMAT);
	}
	
	public static Date parseDate(String date, String format) throws ParseException {
		DateFormat df = new SimpleDateFormat(format);
		return df.parse(date);
	}
	
	public static String getYesterday() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		return formatDate(cal.getTime());
	}
	
	public static String getWeekday(String date) throws ParseException {
		return getWeekday(date, DATE_FORMAT);
	}
	
	public static String getSeparatedDate(String date, int durs) throws ParseException {
		Calendar cal = Calendar.getInstance();
		cal.setTime(parseDate(date));
		cal.add(Calendar.DAY_OF_MONTH, 0 - durs);
		return formatDate(cal.getTime());
	}
	
	public static int getTwoDateSeparateDays(String beginDate, String endDate) throws ParseException {
		return (int) ((parseDate(endDate).getTime() - parseDate(beginDate).getTime()) / (24 * 60 * 60 * 1000)) + 1;
	}
	
	public static String getWeekday(String date, String format) throws ParseException {
		Calendar cal = Calendar.getInstance();
		cal.setTime(parseDate(date, format));
		int weekday = cal.get(Calendar.DAY_OF_WEEK);
		return WEEKDAYS[weekday];
	}
	
	public static List<String> getDateList(String startDate, String endDate, int dateNum) throws ParseException {
		List<String> dateList = new ArrayList<String>();
		Calendar cal = new GregorianCalendar();
		cal.setTime(parseDate(endDate));
		while(dateNum-- > 0 && cal.getTime().compareTo(parseDate(startDate)) >= 0) {
			dateList.add(formatDate(cal.getTime()));
			cal.add(Calendar.DAY_OF_MONTH, -1);
		}
		return dateList;
	}
	
	public static void main(String args[]) throws ParseException {
		String endDate = getSeparatedDate("2017-08-17", 15);
		List<String> dateList = getDateList("2017-08-01", endDate, 15);
		System.out.println(dateList);
		for(String date : dateList) {
			System.out.println(date + " " + getWeekday(date));
		}
		System.out.println("separate days:" + getTwoDateSeparateDays("2017-08-01", endDate));
	}
}
