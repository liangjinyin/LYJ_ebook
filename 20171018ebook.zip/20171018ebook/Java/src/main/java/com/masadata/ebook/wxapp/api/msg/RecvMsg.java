package com.masadata.ebook.wxapp.api.msg;

import com.masadata.ebook.common.xml.XmlParser;

public class RecvMsg {
	private String ToUserName;
	private String FromUserName;
	private Long CreateTime;
	private String MsgType;
	private String Content;
	private String Event;
	private String EventKey;
	private XmlParser parser;
	
	public RecvMsg(XmlParser parser) {
		this.parser = parser;
		parse();
	}
	
	private void parse() {
		setToUserName(parser.getNodeText("/xml/ToUserName"));
		setFromUserName(parser.getNodeText("/xml/FromUserName"));
		setCreateTime(parser.getNodeTextLongVal("/xml/CreateTime"));
		setMsgType(parser.getNodeText("/xml/MsgType"));
		setContent(parser.getNodeText("/xml/Content"));
		setEvent(parser.getNodeText("/xml/Event"));
		setEventKey(parser.getNodeText("/xml/EventKey"));
	}
	
	public String getContent() {
		return Content;
	}

	public void setContent(String content) {
		Content = content;
	}

	public String getEvent() {
		return Event;
	}

	public void setEvent(String event) {
		Event = event;
	}
	
	public String getEventKey() {
		return EventKey;
	}

	public void setEventKey(String eventKey) {
		EventKey = eventKey;
	}

	public String getToUserName() {
		return ToUserName;
	}

	public void setToUserName(String toUserName) {
		ToUserName = toUserName;
	}

	public String getFromUserName() {
		return FromUserName;
	}

	public void setFromUserName(String fromUserName) {
		FromUserName = fromUserName;
	}

	public Long getCreateTime() {
		return CreateTime;
	}

	public void setCreateTime(Long createTime) {
		CreateTime = createTime;
	}

	public String getMsgType() {
		return MsgType;
	}

	public void setMsgType(String msgType) {
		MsgType = msgType;
	}

	public XmlParser getParser() {
		return parser;
	}

	public void setParser(XmlParser parser) {
		this.parser = parser;
	}
	
}
