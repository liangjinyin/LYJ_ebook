package com.masadata.ebook.wxapp.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.web.BaseController;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;

@Component
public class WXUserInterceptor extends BaseController implements HandlerInterceptor  {

	@Autowired
	UserDao userDao;
	
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// TODO Auto-generated method stub
		String openid = request.getParameter("openid"), caseId = request.getParameter("caseId");
		logger.info("openid=" + openid + "|caseId=" + caseId);
		User user = new User();
		user.setOpenid(openid);
		if(StringUtils.isEmpty(openid) || StringUtils.isEmpty(userDao.getUserBindedCaseByWXOpenID(openid))) {
			retCode = ResultCode.USER_UNAUTHORIZED;
			response.setCharacterEncoding("utf-8");
			response.setContentType("text/json;charset=utf-8");
			response.getWriter().write(result());
			response.getWriter().flush();
			return false;
		} else {
			return true;
		}
	}

	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
	}
	
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
	}

}
