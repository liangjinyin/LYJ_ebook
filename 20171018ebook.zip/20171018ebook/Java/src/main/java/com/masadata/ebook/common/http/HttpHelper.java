package com.masadata.ebook.common.http;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class HttpHelper {
	
	private static Logger logger = LoggerFactory.getLogger(HttpHelper.class);

	public HttpHelper() {
		this(new DefaultHttpResponseParser());
	}
	public HttpHelper(HttpResponseParser resParser) {
		this.resParser = resParser;
	}
	private HttpResponseParser resParser;
	
	public CommonHttpResponse httpGet(String url, JSONObject params) throws Exception {
		logger.info("reqest url:" + url + ";params:" + JSON.toJSONString(params));
		StringBuilder urlSb = new StringBuilder();
		if(url.indexOf("?") > -1) {
			urlSb.append(url);
		} else {
			urlSb.append(url).append("?");
		}
		if(params != null) {
			for(String key : params.keySet()) {
				urlSb.append("&").append(key).append("=").append(params.get(key));
			}
		}
		logger.info("get request url:" + urlSb.toString());
		HttpClient client = HttpClientBuilder.create()
				.build();
		HttpGet get = new HttpGet(urlSb.toString());
		HttpResponse response = client.execute(get);
		return resParser.parseHttpResponse(response);
	}
	
	public CommonHttpResponse httpPostWithStringStream(String url, JSONObject params) throws Exception {
		HttpEntity entity = null;
		if(params != null && !params.isEmpty()) {
			entity = new StringEntity(params.toString(), Charset.forName("utf-8"));  
		}
		return httpPost(url, entity);
	}
	

	public CommonHttpResponse httpPostWithKeyValueStream(String url, JSONObject params) throws Exception {
		HttpEntity entity = null;
		if(params != null) {
			List<NameValuePair> list = new ArrayList<NameValuePair>();  
			Iterator<Entry<String, Object>> iterator = params.entrySet().iterator();  
			while(iterator.hasNext()){  
				Entry<String,Object> elem = (Entry<String, Object>) iterator.next();  
				list.add(new BasicNameValuePair(elem.getKey(),String.valueOf(elem.getValue())));  
			}  
			if(list.size() > 0){  
				entity = new UrlEncodedFormEntity(list, Charset.forName("utf-8"));  
			}
		}
		return httpPost(url, entity);
	}
	
	private CommonHttpResponse httpPost(String url, HttpEntity entity) throws Exception {
		logger.info("post request url:" + url);
		HttpClient client = HttpClientBuilder.create()
				.build();
		HttpPost post = new HttpPost(url);
		if(entity != null) {
			post.setEntity(entity);
		}
		HttpResponse response = client.execute(post);
		return resParser.parseHttpResponse(response);
	}
	
}
