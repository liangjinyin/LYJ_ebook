package com.masadata.ebook.wxapp.api.request;

import org.apache.http.HttpStatus;

import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class WXUserBaseInfoRequest {

	private static final String URL = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=%s&openid=%s&lang=zh_CN";
	String accessToken;
	String openid;
	public WXUserBaseInfoRequest(String accessToken, String openid) {
		this.accessToken = accessToken;
		this.openid = openid;
	}
	
	public String getWXUserBaseInfo() throws Exception {
		String url = String.format(URL, accessToken, openid);
		CommonHttpResponse response = new HttpHelper().httpGet(url, null);
		if(HttpStatus.SC_OK == response.getRetCode()) {
			return response.getEntityStr();
		} else {
			return response.toString();
		}
	}
	
}
