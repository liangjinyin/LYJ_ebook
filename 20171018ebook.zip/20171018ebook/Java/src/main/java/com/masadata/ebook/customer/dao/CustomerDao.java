package com.masadata.ebook.customer.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.masadata.ebook.customer.entity.CustAttr;
import com.masadata.ebook.customer.entity.CustReport;
import com.masadata.ebook.customer.entity.CustStatusRecord;
import com.masadata.ebook.customer.entity.Customer;
import com.masadata.ebook.user.entity.User;

@Mapper
public interface CustomerDao {

	//案场置业顾问查看未补全信息的到访客户
	@Select("select a.id, a.name, a.mobile, a.visits, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '到访' and del_flag = 0 group by cust_id)b "
			+ "on a.id = b.cust_id "
			+ "and a.`completion` <> '100%' and a.del_flag = 0 and a.`status` = '到访' "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "limit ${rowNum}, ${pageSize}")
	List<Map<String, Object>> getIncompleteVisitorList(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize);
	@Select("select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "and a.`completion` <> '100%' and a.del_flag = 0 and a.`status` = '到访' "
			+ "where c.openid = #{openid} and c.case_id = ${caseId} ")
	Integer getIncompleteVisitorCount(User user);
	
	//案场管理员查看未补全信息的到访客户列表
	@Select("select a.id, a.name, a.mobile, if(a.consultant_name is null, '--', a.consultant_name) consultantName, a.visits, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '到访' and del_flag = 0 group by cust_id)b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '到访' and a.`completion` <> '100%' and a.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "limit ${rowNum}, ${pageSize}")
	List<Map<String, Object>> getIncompleteVisitorListByAdmin(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize);
	@Select("select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "and a.`completion` <> '100%' and a.del_flag = 0 and a.`status` = '到访' "
			+ "where c.openid = #{openid} and c.case_id = ${caseId} ")
	Integer getIncompleteVisitorCountByAdmin(User user);
	
	//置业顾问 查看到访客户
	@Select("<script>"
			+ "select a.id, a.name, a.mobile, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '到访' and del_flag = 0 group by cust_id)b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '到访' and a.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>"
			)
	List<Map<String, Object>> getVisitorList(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize, @Param("statDate") String statDate);
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and a.`status` = '到访' and a.del_flag = 0 "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "</script>"
			)
	Integer getVisitorCount(@Param("user") User user, @Param("statDate") String statDate);
	
	//管理员 查看到访客户
	@Select("<script>"
			+ "select a.id, a.name, a.mobile, if(a.consultant_name is null, '--', a.consultant_name) consultantName, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '到访' and del_flag = 0 group by cust_id) b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '到访' and a.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>"
			)
	List<Map<String, Object>> getVisitorListByAdmin(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize, @Param("statDate") String statDate);
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "and a.`status` = '到访' and a.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "</script>"
			)
	Integer getVisitorCountByAdmin(@Param("user") User user, @Param("statDate") String statDate);
	
	//置业顾问 多次到访客户
	@Select("<script>"
			+ "select a.id, a.name, a.mobile, a.visits, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '到访' and del_flag = 0 group by cust_id) b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '到访' and a.del_flag = 0 and a.visits > 1 "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>"
			)
	List<Map<String, Object>> getMultiVisitVisitorList(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize, @Param("statDate") String statDate);
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "and a.`status` = '到访' and a.visits > 1 and a.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "</script>"
			)
	Integer getMultiVisitVisitorCount(@Param("user") User user, @Param("statDate") String statDate);
	
	//管理员 多次到访客户
	@Select("<script>"
			+ "select a.id, a.name, a.mobile, a.visits, if(a.consultant_name is null, '--', a.consultant_name)consultantName, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '到访' and del_flag = 0 group by cust_id) b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '到访' and a.del_flag = 0 and a.visits > 1 "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>"
			)
	List<Map<String, Object>> getMultiVisitVisitorListByAdmin(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize, @Param("statDate") String statDate);
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and a.`status` = '到访' and a.visits > 1 and a.del_flag = 0 "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "</script>"
			)
	Integer getMultiVisitVisitorCountByAdmin(@Param("user") User user, @Param("statDate") String statDate);
	
	//置业顾问 成交客户
	@Select("<script>"
			+ "select a.id, a.name, a.mobile, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '成交' and del_flag = 0 group by cust_id) b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '成交' and a.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>"
			)
	List<Map<String, Object>> getDealCustList(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize, @Param("statDate") String statDate);
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.consultant = c.user_id and a.case_id = c.case_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "and a.`status` = '成交' and a.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "</script>"
			)
	Integer getDealCustCount(@Param("user") User user, @Param("statDate") String statDate);

	//管理员 成交客户
	@Select("<script>"
			+ "select a.id, a.name, a.mobile, if(a.consultant_name is null, '--', a.consultant_name)consultantName, date_format(b.record_time, '%Y-%m-%d') recordTime "
			+ "from customer a "
			+ "join (select cust_id, max(record_time) record_time from customer_status_record where `status` = '成交' and del_flag = 0 group by cust_id) b "
			+ "on a.id = b.cust_id "
			+ "and a.`status` = '成交' and a.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>"
			)
	List<Map<String, Object>> getDealCustListByAdmin(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize, @Param("statDate") String statDate);
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "and a.`status` = '成交' and a.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "<if test=\"statDate != null and statDate != ''\">"
			+ "and a.last_record_date = #{statDate} "
			+ "</if>"
			+ "</script>"
			)
	Integer getDealCustCountByAdmin(@Param("user") User user, @Param("statDate") String statDate);
	
	//置业顾问  获取客户列表
	@Select("<script>"
			+ "select a.id, a.name, a.first_letter firstLetter, a.mobile "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id and a.consultant = b.user_id "
			+ "and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.admin_flag = 0 "
			+ "where b.case_id = ${user.caseId} and b.openid = #{user.openid} "
			+ "<if test=\"user.name != null and user.name != ''\">"
			+ "and a.name like concat('%', #{user.name}, '%') "
			+ "</if>"
			+ "<if test=\"user.mobile != null and user.mobile != ''\">"
			+ "and a.mobile like concat('%', #{user.mobile}, '%') "
			+ "</if>"
			+ "order by a.first_letter, a.name "
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>")
	List<Map<String, Object>> getCustListByNameOrMobile(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize);
	//置业顾问 获取总客户数
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id and a.consultant = b.user_id "
			+ "and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.admin_flag = 0 "
			+ "where b.case_id = ${user.caseId} and b.openid = #{user.openid} "
			+ "<if test=\"user.name != null and user.name != ''\">"
			+ "and a.name like concat('%', #{user.name}, '%') "
			+ "</if>"
			+ "<if test=\"user.mobile != null and user.mobile != ''\">"
			+ "and a.mobile like concat('%', #{user.mobile}, '%') "
			+ "</if>"
			+ "</script>")
	int getCustCountByNameOrMobile(@Param("user") User user);
	
	//管理员  获取客户列表
	@Select("<script>"
			+ "select a.id, a.name, a.first_letter firstLetter, a.mobile "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id "
			+ "and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.admin_flag = 1 "
			+ "where b.case_id = ${user.caseId} and b.openid = #{user.openid} "
			+ "<if test=\"user.name != null and user.name != ''\">"
			+ "and a.name like concat('%', #{user.name}, '%') "
			+ "</if>"
			+ "<if test=\"user.mobile != null and user.mobile != ''\">"
			+ "and a.mobile like concat('%', #{user.mobile}, '%') "
			+ "</if>"
			+ "order by a.first_letter, a.name "
			+ "limit ${rowNum}, ${pageSize} "
			+ "</script>")
	List<Map<String, Object>> getCustListByAdminWithNameOrMobile(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize);
	//管理员  获取总客户数
	@Select("<script>"
			+ "select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id "
			+ "and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.admin_flag = 1 "
			+ "where b.case_id = ${user.caseId} and b.openid = #{user.openid} "
			+ "<if test=\"user.name != null and user.name != ''\">"
			+ "and a.name like concat('%', #{user.name}, '%') "
			+ "</if>"
			+ "<if test=\"user.mobile != null and user.mobile != ''\">"
			+ "and a.mobile like concat('%', #{user.mobile}, '%') "
			+ "</if>"
			+ "</script>")
	int getCustCountByAdminWithNameOrMobile(@Param("user") User user);
		
	//置业顾问 获取客户访问记录
	@Select("select b.id, b.cust_id custId, a.name, date_format(b.record_time, '%Y-%m-%d') visitDate, date_format(b.record_time, '%H:%i') recordTime "
			+ "from customer a "
			+ "join customer_status_record b "
			+ "on a.id = b.cust_id "
			+ "and a.del_flag = 0 "
			+ "and b.`status` = '到访' and b.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id and a.consultant = c.user_id "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "order by b.record_time desc "
			+ "limit ${rowNum}, ${pageSize} ")
	List<Map<String, Object>> getAllVisitList(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize);
	//置业顾问 获取客户访问总次数
	@Select("select count(1) visits "
			+ "from customer a "
			+ "join customer_status_record b "
			+ "on a.id = b.cust_id and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.`status` = '到访' "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id and a.consultant = c.user_id "
			+ "and a.del_flag = 0 "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where c.openid = #{openid} and c.case_id = ${caseId} ")
	Integer getAllVisitCount(User user);
	
	//管理员 获取客户访问记录
	@Select("select b.id, b.cust_id custId, a.name, date_format(b.record_time, '%Y-%m-%d') visitDate, date_format(b.record_time, '%H:%i') recordTime "
			+ "from customer a "
			+ "join customer_status_record b "
			+ "on a.id = b.cust_id "
			+ "and a.del_flag = 0 "
			+ "and b.`status` = '到访' and b.del_flag = 0 "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{user.openid} and c.case_id = ${user.caseId} "
			+ "order by b.record_time desc "
			+ "limit ${rowNum}, ${pageSize} ")
	List<Map<String, Object>> getAllVisitListByAdmin(@Param("user") User user, @Param("rowNum") int rowNum, @Param("pageSize") int pageSize);
	//管理员  获取客户访问总次数
	@Select("select count(1) visits "
			+ "from customer a "
			+ "join customer_status_record b "
			+ "on a.id = b.cust_id and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.`status` = '到访' "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and a.del_flag = 0 "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where c.openid = #{openid} and c.case_id = ${caseId} ")
	Integer getAllVisitCountByAdmin(User user);
	
	//验证用户对客户的访问权限
	@Select("select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id and a.consultant = c.user_id "
			+ "and a.del_flag = 0 "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where a.id = ${id} and c.openid = #{user.openid} and c.case_id = ${user.caseId} ")
	Integer checkCustExist(@Param("user") User user, @Param("id") String id);
	@Select("select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and a.del_flag = 0 "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where a.id = ${id} "
			+ "and c.openid = #{user.openid} and c.case_id = ${user.caseId} ")
	Integer checkCustExistByAdmin(@Param("user") User user, @Param("id") String id);
	@Select("select a.name, a.`status`, a.last_record_date lastRecordDate, a.consultant_name consultantName, a.consultant_no consultantNo "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id and a.consultant = c.user_id "
			+ "and a.del_flag = 0 "
			+ "and c.admin_flag = 0 and c.del_flag = 0 "
			+ "where a.mobile = #{mobile} and c.openid = #{user.openid} and c.case_id = ${user.caseId} ")
	Customer getCustInfoByMobileAndCaseWorker(@Param("user") User user, @Param("mobile") String mobile);
	@Select("select a.name, a.`status`, a.last_record_date lastRecordDate, a.consultant_name consultantName, a.consultant_no consultantNo "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and a.del_flag = 0 "
			+ "and c.admin_flag = 1 and c.del_flag = 0 "
			+ "where a.mobile = #{mobile} "
			+ "and c.openid = #{user.openid} and c.case_id = ${user.caseId} ")
	Customer getCustInfoByMobileAndCaseAdmin(@Param("user") User user, @Param("mobile") String mobile);
	@Select("select count(1) "
			+ "from customer a "
			+ "join salesoffice_worker c "
			+ "on a.case_id = c.case_id "
			+ "and a.del_flag = 0 "
			+ "and c.del_flag = 0 "
			+ "where a.mobile = #{mobile} "
			+ "and c.openid = #{user.openid} and c.case_id = ${user.caseId} ")
	Integer checkCustMobileExist(@Param("user") User user, @Param("mobile") String mobile);
	@Select("select a.id, a.name, a.first_letter firstLetter, a.gender, a.age, a.mobile, a.case_id caseId, "
			+ "a.consultant, a.consultant_name consultantName, a.consultant_no consultantNo, a.remark, "
			+ "a.intent_level intentLevel, a.intent_project intentProject, a.intent_project_label intentProjectLabel, "
			+ "a.intent_apart_type intentApartType, a.intent_apart_type_label intentApartTypeLabel, "
			+ "a.`status`, a.last_record_date, "
			+ "a.visits, a.deals "
			+ "from customer a "
			+ "where a.mobile = #{mobile} and a.case_id = ${caseId} and del_flag = 0 ")
	Customer getCustInfoByMobile(@Param("mobile") String mobile, @Param("caseId") String caseId);
	//新建客户
	@Insert("insert into customer("
			+ "  case_id, name, first_letter, gender, age, mobile, mobile_mac, hanming, status, last_record_date, remark"
			+ ", consultant, consultant_name, consultant_no, intent_project, intent_project_label, intent_level"
			+ ", visits, deals"
			+ ", create_time, create_by, update_time, update_by"
			+ ") "
			+ "values("
			+ "  #{caseId}, #{name}, #{firstLetter}, #{gender}, #{age}, #{mobile}, #{mobileMac}, #{hanming}, #{status}, #{lastRecordDate}, #{remark}"
			+ ", #{consultant}, #{consultantName}, #{consultantNo}, #{intentProject}, #{intentProjectLabel}, #{intentLevel}"
			+ ", ${visits}, ${deals}"
			+ ", #{createTime}, #{createBy}, #{updateTime}, #{updateBy}"
			+ ")")
	@SelectKey(before = false, keyProperty = "id", resultType = Integer.class, statement = { "select last_insert_id()" })
	Integer addCust(Customer cust);
	@Update("update customer "
			+ "set name=#{name}, first_letter=#{firstLetter}, gender=#{gender}, age=#{age}, mobile=#{mobile} "
			+ ", remark=#{remark}, intent_level=#{intentLevel} "
			+ ", intent_project=#{intentProject}, intent_project_label=#{intentProjectLabel} "
			+ ", intent_apart_type=#{intentApartType}, intent_apart_type_label=#{intentApartTypeLabel} "
			+ ", update_time=now(), update_by=#{updateBy} "
			+ "where id = ${id} ")
	Integer updateCust(Customer cust);
	@Update("update customer "
			+ "set name=#{name}, first_letter=#{firstLetter}, mobile_mac=#{mobileMac}, hanming=#{hanming}, gender=#{gender}, status=#{status}, visits=${visits}, update_time=now(), update_by=#{updateBy} "
			+ "where id = ${id} ")
	Integer updateCustByClientRegister(Customer cust);
	@Update("update customer "
			+ "set completion = #{completion} "
			+ "where id = ${id} ")
	Integer updateCustCompletion(@Param("id") int id, @Param("completion") String completion);
	@Update("update customer a, "
			+ "(select count(1) visits from customer_status_record where cust_id = ${id} and del_flag = 0 and `status` = '到访')t1, "
			+ "(select count(1) deals from customer_status_record where cust_id = ${id} and del_flag = 0 and `status` = '成交')t2 "
			+ "set a.`status` = (case when t2.deals > 0 then '成交' when t1.visits > 0 then '到访' else '来电' end), "
			+ "a.visits = t1.visits, "
			+ "a.deals = t2.deals "
			+ "where a.id = ${id} ")
	Integer updateCustStatusAndDealsAndVisits(@Param("id") int id);
	//增加客户状态记录
	@Insert("insert into customer_status_record("
			+ "  cust_id, status, record_time, deal_apart_type, deal_apart_type_label"
			+ ", create_time, create_by, update_time, update_by) "
			+ "values("
			+ "  #{custId}, #{status}, #{recordTime}, #{dealApartType}, #{dealApartTypeLabel}"
			+ ", now(), #{createBy}, now(), #{updateBy}"
			+ ")")
	Integer insertCustStatusRecord(CustStatusRecord record);
	@Update("update customer_status_record "
			+ "set del_flag = 1 "
			+ "where cust_id = ${custId} and `status` = '到访' ")
	Integer deleteCustVisitRecord(@Param("custId") int custId);
	@Update("update customer_status_record "
			+ "set del_flag = 1 "
			+ "where cust_id = ${custId} and `status` = '成交' ")
	Integer deleteCustDealRecord(@Param("custId") int custId);
	@Update("update customer_additional_attr "
			+ "set del_flag = 1 "
			+ "where cust_id = ${custId} and attr_id = ${attrId} ")
	Integer deleteCustAttr(@Param("custId") int custId, @Param("attrId") int attrId);
	@Update("update customer_additional_attr "
			+ "set del_flag = 1 "
			+ "where cust_id = ${custId} ")
	Integer deleteCustAttrs(@Param("custId") int custId);
	@Insert("insert into customer_additional_attr(cust_id, attr_id, attr_value, attr_value_label) "
			+ "values(${custId}, ${id}, #{value}, #{valueLabel}) ")
	Integer insertCustAttr(CustAttr custAttr);
	
	@Update("update customer a, "
			+ "(select cust_id, `status`, max(record_time) record_time from customer_status_record where del_flag = 0 group by cust_id, `status`) b "
			+ "set a.last_record_date = date_format(b.record_time, '%Y-%m-%d') "
			+ "where a.id = b.cust_id and a.`status` = b.`status` "
			+ "and a.id = ${id} ")
	Integer updateStatusLastRecordDate(@Param("id") Integer id);
	//获取客户信息
	@Select("select id, name, gender, age, mobile, completion, remark, "
			+ "status, visits, deals, intent_level intentLevel, "
			+ "intent_project intentProject, intent_project_label intentProjectLabel, "
			+ "intent_apart_type intentApartType, intent_apart_type_label intentApartTypeLabel "
			+ "from customer "
			+ "where id = ${id} and del_flag = 0 ")
	/*@Results({
		@Result(column="id", property="visitList", many=@Many(select="com.masa.ebook.customer.dao.getCustVisitList")), 
		@Result(column="id", property="dealList", many=@Many(select="com.masa.ebook.customer.dao.getCustDealList")),
		@Result(column="id", property="attrs", many=@Many(select="com.masa.ebook.customer.dao.getCustAttrs")),
	})*/
	Map<String, Object> getCustDetail(@Param("id") String id);
	@Select("select id, name, first_letter firstLetter, gender, age, mobile, completion, remark, case_id caseId, consultant, "
			+ "status, visits, deals, intent_level intentLevel, "
			+ "intent_project intentProject, intent_project_label intentProjectLabel, "
			+ "intent_apart_type intentApartType, intent_apart_type_label intentApartTypeLabel "
			+ "from customer "
			+ "where case_id = ${caseId} and mobile_mac = #{mobileMac} and del_flag = 0 ")
	Customer getCustDetailByMac(@Param("caseId") String caseId, @Param("mobileMac")String mobileMac);
	
	@Select("select id, record_time recordTime "
			+ "from customer_status_record "
			+ "where del_flag = 0 and cust_id = ${custId} and `status` = '到访' ")
	List<CustStatusRecord> getCustVisitList(@Param("custId") String custId);

	@Select("select id, record_time recordTime, deal_apart_type dealApartType, deal_apart_type_label dealApartTypeLabel "
			+ "from customer_status_record "
			+ "where del_flag = 0 and cust_id = ${custId} and `status` = '成交' ")
	List<CustStatusRecord> getCustDealList(@Param("custId") String custId);
	
	@Select("select a.attr_id id, a.attr_value value, a.attr_value_label valueLabel "
			+ "from customer_additional_attr a, salesoffice_cust_attr b "
			+ "where a.cust_id = ${custId} and a.del_flag = 0 "
			+ "and a.attr_id = b.id and b.del_flag = 0 ")
	List<CustAttr> getCustAttrs(@Param("custId") String custId);
	
	//删除客户
	@Update("update customer a, salesoffice_worker c "
			+ "set a.del_flag = 1, a.update_time = now(), a.update_by = c.user_id "
			+ "where a.case_id = c.case_id "
			+ "and a.id = ${id} "
			+ "and c.openid = #{user.openid} and c.case_id = ${user.caseId} ")
	Integer delCust(@Param("user") User user, @Param("id") String id);
	
	//日报历史
	/*@Select("select stat_date statDate, stat_weekday statWeekday, visitors, multi_visit_visitors multiVisitVisitors, deal_customers dealCustomers "
			+ "from customer_stat_daily "
			+ "where openid = #{openid} and case_id = ${caseId} "
			+ "order by stat_date desc "
			+ "limit 30 ")*/
	//个人实时日报查看
	@Select("select * from ("
			+ "select substr(a.last_record_date, 1, 7) statMonth, a.last_record_date statDate, "
			+ "	(case date_format(a.last_record_date, '%w') "
			+ "		when 0 then '周日' "
			+ "		when 1 then '周一' "
			+ "		when 2 then '周二' "
			+ "		when 3 then '周三' "
			+ "		when 4 then '周四' "
			+ "		when 5 then '周五' "
			+ "		when 6 then '周六' end) statWeekday, "
			+ "	b.user_id userId, b.openid, b.case_id caseId, "
			+ "	sum(case when a.`status` = '到访' then 1 else 0 end) visitors, "
			+ "	sum(case when a.`status` = '到访' and a.visits > 1 then 1 else 0 end) multiVisitVisitors, "
			+ "	sum(case when a.`status` = '成交' then 1 else 0 end) dealCustomers "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id and a.consultant = b.user_id "
			+ "and a.del_flag = 0 and a.last_record_date between #{beginDate} and #{endDate} "
			+ "where b.openid = #{user.openid} and b.case_id = ${user.caseId} "
			+ "and b.admin_flag = 0 and b.del_flag = 0 "
			+ "group by b.user_id, b.openid, b.case_id, a.last_record_date "
			+ "union "
			+ "select substr(a.last_record_date, 1, 7) statMonth, a.last_record_date statDate, "
			+ "	(case date_format(a.last_record_date, '%w') "
			+ "		when 0 then '周日' "
			+ "		when 1 then '周一' "
			+ "		when 2 then '周二' "
			+ "		when 3 then '周三' "
			+ "		when 4 then '周四' "
			+ "		when 5 then '周五' "
			+ "		when 6 then '周六' end) statWeekday, "
			+ "	b.user_id userId, b.openid, b.case_id caseId, "
			+ "	sum(case when a.`status` = '到访' then 1 else 0 end) visitors, "
			+ "	sum(case when a.`status` = '到访' and a.visits > 1 then 1 else 0 end) multiVisitVisitors, "
			+ "	sum(case when a.`status` = '成交' then 1 else 0 end) dealCustomers "
			+ "from customer a "
			+ "right join salesoffice_worker b "
			+ "on a.case_id = b.case_id "
			+ "and a.del_flag = 0 and a.last_record_date between #{beginDate} and #{endDate} "
			+ "where b.openid = #{user.openid} and b.case_id = ${user.caseId} "
			+ "and b.admin_flag = 1 and b.del_flag = 0 "
			+ "group by b.user_id, b.openid, b.case_id, a.last_record_date "
			+ ")t "
			+ "order by statDate desc ")
	List<CustReport> getCustReportByUser(@Param("user") User user, @Param("beginDate") String beginDate, @Param("endDate") String endDate);
	/*@Select("select visitors, multi_visit_visitors multiVisitVisitors, deal_customers dealCustomers "
			+ "from customer_stat_daily "
			+ "where stat_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') and openid = #{openid} and case_id = ${caseId} ")*/
	@Select("select a.last_record_date statDate, "
			+ "	(case date_format(a.last_record_date, '%w') "
			+ "		when 0 then '周日' "
			+ "		when 1 then '周一' "
			+ "		when 2 then '周二' "
			+ "		when 3 then '周三' "
			+ "		when 4 then '周四' "
			+ "		when 5 then '周五' "
			+ "		when 6 then '周六' end) stateWeekday, "
			+ "	b.user_id userId, b.openid, b.case_id caseId, "
			+ "	sum(case when a.`status` = '到访' then 1 else 0 end) visitors, "
			+ "	sum(case when a.`status` = '到访' and a.visits > 1 then 1 else 0 end) multiVisitVisitors, "
			+ "	sum(case when a.`status` = '成交' then 1 else 0 end) dealCustomers "
			+ "from customer a "
			+ "right join salesoffice_worker b "
			+ "on a.case_id = b.case_id and a.consultant = b.user_id "
			+ "and a.last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') "
			+ "and a.del_flag = 0 "
			+ "where b.openid = #{openid} and b.case_id = ${caseId} "
			+ "and b.admin_flag = 0 and b.del_flag = 0 "
			+ "group by b.user_id, b.openid, b.case_id, a.last_record_date "
			+ "union "
			+ "select a.last_record_date statDate, "
			+ "	(case date_format(a.last_record_date, '%w') "
			+ "		when 0 then '周日' "
			+ "		when 1 then '周一' "
			+ "		when 2 then '周二' "
			+ "		when 3 then '周三' "
			+ "		when 4 then '周四' "
			+ "		when 5 then '周五' "
			+ "		when 6 then '周六' end) stateWeekday, "
			+ "	b.user_id userId, b.openid, b.case_id caseId, "
			+ "	sum(case when a.`status` = '到访' then 1 else 0 end) visitors, "
			+ "	sum(case when a.`status` = '到访' and a.visits > 1 then 1 else 0 end) multiVisitVisitors, "
			+ "	sum(case when a.`status` = '成交' then 1 else 0 end) dealCustomers "
			+ "from customer a "
			+ "right join salesoffice_worker b "
			+ "on a.case_id = b.case_id "
			+ "and a.last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') "
			+ "and a.del_flag = 0 "
			+ "where b.openid = #{openid} and b.case_id = ${caseId} "
			+ "and b.admin_flag = 1 and b.del_flag = 0 "
			+ "group by b.user_id, b.openid, b.case_id, a.last_record_date ")
	CustReport getYesterdayCustReportByUser(User user);
	/*@Select("select user_id userId, openid, case_id caseId, visitors, multi_visit_visitors multiVisitVisitors, deal_customers dealCustomers "
			+ "from customer_stat_daily "
			+ "where stat_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') ")*/
	@Select("select a.last_record_date statDate, "
			+ "	(case date_format(a.last_record_date, '%w') "
			+ "		when 0 then '周日' "
			+ "		when 1 then '周一' "
			+ "		when 2 then '周二' "
			+ "		when 3 then '周三' "
			+ "		when 4 then '周四' "
			+ "		when 5 then '周五' "
			+ "		when 6 then '周六' end) stateWeekday, "
			+ "	b.user_id userId, b.openid, b.case_id caseId, "
			+ "	sum(case when a.`status` = '到访' then 1 else 0 end) visitors, "
			+ "	sum(case when a.`status` = '到访' and a.visits > 1 then 1 else 0 end) multiVisitVisitors, "
			+ "	sum(case when a.`status` = '成交' then 1 else 0 end) dealCustomers "
			+ "from customer a "
			+ "right join salesoffice_worker b "
			+ "on a.case_id = b.case_id and a.consultant = b.user_id "
			+ "and a.last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') "
			+ "and a.del_flag = 0 "
			+ "where b.admin_flag = 0 and b.del_flag = 0 "
			+ "group by b.user_id, b.openid, b.case_id, a.last_record_date "
			+ "union "
			+ "select a.last_record_date statDate, "
			+ "	(case date_format(a.last_record_date, '%w') "
			+ "		when 0 then '周日' "
			+ "		when 1 then '周一' "
			+ "		when 2 then '周二' "
			+ "		when 3 then '周三' "
			+ "		when 4 then '周四' "
			+ "		when 5 then '周五' "
			+ "		when 6 then '周六' end) stateWeekday, "
			+ "	b.user_id userId, b.openid, b.case_id caseId, "
			+ "	sum(case when a.`status` = '到访' then 1 else 0 end) visitors, "
			+ "	sum(case when a.`status` = '到访' and a.visits > 1 then 1 else 0 end) multiVisitVisitors, "
			+ "	sum(case when a.`status` = '成交' then 1 else 0 end) dealCustomers "
			+ "from customer a "
			+ "right join salesoffice_worker b "
			+ "on a.case_id = b.case_id "
			+ "and a.last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') "
			+ "and a.del_flag = 0 "
			+ "where b.admin_flag = 1 and b.del_flag = 0 "
			+ "group by b.user_id, b.openid, b.case_id, a.last_record_date ")
	List<CustReport> getYesterdayCustReport();
	
	//生成日报
	@Delete("delete from customer_stat_daily "
			+ "where stat_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') ")
	Integer deleteYesterdayStat();
	@Insert("insert into customer_stat_daily "
			//生成置业顾问的客户日报
			+ "select date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') stat_date, "
			+ "(case date_format(date_sub(now(), interval 1 day), '%w') "
			+ "		 when 0 then '周日' "
			+ "		 when 1 then '周一' "
			+ "		 when 2 then '周二' "
			+ "		 when 3 then '周三' "
			+ "		 when 4 then '周四' "
			+ "		 when 5 then '周五' "
			+ "		 when 6 then '周六' end) state_weekday, "
			+ "b.user_id, b.openid, b.case_id, "
			+ "sum(case when a.`status` = '到访' and last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') then 1 else 0 end) visitors, "
			+ "sum(case when a.`status` = '到访' and last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') and a.visits > 1 then 1 else 0 end) multi_visit_visitors, "
			+ "sum(case when a.`status` = '成交' and last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') then 1 else 0 end) deal_customers "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id and a.consultant = b.user_id "
			+ "and b.admin_flag = 0 and b.del_flag = 0 "
			+ "and a.del_flag = 0 "
			+ "group by user_id, openid, case_id "
			+ "union "
			//生成案场管理员的客户日报
			+ "select date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') stat_date, "
			+ "(case date_format(date_sub(now(), interval 1 day), '%w') "
			+ "		 when 0 then '周日' "
			+ "		 when 1 then '周一' "
			+ "		 when 2 then '周二' "
			+ "		 when 3 then '周三' "
			+ "		 when 4 then '周四' "
			+ "		 when 5 then '周五' "
			+ "		 when 6 then '周六' end) state_weekday, "
			+ "b.user_id, b.openid, b.case_id, "
			+ "sum(case when a.`status` = '到访' and last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') then 1 else 0 end) visitors, "
			+ "sum(case when a.`status` = '到访' and last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') and a.visits > 1 then 1 else 0 end) multi_visit_visitors, "
			+ "sum(case when a.`status` = '成交' and last_record_date = date_format(date_sub(now(), interval 1 day), '%Y-%m-%d') then 1 else 0 end) deal_customers "
			+ "from customer a "
			+ "join salesoffice_worker b "
			+ "on a.case_id = b.case_id "
			+ "and b.admin_flag = 1 and b.del_flag = 0 "
			+ "and a.del_flag = 0 "
			+ "group by user_id, openid, case_id ")
	Integer statCustDaily();
}
