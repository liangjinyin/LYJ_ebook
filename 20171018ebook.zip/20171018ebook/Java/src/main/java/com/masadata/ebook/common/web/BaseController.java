package com.masadata.ebook.common.web;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.masadata.ebook.common.constants.ResultCode;


public abstract class BaseController {

	protected Logger logger = LoggerFactory.getLogger(getClass());
	protected ResultCode retCode = null;
	protected Object data = null;
	
	public String result() {
		Map<String, Object> result = new HashMap<String, Object>();
		if(retCode == null) {
			retCode = ResultCode.NONE;
		}
		result.put("retCode", retCode.getResultCode());
		result.put("retMsg", retCode.getResultMsg());
		result.put("data", data);
		return JSON.toJSONString(result, SerializerFeature.DisableCircularReferenceDetect, SerializerFeature.WriteMapNullValue);
	}
	
}
