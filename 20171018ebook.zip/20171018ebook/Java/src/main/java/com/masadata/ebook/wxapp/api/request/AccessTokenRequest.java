package com.masadata.ebook.wxapp.api.request;

import org.apache.http.HttpStatus;

import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class AccessTokenRequest {
	
		
		String appID;
		String appSecret;
		private final static String URL = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s";
		
		public AccessTokenRequest(String appID, String appSecret) {
			this.appID = appID;
			this.appSecret = appSecret;
		}
		
		public String getAccessToken() throws Exception {
			String url = String.format(URL, appID, appSecret);
			CommonHttpResponse response = new HttpHelper().httpGet(url, null);
			if(HttpStatus.SC_OK == response.getRetCode()) {
				return response.getEntityStr();
			} else {
				return response.toString();
			}
		}
		
}
