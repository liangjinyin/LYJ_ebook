package com.masadata.ebook.wxapp.service;

import java.net.URLEncoder;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.wxapp.api.request.MenuCreateRequest;
import com.masadata.ebook.wxapp.api.request.WebAccessTokenRequest;
import com.masadata.ebook.wxapp.dao.CaseWXAppDao;
import com.masadata.ebook.wxapp.entity.CaseWXApp;

@Service
@Transactional(readOnly=true)
public class WXAppService {

	@Autowired
	UserDao userDao;
	@Autowired
	CaseWXAppDao appDao;
	@Autowired
	AccessTokenService tokenService;
	@Autowired
	JSApiTicketService ticketService;
	
	private static final String nonceStr = "masa.123";
	
	public Object getWXUserInfo(String caseId, String code, String contextPath) {
		//根据caseid获取公众号appsecret信息
		CaseWXApp app = appDao.getCaseWXAppInfo(caseId);
		if(app == null || StringUtils.isEmpty(app.getAppID())) {
			app = new CaseWXApp();
			app.setAppID(AppConfig.EBOOK_APP_ID);
			app.setAppSecret(AppConfig.EBOOK_APP_SECRET);
			app.setWebHost(AppConfig.EBOOK_WEB_HOST);
		}
		try {
			JSONObject data = new JSONObject();
			JSONObject json = JSON.parseObject(new WebAccessTokenRequest(app.getAppID(), app.getAppSecret(), code).getAccessTokenAndOpenID());
			if(json.containsKey("retCode")) {
				return ResultCode.OPENID_REQEUST_FAILED;
			} else if(json.containsKey("errcode")) {
				return ResultCode.createCustomResultCode(json.getString("errcode"), json.getString("errmsg"));
			} else {
				String newCaseId = userDao.getUserBindedCaseByWXOpenID(json.getString("openid"));
				boolean binded = !StringUtils.isEmpty(newCaseId);
				data.put("caseId", newCaseId);
				data.put("appID", app.getAppID());
				data.put("openid", json.getString("openid"));
				data.put("binded", binded);
				//获取jsapi_ticket，生成签名
				String ticket = ticketService.getWXAppJSApiTicket(app.getAppID());
				Long timestamp = System.currentTimeMillis() / 1000;
				String url = app.getWebHost() + (contextPath.startsWith("/") ? "" : "/") + contextPath;
				data.put("signature", createJSApiSignature(ticket, timestamp, URLEncoder.encode(url, "utf-8")));
				data.put("nonceStr", nonceStr);
				data.put("timestamp", timestamp);
				return data;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ResultCode.OPENID_REQEUST_FAILED;
		}
	}
	
	public static void main(String args[]) {
		String ticket = "HoagFKDcsGMVCIY2vOjf9oI0-APXU2V1_J7mDOfKnrvuACC1h5dV85bY8naMJq3moQS6N9SELlA-n6nZymNLtg";
		System.out.println(createJSApiSignature(ticket, Long.valueOf("123"), "http://boss.vigortech.cn/api/wxapp/msg/handle/1999"));
	}
	
	public static String createJSApiSignature(String ticket, Long timestamp, String url) {
		StringBuffer sb = new StringBuffer();
		sb.append("jsapi_ticket=" + ticket);
		sb.append("&noncestr=" + nonceStr);
		sb.append("&timestamp=" + timestamp);
		sb.append("&url=" + url);
		return DigestUtils.sha1Hex(sb.toString());
	}
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode initWXApp(String caseId) {
		try {
			CaseWXApp app = appDao.getCaseWXAppInfo(caseId);
			JSONObject result = JSON.parseObject(new MenuCreateRequest(tokenService.getAccessToken(caseId), app.getWebHost(), app.getAppID(), caseId).initMenu());
			if(result.containsKey("errcode") && result.getIntValue("errcode") != 0) {
				return ResultCode.createCustomResultCode("" + result.getIntValue("errcode"), result.getString("errmsg"));
			}
			return ResultCode.OPERATION_SUCCESSED;
		} catch(Exception e) {
			e.printStackTrace();
			return ResultCode.OPERATION_FAILED;
		}
	}
	
}
