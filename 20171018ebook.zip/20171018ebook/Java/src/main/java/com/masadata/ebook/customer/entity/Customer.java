package com.masadata.ebook.customer.entity;

import java.util.Date;
import java.util.List;

public class Customer {

	private Integer id;
	private String caseId;
	private String name;
	private String firstLetter;
	private Integer gender;
	private String age;
	private String mobile;
	private String mobileMac;
	private String hanming;
	private Integer consultant;
	private String consultantNo;
	private String consultantName;
	private String status;
	private String lastRecordDate;
	private String completion;
	private String intentLevel;
	private String intentProject;
	private String intentProjectLabel;
	private String intentApartType;
	private String intentApartTypeLabel;
	private String remark;
	private Integer visits;
	private Integer deals;
	private Date createTime;
	private String createBy;
	private Date updateTime;
	private String updateBy;
	
	private List<CustStatusRecord> visitList;
	private List<CustStatusRecord> dealList;
	private List<CustAttr> attrs;

	public List<CustStatusRecord> getVisitList() {
		return visitList;
	}
	public void setVisitList(List<CustStatusRecord> visitList) {
		this.visitList = visitList;
	}
	public List<CustStatusRecord> getDealList() {
		return dealList;
	}
	public void setDealList(List<CustStatusRecord> dealList) {
		this.dealList = dealList;
	}
	public List<CustAttr> getAttrs() {
		return attrs;
	}
	public void setAttrs(List<CustAttr> attrs) {
		this.attrs = attrs;
	}
	public String getCompletion() {
		return completion;
	}
	public void setCompletion(String completion) {
		this.completion = completion;
	}
	public Integer getVisits() {
		return visits;
	}
	public void setVisits(Integer visits) {
		this.visits = visits;
	}
	public Integer getDeals() {
		return deals;
	}
	public void setDeals(Integer deals) {
		this.deals = deals;
	}
	public String getIntentLevel() {
		return intentLevel;
	}
	public void setIntentLevel(String intentLevel) {
		this.intentLevel = intentLevel;
	}
	public String getIntentProject() {
		return intentProject;
	}
	public void setIntentProject(String intentProject) {
		this.intentProject = intentProject;
	}
	public String getIntentProjectLabel() {
		return intentProjectLabel;
	}
	public void setIntentProjectLabel(String intentProjectLabel) {
		this.intentProjectLabel = intentProjectLabel;
	}
	public String getIntentApartType() {
		return intentApartType;
	}
	public void setIntentApartType(String intentApartType) {
		this.intentApartType = intentApartType;
	}
	public String getIntentApartTypeLabel() {
		return intentApartTypeLabel;
	}
	public void setIntentApartTypeLabel(String intentApartTypeLabel) {
		this.intentApartTypeLabel = intentApartTypeLabel;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(int gender) {
		this.gender = gender;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMobileMac() {
		return mobileMac;
	}
	public void setMobileMac(String mobileMac) {
		this.mobileMac = mobileMac;
	}
	public String getHanming() {
		return hanming;
	}
	public void setHanming(String hanming) {
		this.hanming = hanming;
	}
	public void setConsultant(Integer consultant) {
		this.consultant = consultant;
	}
	public int getConsultant() {
		return consultant;
	}
	public void setConsultant(int consultant) {
		this.consultant = consultant;
	}
	public String getConsultantNo() {
		return consultantNo;
	}
	public void setConsultantNo(String consultantNo) {
		this.consultantNo = consultantNo;
	}
	public String getConsultantName() {
		return consultantName;
	}
	public void setConsultantName(String consultantName) {
		this.consultantName = consultantName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLastRecordDate() {
		return lastRecordDate;
	}
	public void setLastRecordDate(String lastRecordDate) {
		this.lastRecordDate = lastRecordDate;
	}
	public String getFirstLetter() {
		return firstLetter;
	}
	public void setFirstLetter(String firstLetter) {
		this.firstLetter = firstLetter;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	
}
