package com.masadata.ebook.wxapp.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masadata.ebook.common.logger.LoggerUtils;
import com.masadata.ebook.common.web.BaseController;
import com.masadata.ebook.common.xml.XmlParser;
import com.masadata.ebook.customer.entity.Customer;
import com.masadata.ebook.wxapp.api.msg.RecvMsg;
import com.masadata.ebook.wxapp.service.WXMsgService;

@RequestMapping("${server.apiPath}/wxapp/msg")
@RestController
public class WXMsgController extends BaseController {

	@Autowired
	WXMsgService msgService;
	
	@RequestMapping(method=RequestMethod.POST, path="/handle/{caseId}")
	public void handle(@PathVariable("caseId") String caseId, HttpServletRequest request, HttpServletResponse response) {
		Long logid = LoggerUtils.getLogId();
		logger.info("logid={} | POST /handle: caseId={}", logid, caseId);
		RecvMsg recvMsg = null;
		try {
			recvMsg = new RecvMsg(new XmlParser(request.getInputStream()));
		} catch(Exception de) {
			de.printStackTrace();
		}
		try {
			response.getWriter().write("success");
			response.getWriter().flush();
			response.getWriter().close();
		} catch(Exception ioe) {
			ioe.printStackTrace();
		}
		if(recvMsg != null) { //处理消息
			logger.info("recvMsg:" + recvMsg.toString());
			msgService.handle(recvMsg, caseId);
		}
		logger.info("logid={} | return:success", logid, caseId);
	}
	
	@RequestMapping(method=RequestMethod.GET, path="/handle/{caseId}")
	public String auth(@RequestParam("signature") String signature, @RequestParam("nonce") String nonce, @RequestParam("timestamp") String timestamp, @RequestParam("echostr") String echostr) {
		Long logid = LoggerUtils.getLogId();
		logger.info("logid={} | GET /handle: signature={}, nonce={}, timestamp={}, echostr={}", logid, signature, nonce, timestamp, echostr);
		String str = msgService.authWXAppServerUrl(signature, nonce, timestamp, echostr);
		logger.info("logid={} |return: {}", logid, str);
		return str;
	}
	
	@PostMapping("/cust-visit")
	public String pushCustVisitMsg(@RequestParam("sign") String sign, Customer cust) {
		if("POIU$#@!".equals(sign)) {
			try {
				msgService.pushCustVisitMsg(cust);
			} catch(Exception e) {
				e.printStackTrace();
				return "excp";
			}
			return "success";
		} else {
			return "error";
		}
	}
}
