package com.masadata.ebook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.masadata.ebook.common.constants.AppConfig;
import com.masadata.ebook.wxapp.interceptor.LogInterceptor;
import com.masadata.ebook.wxapp.interceptor.WXUserInterceptor;

@Configuration
public class EBookAppConfiguration extends WebMvcConfigurerAdapter {

	@Autowired
	WXUserInterceptor userInterceptor;
	@Autowired
	LogInterceptor logInterceptor;
	
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(userInterceptor)
			.addPathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/**")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/user/case-config")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/user/bind")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/wxuser-info")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/wxapp-init")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/customer/daily-stat")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/wxapp/msg/**")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/common/**")
			.excludePathPatterns(AppConfig.SERVER_API_PATH + "/client/**")
			.excludePathPatterns("/test/**")
			;
		registry.addInterceptor(logInterceptor);
		super.addInterceptors(registry);
	}
	
	public void addCorsMappings(CorsRegistry registry) {
		if(AppConfig.SERVER_ALLOW_CORSDOMAIN) {
			registry.addMapping(AppConfig.SERVER_API_PATH + "/**")
				.allowedOrigins(AppConfig.SERVER_CORSDOMAIN)
				.allowedMethods("POST", "GET")
				.allowCredentials(true)
				.allowedHeaders("x-requested-with")
				.maxAge(3600);
			super.addCorsMappings(registry);
		}
	}
}
