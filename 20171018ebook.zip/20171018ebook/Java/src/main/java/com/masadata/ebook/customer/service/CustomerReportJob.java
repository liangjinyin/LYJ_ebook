package com.masadata.ebook.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masadata.ebook.customer.dao.CaseDao;
import com.masadata.ebook.customer.dao.CustomerDao;

@Component
@RestController
public class CustomerReportJob {
	
	@Autowired
	CustomerDao custDao;
	@Autowired
	CaseDao caseDao;
	
	@Scheduled(cron="0 0 1 ? * *")
	private void statCustDaily() {
		try {
			custDao.deleteYesterdayStat();
			custDao.statCustDaily();
		} catch(Exception e) {
			e.printStackTrace();
			//日报统计出错，后续版本完善要增加提醒
		}
	}
	
	// 实时调用重跑昨日r
	@RequestMapping("${server.apiPath}/wxapp/customer/daily-stat")
	public String dailyStat() {
		try {
			statCustDaily();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return "success";
	}
}
