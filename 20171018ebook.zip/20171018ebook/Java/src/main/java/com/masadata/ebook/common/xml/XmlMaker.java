package com.masadata.ebook.common.xml;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.util.StringUtils;

import com.masadata.ebook.common.xml.annotation.XmlElemPath;
import com.masadata.ebook.common.xml.annotation.XmlRootPath;

public class XmlMaker {
	private Object object;
	public XmlMaker(Object object) {
		this.object = object;
	}
	
	@SuppressWarnings("rawtypes")
	private List<Field> getObjFields(Class clazz) {
		if(clazz == null) {
			return new ArrayList<Field>();
		}
		List<Field> fields = new ArrayList<Field>();
		for(Field field : clazz.getDeclaredFields()) {
			fields.add(field);
		}
		fields.addAll(getObjFields(clazz.getSuperclass()));
		return fields;
	}

	@SuppressWarnings("rawtypes")
	private Element getXmlNodeFromObj(Object obj) throws IllegalArgumentException, IllegalAccessException {
		Class clazz = obj.getClass();
		XmlRootPath rootPathAnno = obj.getClass().getAnnotation(XmlRootPath.class);
		if(rootPathAnno == null) {
			return null;
		}
		String rootPath = (StringUtils.isEmpty(rootPathAnno.value()) ? obj.getClass().getSimpleName() : rootPathAnno.value());
		Element root = DocumentHelper.createElement(rootPath);
		
		List<Field> fields = getObjFields(clazz);
		for(Field field : fields) {
			XmlElemPath elemAnno = field.getAnnotation(XmlElemPath.class);
			if(elemAnno != null) {
				field.setAccessible(true);
				String elemPath = elemAnno.value();
				if(StringUtils.isEmpty(elemPath)) {
					elemPath = field.getName();
				}
				Element elem = DocumentHelper.createElement(elemPath);
				if(field.getType().isAssignableFrom(List.class)) {
					List itemList = (List)field.get(obj);
					for(Object item : itemList) {
						elem.add(getXmlNodeFromObj(item));
					}
					root.add(elem);
				} else {
					String elemText = (field.get(obj) == null ? null : field.get(obj).toString());
					elem.addCDATA(elemText);
					String parent = elemAnno.parent();
					if(StringUtils.isEmpty(parent)) {
						root.add(elem);
					} else {
						Element elemParent = (Element) root.selectSingleNode(elemAnno.parent());
						if(elemParent == null) {
							elemParent = DocumentHelper.createElement(elemAnno.parent());
							elemParent.add(elem);
							root.add(elemParent);
						} else {
							elemParent.add(elem);
						}
					}
				}
			}
		}	
		return root;
	}
	
	public String toDomStr() throws IllegalArgumentException, IllegalAccessException {
		Document dom = toDocument();
		return dom.asXML();
	}
	
	public Document toDocument() throws IllegalArgumentException, IllegalAccessException {
		Document dom = DocumentHelper.createDocument();
		dom.setRootElement(getXmlNodeFromObj(this.object));
		return dom;
	}
	
}
