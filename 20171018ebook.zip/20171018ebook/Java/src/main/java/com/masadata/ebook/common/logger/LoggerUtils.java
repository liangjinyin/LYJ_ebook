package com.masadata.ebook.common.logger;



public class LoggerUtils {

	public final static Long getLogId() {
		return System.currentTimeMillis();
	}
	
}
