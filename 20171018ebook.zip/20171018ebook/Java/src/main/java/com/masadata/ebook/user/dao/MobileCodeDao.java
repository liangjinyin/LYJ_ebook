package com.masadata.ebook.user.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.masadata.ebook.user.entity.MobileCode;

@Mapper
public interface MobileCodeDao {

	//手机验证码，10分钟有效
	@Update("update sys_mobile_code "
			+ "set verify_time = now() "
			+ "where mobile = #{mobile} and `type` = #{type} and verify_time is null "
			+ "and code = #{code} and unix_timestamp(create_time) >= unix_timestamp(now()) - 600")
	int checkMobileCode(@Param("mobile") String mobile, @Param("code") String code, @Param("type") String type);
	
	@Select("select mobile, `type`, code, date_format(create_time, '%Y-%m-%d %H:%i:%s') createTime, date_format(verify_time, '%Y-%m-%d %H:%i:%s') verifyTime "
			+ "from sys_mobile_code "
			+ "where mobile = #{mobile} and `type` = #{type} "
			+ "and unix_timestamp(create_time) >= unix_timestamp(now()) - 600 "
			+ "and code = #{code} ")
	MobileCode checkMobileIncorrectOrExpired(@Param("mobile") String mobile, @Param("code") String code, @Param("type") String type);
	
	@Update("update sys_mobile_code "
			+ "set verify_time = now() "
			+ "where mobile = #{mobile} and `type` = #{type} "
			+ "and verify_time is null ")
	int expireMobileCode(MobileCode code);
	@Insert("insert into sys_mobile_code(mobile, type, code, create_time) "
			+ "values(#{mobile}, #{type}, #{code}, now()) ")
	Integer createMobileCode(MobileCode code);
}
