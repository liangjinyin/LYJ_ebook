package com.masadata.ebook.wxapp.api.request;

import org.apache.http.HttpStatus;

import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class WebJSApiTicketRequest {
	private final static String URL = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=%s&type=jsapi";
	
	String accessToken;
	
	public WebJSApiTicketRequest(String accessToken) {
		this.accessToken = accessToken;
	}
	
	public String getJSApiKey() throws Exception {
		String url = String.format(URL, accessToken);
		CommonHttpResponse response = new HttpHelper().httpGet(url, null);
		if(HttpStatus.SC_OK == response.getRetCode()) {
			return response.getEntityStr();
		} else {
			return response.toString();
		}
	}
	
	public static void main(String args[]) throws Exception {
		System.out.println(new WebJSApiTicketRequest("gerH4Qg1mxdqIg9tOB-hverIEud3r77Ygn-mzPa3OLI8yZ7tQOTjl1uEh3Qat5PSzN2O356t8TmrLrRRvyWt1N-xnheFAk3S_qjfCY8I7yxgwA_HlQnd5QviJuYUiMUWSCFaAIAFPS").getJSApiKey());
	}
}
