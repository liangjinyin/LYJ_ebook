package com.masadata.ebook.common.http;

import org.apache.http.HttpResponse;

public interface HttpResponseParser {
	
	public CommonHttpResponse parseHttpResponse(HttpResponse response) throws Exception;
}
