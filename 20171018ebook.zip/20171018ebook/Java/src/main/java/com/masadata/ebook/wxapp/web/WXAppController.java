package com.masadata.ebook.wxapp.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.web.BaseController;
import com.masadata.ebook.wxapp.service.WXAppService;

@RestController
@RequestMapping(path="${server.apiPath}/wxapp", method={RequestMethod.POST})
public class WXAppController extends BaseController {

	@Autowired
	WXAppService appService;
	
	@RequestMapping(path="/wxuser-info")
	public String getWXUserInfo(@RequestParam("caseId") String caseId, @RequestParam("code") String code, @RequestParam("contextPath") String contextPath) {
		data = appService.getWXUserInfo(caseId, code, contextPath);
		if(data instanceof ResultCode) {
			retCode = (ResultCode) data;
			data = null;
		} else {
			retCode = ResultCode.OPERATION_SUCCESSED;
		}
		return result();
	}
	
	@RequestMapping(path="/wxapp-init", method={RequestMethod.GET})
	public String initWXApp(@RequestParam("caseId") String caseId, @RequestParam("token") String token) {
		logger.info("request /api/wxapp/wxapp-init caseId=" + caseId + "&token=" + token);
		if("masa.123".equalsIgnoreCase(token)) {
			retCode = appService.initWXApp(caseId);
			logger.info("response " + result());
			data = null;
			return result();
		} else {
			return "";
		}
			
	}
}
