package com.masadata.ebook.user.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.web.BaseController;
import com.masadata.ebook.user.entity.User;
import com.masadata.ebook.user.service.UserService;

@RestController
@RequestMapping(path="${server.apiPath}/wxapp/user", method={RequestMethod.POST})
public class UserController extends BaseController {

	@Autowired
	UserService userService;
	
	@RequestMapping("/bind")
	public String bind(@RequestParam("code") String code, User user) {
		try {
			retCode = userService.bind(code, user);
		} catch(Exception e) {
			e.printStackTrace();
			retCode = ResultCode.OPERATION_FAILED;
		}
		data = null;
		return result();
	}
	
	@RequestMapping("/view")
	public String view(User user) {
		data = userService.getUserInfo(user);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
	
	@RequestMapping("/cancel-bind")
	public String cancelBind(User user) {
		retCode = userService.cancelBind(user);
		data = null;
		return result();
	}
	
	@RequestMapping("/case-config")
	public String getCaseConfig(User user) {
		data = userService.getUserCaseConfig(user);
		retCode = ResultCode.OPERATION_SUCCESSED;
		return result();
	}
}
