package com.masadata.ebook.common.xml;

import java.io.InputStream;
import java.io.StringReader;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

public class XmlParser {
	
	private Document dom = null;
	
	public XmlParser(String xmlStr) throws DocumentException {
		SAXReader saxReader = new SAXReader();
		dom = saxReader.read(new StringReader(xmlStr));
	}
	
	public XmlParser(InputStream in) throws DocumentException {
		SAXReader saxReader = new SAXReader();
		dom = saxReader.read(in);
	}
	
	public String getNodeText(String nodePath) {
		return (dom.selectSingleNode(nodePath) == null ? null : dom.selectSingleNode(nodePath).getText());
	}
	
	public Long getNodeTextLongVal(String nodePath) {
		return (dom.selectSingleNode(nodePath) == null ? null : Long.parseLong(dom.selectSingleNode(nodePath).getText()));
	}
	
	public Integer getNodeTextIntVal(String nodePath) {
		return (dom.selectSingleNode(nodePath) == null ? null : Integer.parseInt(dom.selectSingleNode(nodePath).getText()));
	}
	
	public Double getNodeTextDoubleVal(String nodePath) {
		return (dom.selectSingleNode(nodePath) == null ? null : Double.parseDouble(dom.selectSingleNode(nodePath).getText()));
	}
	
}
