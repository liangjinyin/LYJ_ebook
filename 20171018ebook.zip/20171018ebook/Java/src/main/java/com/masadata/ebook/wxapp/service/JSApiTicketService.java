package com.masadata.ebook.wxapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.masadata.ebook.wxapp.api.request.WebJSApiTicketRequest;
import com.masadata.ebook.wxapp.dao.CaseWXAppDao;
import com.masadata.ebook.wxapp.entity.CaseWXApp;

@Component
public class JSApiTicketService {

	@Autowired
	CaseWXAppDao caseAppDao;
	@Autowired
	AccessTokenService tokenService;
	
	//@Scheduled(fixedDelay=7150000)
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public void updateJSApiTicket() {
		List<CaseWXApp> appList = caseAppDao.getCaseWXAppList();
		for(CaseWXApp app : appList) {
			updateJSApiTicket(app);
		}
	}
	
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	private void updateJSApiTicket(CaseWXApp app) {
		int times = 3;
		String ticket = null;
		while(times-- > 0) { //每个公众号的access_token最多尝试获取3次
			try {
				JSONObject json = JSON.parseObject(new WebJSApiTicketRequest(tokenService.getAccessToken(app.getCaseId())).getJSApiKey());
				if(json.containsKey("errcode") && json.getIntValue("errcode") != 0) { //默认考虑为42001 access_token expired
					continue ;
				} else {
					ticket = json.getString("ticket");
					break;
				}
			} catch(Exception e) { //如果请求过程中出现异常，继续尝试
				e.printStackTrace(); 
				continue;
			}
		}
		if(!StringUtils.isEmpty(ticket)) { //更新accessToken
			app.setJsApiTicket(ticket);
			caseAppDao.updateCaseWXAppJSApiTicket(app);
		}
	}
	
	public String getWXAppJSApiTicket(String appID) {
		String ticket = caseAppDao.getWXAppJSApiTicketByAppID(appID);
		return ticket;
	}
	
}
