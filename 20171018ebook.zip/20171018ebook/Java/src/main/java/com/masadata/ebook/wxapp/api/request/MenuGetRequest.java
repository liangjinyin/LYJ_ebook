package com.masadata.ebook.wxapp.api.request;

import org.apache.http.HttpStatus;

import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class MenuGetRequest {

	private String accessToken;
	private static String URL = "https://api.weixin.qq.com/cgi-bin/menu/get?access_token=%s";
	
	public MenuGetRequest(String accessToken) {
		this.accessToken = accessToken;
	}
	
	public String getMenu() throws Exception { 
		CommonHttpResponse response = new HttpHelper().httpGet(String.format(URL, accessToken), null);
		if(response.getRetCode() == HttpStatus.SC_OK) {
			return response.getEntityStr();
		} else {
			return response.toString();
		}
	}
	
}
