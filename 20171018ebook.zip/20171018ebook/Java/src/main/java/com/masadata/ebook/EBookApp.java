package com.masadata.ebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class EBookApp {	
    public static void main(String[] args) {
    	SpringApplication app = new SpringApplication(EBookApp.class);
    	app.run(args);
    }
}