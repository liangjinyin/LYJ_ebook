package com.masadata.ebook.wxapp.api.request;

import org.apache.http.HttpStatus;

import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class WebAccessTokenRequest {

	String appID;
	String appSecret;
	String code;
	private final static String URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code";
	
	public WebAccessTokenRequest(String appID, String appSecret, String code) {
		this.appID = appID;
		this.appSecret = appSecret;
		this.code = code;
	}
	
	public String getAccessTokenAndOpenID() throws Exception {
		String url = String.format(URL, appID, appSecret, code);
		CommonHttpResponse response = new HttpHelper().httpGet(url, null);
		if(HttpStatus.SC_OK == response.getRetCode()) {
			return response.getEntityStr();
		} else {
			return response.toString();
		}
	}
	
}
