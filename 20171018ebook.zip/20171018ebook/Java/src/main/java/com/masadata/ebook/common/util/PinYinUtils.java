package com.masadata.ebook.common.util;

import java.util.HashMap;
import java.util.Map;

import com.github.stuxuhai.jpinyin.PinyinFormat;
import com.github.stuxuhai.jpinyin.PinyinHelper;

public class PinYinUtils {

	static Map<String, String> map = new HashMap<String, String>();
	static {
		map.put("区", "ou");
		map.put("黑", "he"); //he4
		map.put("盖", "ge"); //ge3
		map.put("查", "zha");
		map.put("教", "jiao");
		map.put("任", "ren"); //
		map.put("曾", "zeng");
		map.put("缪", "miao");
		map.put("晟", "cheng"); //cheng2
		map.put("单", "shan"); 
		map.put("乐", "yue");
		map.put("员", "yun"); //yun4
		map.put("仇", "qiu"); 
		map.put("华", "hua");
		map.put("尉迟", "yuchi");
		map.put("万俟", "moqi"); //mo4 qi2
	}
	public static String getPinYin(String name) throws Exception {
		return getPinYin(name, " ");
	}
	
	public static String getPinYin(String name, String seperator) throws Exception {
		return getPinYin(name, seperator, PinyinFormat.WITHOUT_TONE);
	}
	
	public static String getPinYin(String name, PinyinFormat format) throws Exception {
		return getPinYin(name, " ", format);
	}
	
	public static String getPinYin(String name, String seperator, PinyinFormat format) throws Exception {
		return PinyinHelper.convertToPinyinString(name, seperator, format);
	}
	
	public static String getLastNameFirstLetter(String name) throws Exception {
		return getLastName(name).substring(0, 1).toUpperCase();
	}
	
	public static String getLastNameFirstLetter(String name, String defaultVal) {
		try {
			return getLastName(name).substring(0, 1).toUpperCase();
		} catch(Exception e) {
			return defaultVal;
		}
	}
	
	public static String getLastName(String name) throws Exception {
		String lastName = null;
		for(String key : map.keySet()) {
			if(name.startsWith(key)) {
				lastName = map.get(key);
				break;
			}
		}
		if(lastName == null) {
			String pinyin = getPinYin(name).trim();
			int indx = pinyin.indexOf(' ');
			if(indx < 0) {
				lastName = pinyin;
			} else {
				lastName = pinyin.substring(0, indx);
			}
		}
		return lastName;
	}
	
}
