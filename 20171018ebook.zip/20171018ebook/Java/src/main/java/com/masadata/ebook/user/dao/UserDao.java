package com.masadata.ebook.user.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.masadata.ebook.user.entity.User;

@Mapper
public interface UserDao {

	//一个公众号多个案场
	@Select("select b.case_id caseId "
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.del_flag = 0 and a.login_flag = 1 "
			+ "and b.del_flag = 0 "
			+ "where b.openid = #{openid} "
			+ "limit 1 ")
	public String getUserBindedCaseByWXOpenID(@Param("openid") String openid);
	@Select("select b.case_id caseId, a.id, a.name, a.no "
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.del_flag = 0 and a.login_flag = 1 "
			+ "and b.del_flag = 0 "
			+ "where b.openid = #{openid} and b.case_id = ${caseId} ")
	public User getUserByWXOpenID(User user);
	
	@Select("select a.id, a.name, a.no "
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.del_flag = 0 and a.login_flag = 1 "
			+ "and b.del_flag = 0 "
			+ "where b.case_id = ${caseId} "
			+ "and a.no = #{no} ")
	public User getUserByCaseIdAndUserNo(@Param("caseId") String caseId, @Param("no") String consultantNo);
	
	@Select("select admin_flag from salesoffice_worker where openid = #{openid} and case_id = ${caseId} and del_flag = 0")
	Integer getUserAdminFlag(User user);

	/*//一个案场一个公众号
	@Select("select count(1) "
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.`type` = 'case-worker' and a.mobile = #{mobile} and a.del_flag = 0 "
			+ "and b.case_id = ${caseId} and b.del_flag = 0 ")*/
	//多个案场一个公众号
	@Select("select a.login_flag loginFlag "
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.`type` = 'case-worker' and a.mobile = #{mobile} and a.del_flag = 0 "
			+ "and b.del_flag = 0 ")
	Boolean getUserLoginFlagByMobile(@Param("mobile") String mobile);
	/*@Select("select count(1) " 
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.`type` = 'case-worker' and a.mobile = #{mobile} and name = #{name} and a.del_flag = 0 "
			+ "and b.case_id = ${caseId} and b.del_flag = 0 ")*/
	@Select("select count(1) " 
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.`type` = 'case-worker' and a.mobile = #{mobile} and a.name = #{name} and a.del_flag = 0 "
			+ "and b.del_flag = 0 ")
	Integer checkCaseWorkerMobileAndName(User user);
	/*@Select("select b.mobile "
			+ "from salesoffice_worker a "
			+ "join sys_user b "
			+ "on a.user_id = b.id "
			+ "and a.openid = #{openid} "
			+ "and a.case_id = ${caseId} " 
			+ "and b.`type` = 'case-worker' ")*/
	@Select("select b.mobile "
			+ "from salesoffice_worker a "
			+ "join sys_user b "
			+ "on a.user_id = b.id "
			+ "and a.openid = #{openid} "
			+ "and b.`type` = 'case-worker' and b.login_flag = 1 "
			+ "and a.del_flag = 0 and b.del_flag = 0 ")
	String getUserBindMobileByOpenid(User user);
	/*@Select("select a.openid "
			+ "from salesoffice_worker a "
			+ "join sys_user b "
			+ "on a.user_id = b.id "
			+ "and b.mobile = #{mobile} "
			+ "and a.case_id = ${caseId} ")*/
	@Select("select a.openid "
			+ "from salesoffice_worker a "
			+ "join sys_user b "
			+ "on a.user_id = b.id "
			+ "and b.mobile = #{mobile} and b.`type` = 'case-worker' and b.login_flag = 1 "
			+ "and a.del_flag = 0 and b.del_flag = 0 ")
	String getUserBindOpenidByMobile(User user);
	/*@Update("update salesoffice_worker a, sys_user b "
			+ "set a.openid = #{openid} "
			+ "where a.user_id = b.id "
			+ "and b.mobile = #{mobile} and b.del_flag = 0 and b.`type` = 'case-worker' "
			+ "and a.del_flag = 0 and a.case_id = ${caseId} ")*/
	@Update("update salesoffice_worker a, sys_user b "
			+ "set a.openid = #{openid} "
			+ "where a.user_id = b.id "
			+ "and b.mobile = #{mobile} and b.del_flag = 0 and b.`type` = 'case-worker' and b.login_flag = 1 "
			+ "and a.del_flag = 0 ")
	Integer bindUserWXOpenID(User user);
	
	@Select("select a.name, a.mobile, a.no, a.photo, b.admin_flag adminFlag "
			+ "from sys_user a "
			+ "join salesoffice_worker b "
			+ "on a.id = b.user_id "
			+ "and a.`type` = 'case-worker' and a.del_flag = 0 "
			+ "and b.del_flag = 0 and b.openid = #{openid} and b.case_id = ${caseId} ")
	Map<String, Object> getUserInfo(User user);
	@Select("select openid "
			+ "from salesoffice_worker "
			+ "where user_id = ${userId} and case_id = ${caseId} and del_flag = 0 ")
	String getCaseUserOpenidByUser(@Param("userId") int userId, @Param("caseId") String caseId);
	
	@Update("update salesoffice_worker "
			+ "set openid = null "
			+ "where openid = #{openid} and case_id = ${caseId} ")
	Integer cancelBind(User user);
	
	@Update("update sys_user a, salesoffice_worker b "
			+ "set a.photo = #{photo} "
			+ "where a.id = b.user_id "
			+ "and a.del_flag = 0 "
			+ "and b.openid = #{openid} and b.case_id = #{caseId} and b.del_flag = 0 ")
	Integer updateCaseWorkerPhoto(User user);
	
	@Select("select a.name caseName, a.logo_url logoUrl "
			+ "from salesoffice a "
			+ "where a.id = ${caseId} ")
	Map<String, Object> getUserCaseConfig(@Param("caseId") String caseId);
}
