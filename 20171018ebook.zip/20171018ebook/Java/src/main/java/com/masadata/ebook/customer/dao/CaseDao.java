package com.masadata.ebook.customer.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.masadata.ebook.customer.entity.CustAttr;

@Mapper
public interface CaseDao {

	@Select("select concat('', id) as `key`,name value "
			+ "from salesoffice_project "
			+ "where case_id = ${caseId} and del_flag = 0 ")
	List<Map<String, String>> getProjectList(@Param("caseId") String caseId);
	
	@Select("select apart_type_code `key`, apart_type value "
			+ "from salesoffice_project_aparttype "
			+ "where del_flag = 0 and case_id = ${caseId} "
			+ "order by property_type, apart_type_area_min, apart_type_area_max ")
	List<Map<String, String>> getCaseApartTypeListByCaseId(@Param("caseId") String caseId);
	@Select("select name "
			+ "from salesoffice_project "
			+ "where del_flag = 0 and id = ${id} ")
	String getCaseProjectById(@Param("id") String id);
	@Select("select count(1) "
			+ "from salesoffice_project "
			+ "where del_flag = 0 and case_id = ${caseId} and id = ${id} ")
	int checkCaseProjectExist(@Param("caseId") String caseId, @Param("id") String id);
	@Select("select concat('', id) id, name "
			+ "from salesoffice_project "
			+ "where del_flag = 0 and case_id = ${caseId} "
			+ "limit 1 ")
	Map<String, String> getCaseOneProjectByCaseId(@Param("caseId") String caseId);
	/*@Select("select 1 "
			+ "from salesoffice_project_aparttype "
			+ "where del_flag = 0 "
			+ "and apart_type_code = #{value} and case_id = ${caseId}")
	Integer checkApartType(@Param("caseId") String caseId, @Param("value") String value);*/
	@Select("<script>"
			+ "select group_concat(apart_type_code) apartTypes "
			+ "from salesoffice_project_aparttype "
			+ "where del_flag = 0 "
			+ "and case_id = ${caseId} "
			+ "and apart_type_code in <foreach item='item' index='index' collection='values' open='(' separator=',' close=')'>"
			+ "#{item}"
			+ "</foreach> "
			+ "</script>")
	String checkApartType(@Param("caseId") String caseId, @Param("values") String[] values);
	@Select("select apart_type apartType "
			+ "from salesoffice_project_aparttype "
			+ "where del_flag = 0 and apart_type_code = #{value} and case_id = ${caseId} ")
	String getApartTypeLabel(@Param("caseId") String caseId, @Param("value") String value);
	/*@Select("<script>"
			+ "select count(1) "
			+ "from salesoffice_cust_attr_option "
			+ "where del_flag = 0 and attr_id = ${attrId} "
			+ "and value in <foreach item='item' index='index' collection='values' open='(' separator=',' close=')'>"
			+ "#{item}"
			+ "</foreach>"
			+ "</script>")
	Integer checkAttrOption(@Param("attrId") int attrId, @Param("values") String[] values);*/
	@Select("<script>"
			+ "select group_concat(value) value "
			+ "from salesoffice_cust_attr_option "
			+ "where del_flag = 0 and attr_id = ${attrId} "
			+ "and value in <foreach item='item' index='index' collection='values' open='(' separator=',' close=')'>"
			+ "#{item}"
			+ "</foreach>"
			+ "</script>")
	String checkAttrOption(@Param("attrId") int attrId, @Param("values") String[] values);
	@Select("select label "
			+ "from salesoffice_cust_attr_option "
			+ "where attr_id = ${attrId} and value = #{value} "
			+ "and del_flag = 0 ")
	String getAttrOptionLabel(@Param("attrId") int attrId, @Param("value") String value);
	
	@Select("select id, name, label, `type` "
			+ "from salesoffice_cust_attr "
			+ "where id = ${id} and del_flag = 0 ")
	CustAttr getCaseCustAttrById(@Param("id") int id);
	@Select("select id, name, label, `type`, required "
			+ "from salesoffice_cust_attr "
			+ "where case_id = ${caseId} and del_flag = 0 ")
	List<CustAttr> getCaseCustAttrList(@Param("caseId") String caseId);
	
	@Select("select id, name, label "
			+ "from salesoffice_cust_attr_group "
			+ "where del_flag = 0 and case_id = ${caseId} and hidden = 0 "
			+ "order by editable, sort ")
	/*@Results({
		@Result(column="id", property="attrs", many=@Many(select="com.masa.ebook.customer.dao.CaseDao.getCaseCustAttrByGroup"))
	})*/
	List<Map<String, Object>> getCaseCustAttrGroupAndDetail(@Param("caseId") String caseId);
	
	@Select("select id, name, label, type, required "
			+ "from salesoffice_cust_attr "
			+ "where del_flag = 0 and group_id = ${groupId} "
			+ "order by required desc, sort ")
	/*@Results({
		@Result(column="id", property="options", many=@Many(select="com.masa.ebook.customer.dao.CaseDao.getCaseCustAttrOptions"))
	})*/
	List<Map<String, Object>> getCaseCustAttrByGroup(@Param("groupId") int groupId);
	@Select("select value `key`, label value "
			+ "from salesoffice_cust_attr_option "
			+ "where del_flag = 0 and attr_id = ${attrId} "
			+ "order by sort ")
	List<Map<String, Object>> getCaseCustAttrOptions(@Param("attrId") int attrId);
	
	@Select("select a.name caseName, a.logo_url logoUrl, a.bg_img_url bgImgUrl, a.check_cust checkCust "
			+ "from salesoffice a "
			+ "where a.id = ${caseId} and a.del_flag = 0 ")
	Map<String, Object> getCaseClientConfig(@Param("caseId") String caseId);
	
	@Select("select date_format(create_time, '%Y-%m-%d') openDate "
			+ "from salesoffice where id = ${id}")
	String getCaseOpenDate(@Param("id") String id);
}
