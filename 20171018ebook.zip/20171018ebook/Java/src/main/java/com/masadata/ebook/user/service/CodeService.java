package com.masadata.ebook.user.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.user.dao.MobileCodeDao;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.MobileCode;
import com.masadata.ebook.user.entity.User;

@Service
@Transactional(readOnly=true)
public class CodeService {
	public static final String CODE_TYPE_BIND_WXAPP = "case-worker-bind-wxapp";
	public static final String CODE_TYPE_VISITOR_CHECK = "visitor-check";

	public static final int MOBILE_CODE_LENGH = 6;
	@Autowired
	MobileCodeDao codeDao;
	private String createCode(int length) {
		String base = "1234567890";
		Random random = new Random();     
        StringBuffer sb = new StringBuffer();     
        for (int i = 0; i < length; i++) {     
            int number = random.nextInt(base.length());     
            sb.append(base.charAt(number));     
        }     
        return sb.toString();
	}
	
	@Autowired
	UserDao userDao;
	
	@Transactional(readOnly=false,rollbackFor=Exception.class)
	public ResultCode sendMobileCode(MobileCode code) {
		if(CODE_TYPE_BIND_WXAPP.equalsIgnoreCase(code.getType())) {
			//非案场工作人员
			User user = new User();
			user.setMobile(code.getMobile());
			/*//一个案场一个公众号
			user.setCaseId(code.getCaseId());*/
			Boolean userLoginFlag = userDao.getUserLoginFlagByMobile(user.getMobile());
			if(userLoginFlag == null) {//不为工作人员
				return ResultCode.USER_NOT_CASE_WORKER;
			} else if(!userLoginFlag) {
				return ResultCode.USER_DENIED;
			}
		} else if(CODE_TYPE_VISITOR_CHECK.equalsIgnoreCase(code.getType())) {
			//来客登记 无特殊要求
		} else {
			return ResultCode.MOBILECODE_TYPE_INVALID;
		}
		//将同一用户的同类用途的code置为无效
		codeDao.expireMobileCode(code);
		code.setCode(createCode(MOBILE_CODE_LENGH));
		if(codeDao.createMobileCode(code) > 0) {
			//调用短信发送
			try {
				return TecentSMSService.sendSMSSingle(code.getMobile(), code.getCode());
			} catch(Exception e) {
				e.printStackTrace();
				return ResultCode.OPERATION_FAILED;
			}
		} else {
			return ResultCode.OPERATION_FAILED;
		}	
	}
}
