package com.masadata.ebook.customer.entity;

public class CustReport {

	private String statMonth;
	private String statDate;
	private String statWeekday;
	private int userId;
	private int caseId;
	private String openid;
	private int visitors;
	private int multiVisitVisitors;
	private int dealCustomers;
	
	public String getStatMonth() {
		return statMonth;
	}
	public void setStatMonth(String statMonth) {
		this.statMonth = statMonth;
	}
	public String getStatDate() {
		return statDate;
	}
	public void setStatDate(String statDate) {
		this.statDate = statDate;
	}
	public String getStatWeekday() {
		return statWeekday;
	}
	public void setStatWeekday(String statWeekday) {
		this.statWeekday = statWeekday;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getCaseId() {
		return caseId;
	}
	public void setCaseId(int caseId) {
		this.caseId = caseId;
	}
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public int getVisitors() {
		return visitors;
	}
	public void setVisitors(int visitors) {
		this.visitors = visitors;
	}
	public int getMultiVisitVisitors() {
		return multiVisitVisitors;
	}
	public void setMultiVisitVisitors(int multiVisitVisitors) {
		this.multiVisitVisitors = multiVisitVisitors;
	}
	public int getDealCustomers() {
		return dealCustomers;
	}
	public void setDealCustomers(int dealCustomers) {
		this.dealCustomers = dealCustomers;
	}
}
