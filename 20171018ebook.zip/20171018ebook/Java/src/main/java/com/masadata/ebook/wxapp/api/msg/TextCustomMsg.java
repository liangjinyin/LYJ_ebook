package com.masadata.ebook.wxapp.api.msg;

import com.alibaba.fastjson.JSONObject;

public class TextCustomMsg {

	private String touser;
	private String msgtype;
	private String content;
	public TextCustomMsg(String touser, String content) {
		this.touser = touser;
		this.msgtype = "text";
		this.content = content;
	}
	
	public JSONObject toMsgBody() {
		JSONObject msg = new JSONObject();
		msg.put("touser", touser);
		msg.put("msgtype", msgtype);
		JSONObject text = new JSONObject();
		text.put("content", content);
		msg.put(msgtype, text);
		return msg;
	}
}
