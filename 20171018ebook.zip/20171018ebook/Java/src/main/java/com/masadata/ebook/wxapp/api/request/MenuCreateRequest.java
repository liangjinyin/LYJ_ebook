package com.masadata.ebook.wxapp.api.request;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import org.apache.http.HttpStatus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.masadata.ebook.common.http.CommonHttpResponse;
import com.masadata.ebook.common.http.HttpHelper;

public class MenuCreateRequest {
	
	private static final String MENU_FILE = "wxapp/app_menu.txt";
	private static final String URL = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=%s";
	String accessToken;
	String webserver;
	String appid;
	String caseId;
	
	public MenuCreateRequest(String accessToken, String webserver, String appid, String caseId) {
		this.accessToken = accessToken;
		this.webserver = webserver;
		this.appid = appid;
		this.caseId = caseId;
	}
	
	public JSONObject getMenuStruct() throws Exception {
		InputStream is = getClass().getClassLoader().getResourceAsStream(MENU_FILE);
		InputStreamReader r = new InputStreamReader(is);
		char[] buf = new char[1024];
		StringBuffer sb = new StringBuffer();
		while(r.read(buf) != -1) {
			sb.append(new String(buf));
			buf = new char[1024];
		}
		String menus = sb.toString();
		menus = menus.replaceAll("\\{webserver\\}", URLEncoder.encode(webserver, "utf-8"));
		menus = menus.replaceAll("\\{appid\\}", appid);
		menus = menus.replaceAll("\\{caseId\\}", caseId);
        return JSON.parseObject(menus);
	}
	public String initMenu() throws Exception {
		CommonHttpResponse response = new HttpHelper().httpPostWithStringStream(String.format(URL, accessToken), getMenuStruct());
		if(HttpStatus.SC_OK== response.getRetCode()) {
			return response.getEntityStr();
		} else {
			return response.toString();
		}
	}
	
}
