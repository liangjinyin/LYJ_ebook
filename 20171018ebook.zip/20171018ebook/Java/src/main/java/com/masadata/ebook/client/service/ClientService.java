package com.masadata.ebook.client.service;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.masadata.ebook.common.constants.ResultCode;
import com.masadata.ebook.common.util.DateUtils;
import com.masadata.ebook.common.util.PinYinUtils;
import com.masadata.ebook.customer.dao.CaseDao;
import com.masadata.ebook.customer.dao.CustomerDao;
import com.masadata.ebook.customer.entity.CustStatusRecord;
import com.masadata.ebook.customer.entity.Customer;
import com.masadata.ebook.customer.service.CustomerService;
import com.masadata.ebook.user.dao.MobileCodeDao;
import com.masadata.ebook.user.dao.UserDao;
import com.masadata.ebook.user.entity.User;
import com.masadata.ebook.user.service.CodeService;
import com.masadata.ebook.wxapp.service.WXMsgService;

@Service
@Transactional(readOnly=true)
public class ClientService {

	@Autowired
	CaseDao caseDao;
	@Autowired
	MobileCodeDao codeDao;
	@Autowired
	UserDao userDao;
	@Autowired
	CustomerDao custDao;
	@Autowired
	CustomerService custService;
	@Autowired
	WXMsgService msgService;
	
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public Boolean checkCustExist(String caseId, String mobileMac, String queryStr) throws Exception {
		Customer existCust = custDao.getCustDetailByMac(caseId, mobileMac);
		if(existCust == null) {
			return false;
		} else {
			if(CustomerService.CUST_STATUS_CALL.equalsIgnoreCase((String)existCust.getStatus())) {
				existCust.setStatus(CustomerService.CUST_STATUS_VISITOR);
			}
			existCust.setVisits(existCust.getVisits() + 1);
			existCust.setUpdateBy("" + existCust.getConsultant());
			existCust.setUpdateTime(new Date());
			existCust.setMobileMac(mobileMac);
			existCust.setHanming(queryStr);
			if(custDao.updateCustByClientRegister(existCust) > 0) {
				CustStatusRecord visitRecord = new CustStatusRecord();
				visitRecord.setCustId(existCust.getId());
				visitRecord.setStatus(CustomerService.CUST_STATUS_VISITOR);
				visitRecord.setRecordTime(DateUtils.formatDateTimeMinute(existCust.getUpdateTime()));
				visitRecord.setCreateBy("" + existCust.getConsultant());
				visitRecord.setUpdateBy("" + existCust.getConsultant());
				custDao.insertCustStatusRecord(visitRecord);
				custDao.updateStatusLastRecordDate(existCust.getId());
				msgService.pushCustVisitMsg(existCust);
				return true;
			} else { //客户更新失败，让前端正常进行登记流程
				return false;
			}
		}
	}
	public Map<String, Object> getCaseClientConfig(String caseId) {
		return caseDao.getCaseClientConfig(caseId);
	}
	
	@Transactional(readOnly=false, rollbackFor=Exception.class)
	public ResultCode customerCheckIn(Customer cust, String code) throws Exception {
		Map<String, Object> caseConfig = caseDao.getCaseClientConfig(cust.getCaseId());
		if(caseConfig == null) {
			return ResultCode.OPERATION_NOT_PERMITTED;
		} else {
			if(StringUtils.isEmpty(cust.getMobile())) {
				return ResultCode.CUST_MOBILE_EMPTY;
			}
			boolean checkCust = (boolean)caseConfig.get("checkCust");
			if(checkCust && StringUtils.isEmpty(code)) {
				return ResultCode.MOBILECODE_EMPTY;
			}
			if(checkCust) {
				if(codeDao.checkMobileCode(cust.getMobile(), code, CodeService.CODE_TYPE_VISITOR_CHECK) == 0) {
					if(codeDao.checkMobileIncorrectOrExpired(cust.getMobile(), code, CodeService.CODE_TYPE_VISITOR_CHECK) == null) {
						return ResultCode.MOBILECODE_INCORRECT;
					} else {
						return ResultCode.MOBILECODE_EXPIRED;
					}
				}
			}
			Customer existCust = custDao.getCustInfoByMobile(cust.getMobile(), cust.getCaseId());
			if(existCust == null) { //客户未被登记或添加过，新建客户，并添加到访记录
				if(StringUtils.isEmpty(cust.getConsultantNo())) {
					return ResultCode.CUST_CONSULTANT_EMPTY;
				}
				User consultant = userDao.getUserByCaseIdAndUserNo(cust.getCaseId(), cust.getConsultantNo());
				if(consultant == null) {
					return ResultCode.CUST_CONSULTANT_NOTEXIST;
				}	
				cust.setConsultant(consultant.getId());
				cust.setConsultantName(consultant.getName());
				cust.setConsultantNo(consultant.getNo());
				cust.setFirstLetter(PinYinUtils.getLastNameFirstLetter(cust.getName(), CustomerService.DEFAULT_LAST_NAME_FIRST_LETTER));
				cust.setAge(CustomerService.DEFAULT_AGE);
				cust.setStatus(CustomerService.CUST_STATUS_VISITOR);
				cust.setCreateBy("" + consultant.getId());
				cust.setCreateTime(new Date());
				cust.setUpdateBy(cust.getCreateBy());
				cust.setUpdateTime(cust.getCreateTime());
				cust.setLastRecordDate(DateUtils.formatDate(cust.getCreateTime()));
				cust.setVisits(1);
				cust.setDeals(0);
				cust.setIntentLevel(CustomerService.CUST_INTENT_LEVEL_D);
				Map<String, String> oneProject = caseDao.getCaseOneProjectByCaseId(cust.getCaseId());
				cust.setIntentProject(oneProject.get("id"));
				cust.setIntentProjectLabel(oneProject.get("name"));
				if(custDao.addCust(cust) > 0) {
					custService.updateCustCompletion(cust.getId(), cust.getCaseId());
					CustStatusRecord visitRecord = new CustStatusRecord();
					visitRecord.setCustId(cust.getId());
					visitRecord.setStatus(CustomerService.CUST_STATUS_VISITOR);
					visitRecord.setRecordTime(DateUtils.formatDateTimeMinute(cust.getCreateTime()));
					visitRecord.setCreateBy("" + consultant.getId());
					visitRecord.setUpdateBy("" + consultant.getId());
					custDao.insertCustStatusRecord(visitRecord);
						msgService.pushCustVisitMsg(cust);
					return ResultCode.OPERATION_SUCCESSED;
				} else {
					return ResultCode.OPERATION_FAILED;
				}
			} else { // 客户已经存在，更新手机mac信息，并增加到访记录
				if(existCust.getStatus().equalsIgnoreCase(CustomerService.CUST_STATUS_CALL)) {
					existCust.setStatus(CustomerService.CUST_STATUS_VISITOR);
				}
				existCust.setName(cust.getName());
				existCust.setGender(cust.getGender());
				existCust.setFirstLetter(PinYinUtils.getLastNameFirstLetter(existCust.getName(), CustomerService.DEFAULT_LAST_NAME_FIRST_LETTER));
				existCust.setVisits(existCust.getVisits() + 1);
				existCust.setUpdateBy("" + existCust.getConsultant());
				existCust.setUpdateTime(new Date());
				existCust.setMobileMac(cust.getMobileMac());
				existCust.setHanming(cust.getHanming());
				if(custDao.updateCustByClientRegister(existCust) > 0) {
					CustStatusRecord visitRecord = new CustStatusRecord();
					visitRecord.setCustId(existCust.getId());
					visitRecord.setStatus(CustomerService.CUST_STATUS_VISITOR);
					visitRecord.setRecordTime(DateUtils.formatDateTimeMinute(existCust.getUpdateTime()));
					visitRecord.setCreateBy("" + existCust.getConsultant());
					visitRecord.setUpdateBy("" + existCust.getConsultant());
					custDao.insertCustStatusRecord(visitRecord);
					custDao.updateStatusLastRecordDate(existCust.getId());
						msgService.pushCustVisitMsg(existCust);
					return ResultCode.OPERATION_SUCCESSED;
				} else {
					return ResultCode.OPERATION_FAILED;
				}
			}
		}
	}
	
}
